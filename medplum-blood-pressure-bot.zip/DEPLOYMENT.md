# Guía de Despliegue - Bot de Presión Arterial Medplum

Esta guía te llevará paso a paso a través del proceso de despliegue del bot de recordatorios de presión arterial en Medplum.

## 📋 Pre-requisitos

Antes de comenzar, asegúrate de tener:

- [ ] Cuenta en Medplum (https://app.medplum.com)
- [ ] Node.js >= 18.x instalado
- [ ] NPM o Yarn instalado
- [ ] CLI de Medplum instalado (`npm install -g @medplum/cli`)
- [ ] Credenciales de cliente de Medplum (Client ID y Secret)

## 🚀 Paso 1: Configuración del Proyecto

### 1.1 Clonar o crear el directorio del proyecto

```bash
mkdir medplum-blood-pressure-bot
cd medplum-blood-pressure-bot
```

### 1.2 Instalar dependencias

```bash
npm install
```

### 1.3 Configurar variables de entorno

```bash
# Copiar el archivo de ejemplo
cp .env.example .env

# Editar .env con tus credenciales
nano .env
```

Completa tu archivo `.env`:
```env
MEDPLUM_BASE_URL=https://api.medplum.com
MEDPLUM_CLIENT_ID=tu-client-id-aqui
MEDPLUM_CLIENT_SECRET=tu-secret-aqui
```

## 🔑 Paso 2: Obtener Credenciales de Medplum

### 2.1 Crear un Cliente en Medplum Console

1. Inicia sesión en https://app.medplum.com
2. Ve a **Settings** → **Clients**
3. Click en **Create new client**
4. Configura:
   - **Name**: "Blood Pressure Bot Client"
   - **Description**: "Cliente para bot de recordatorios de presión arterial"
   - **Redirect URI**: Deja vacío (no es necesario para bots)
5. Click en **Create**
6. **¡IMPORTANTE!** Copia y guarda el **Client ID** y **Client Secret** inmediatamente
   - No podrás ver el secret nuevamente
   - Guárdalos en tu archivo `.env`

### 2.2 Verificar permisos

Asegúrate de que el cliente tenga permisos para:
- Leer y escribir recursos `Observation`
- Leer y escribir recursos `Communication`
- Leer recursos `Patient` y `Practitioner`

## 📝 Paso 3: Crear el Bot en Medplum

### 3.1 Usar Medplum CLI

```bash
# Iniciar sesión en Medplum CLI
medplum login

# Desplegar el bot
medplum bot deploy send-blood-pressure-reminders.ts
```

### 3.2 Configurar el Bot en Medplum Console (Alternativa)

Si prefieres usar la interfaz web:

1. Ve a **Bots** en tu proyecto Medplum
2. Click en **Create new bot**
3. Configura:
   - **Name**: "Blood Pressure Reminder Bot"
   - **Description**: "Envía recordatorios de control de presión arterial"
   - **Code**: Copia y pega el contenido de `send-blood-pressure-reminders.ts`
4. Click en **Save**

### 3.3 Probar el Bot Manualmente

```bash
# Ejecutar el test script
npm run test
```

O desde Medplum Console:
1. Ve a tu bot
2. Click en **Execute**
3. En el campo de input, añade:
```json
{
  "daysToCheck": 7
}
```
4. Click en **Run**
5. Revisa los logs para verificar la ejecución

## ⏰ Paso 4: Programar Ejecución Automática

### 4.1 Crear un PlanDefinition para ejecución diaria

Crea un nuevo recurso en Medplum Console:

**ResourceType**: `PlanDefinition`

```json
{
  "resourceType": "PlanDefinition",
  "name": "BloodPressureReminderSchedule",
  "title": "Recordatorios Diarios de Presión Arterial",
  "status": "active",
  "description": "Ejecuta el bot de recordatorios de presión arterial todos los días a las 8:00 AM",
  "action": [
    {
      "title": "Ejecutar Bot de Presión Arterial",
      "trigger": [
        {
          "type": "periodic",
          "timingTiming": {
            "repeat": {
              "frequency": 1,
              "period": 1,
              "periodUnit": "d",
              "timeOfDay": ["08:00:00"]
            }
          }
        }
      ],
      "definitionCanonical": "Bot/[REEMPLAZA-CON-TU-BOT-ID]"
    }
  ]
}
```

**¡Importante!** Reemplaza `[REEMPLAZA-CON-TU-BOT-ID]` con el ID real de tu bot.

### 4.2 Verificar el Schedule

Puedes encontrar el ID de tu bot en:
1. Medplum Console → **Bots**
2. Click en tu bot
3. El ID aparece en la URL: `https://app.medplum.com/Bot/[ID-AQUI]`

### 4.3 Configuración de Zona Horaria

Para Argentina (UTC-3), ajusta el `timeOfDay`:
```json
"timeOfDay": ["08:00:00"]  // 8:00 AM hora local
```

## 🧪 Paso 5: Crear Datos de Prueba

### 5.1 Ejecutar el script de prueba

```bash
# Asegúrate de tener las variables de entorno configuradas
npm run test
```

Este script creará:
- 1 paciente de prueba
- 1 médico de prueba
- 2 observaciones de presión arterial (una normal, una elevada)
- 2 communications (recordatorios)

### 5.2 Verificar en Medplum Console

1. Ve a **Patients** → busca "María González"
2. Ve a **Observations** → filtra por código `85354-9`
3. Ve a **Communications** → verifica los recordatorios creados

## 📊 Paso 6: Monitoreo y Mantenimiento

### 6.1 Configurar Logs

En Medplum Console:
1. Ve a tu Bot
2. Click en **Logs** para ver la ejecución
3. Configura alertas si es necesario

### 6.2 Métricas a Monitorear

- Número de observaciones procesadas diarias
- Número de recordatorios enviados
- Tasa de errores
- Tiempo de ejecución del bot

### 6.3 Dashboard de Monitoreo

Puedes crear un dashboard con:
```typescript
import { getBloodPressureStats } from './integration-examples';

// Obtener estadísticas del último mes
const stats = await getBloodPressureStats(
  medplum,
  new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
  new Date()
);

console.log('Estadísticas del mes:');
console.log(`- Total de pacientes: ${stats.totalPatients}`);
console.log(`- Lecturas anormales: ${stats.abnormalReadings}`);
console.log(`- Recordatorios urgentes: ${stats.urgentReminders}`);
```

## 🔧 Paso 7: Integraciones Adicionales

### 7.1 Integrar con Twilio (SMS)

1. Crea una cuenta en Twilio
2. Obtén tus credenciales
3. Crea un bot secundario para enviar SMS:

```bash
# Crear bot de SMS
medplum bot create sms-notification-bot

# Configurar suscripción
# El bot se ejecutará automáticamente cuando se cree una Communication
```

### 7.2 Integrar con Portal del Paciente

Usa los ejemplos en `integration-examples.ts` para:
- Mostrar recordatorios en el portal
- Permitir que pacientes vean su historial de presión arterial
- Crear gráficos de tendencias

### 7.3 Webhooks para Sistemas Externos

Configura webhooks para notificar a sistemas externos (Slack, Teams, etc.):

```json
{
  "resourceType": "Subscription",
  "status": "active",
  "criteria": "Communication?topic=85354-9",
  "channel": {
    "type": "rest-hook",
    "endpoint": "https://tu-webhook.com/notifications"
  }
}
```

## ✅ Checklist Final de Despliegue

Antes de ir a producción, verifica:

- [ ] Bot desplegado y funcionando correctamente
- [ ] Schedule configurado con horario apropiado
- [ ] Datos de prueba creados y verificados
- [ ] Logs monitoreados sin errores
- [ ] Credenciales seguras (no en código fuente)
- [ ] Variables de entorno configuradas
- [ ] Documentación revisada
- [ ] Equipo entrenado en el uso del sistema
- [ ] Plan de respaldo en caso de fallos
- [ ] Cumplimiento con regulaciones de privacidad

## 🆘 Solución de Problemas

### Error: "Authentication failed"
**Solución**: Verifica tus credenciales en `.env`
```bash
# Re-login
medplum login
```

### Error: "Observation not found"
**Solución**: Asegúrate de que existen observaciones de presión arterial con código LOINC `85354-9`

### Bot no se ejecuta automáticamente
**Solución**: 
1. Verifica que el PlanDefinition esté en estado "active"
2. Confirma que el ID del bot es correcto en definitionCanonical
3. Revisa los logs del sistema

### Communications duplicadas
**Solución**: El bot ya incluye lógica para prevenir duplicados. Si ocurre:
1. Verifica que la búsqueda de Communications existentes funcione
2. Asegúrate de no ejecutar el bot manualmente mientras está programado

## 📞 Soporte

Si necesitas ayuda adicional:

- **Documentación Medplum**: https://www.medplum.com/docs
- **Foro Comunitario**: https://github.com/medplum/medplum/discussions
- **Soporte FHIR**: https://chat.fhir.org

## 🎉 ¡Felicitaciones!

Has desplegado exitosamente el bot de recordatorios de presión arterial. 

Próximos pasos recomendados:
1. Monitorea el bot durante la primera semana
2. Ajusta los rangos de presión arterial según necesites
3. Personaliza los mensajes para tu audiencia
4. Integra con sistemas de notificación (SMS, email)
5. Crea dashboards de análisis

---

**Última actualización**: Noviembre 2025
**Versión**: 1.0.0
