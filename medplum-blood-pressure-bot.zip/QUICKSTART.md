# 🚀 Inicio Rápido - Bot de Presión Arterial Medplum

## 📦 Paso 1: Descomprimir el Proyecto

```bash
unzip medplum-blood-pressure-bot.zip
cd medplum-blood-pressure-bot
```

## 📚 Paso 2: Leer la Documentación

Archivos clave para empezar:
1. **PROJECT_OVERVIEW.md** ← Empieza aquí para entender el proyecto
2. **README.md** ← Documentación técnica completa
3. **DEPLOYMENT.md** ← Guía paso a paso para producción

## ⚡ Paso 3: Setup Rápido (5 minutos)

```bash
# Instalar dependencias
npm install

# Configurar credenciales
cp .env.example .env
nano .env  # Agrega tus credenciales de Medplum

# Probar el bot
npm run test
```

## 🎯 ¿Qué hace este bot?

✅ Busca observaciones de presión arterial recientes  
✅ Detecta valores anormales (>140/90 mmHg)  
✅ Envía recordatorios personalizados a pacientes  
✅ Crea recursos FHIR R4 Communication  
✅ Prioriza notificaciones según urgencia  

## 📁 Archivos Principales

```
📦 Tu Proyecto
├── send-blood-pressure-reminders.ts  ⭐ BOT PRINCIPAL
├── test-bot.ts                       🧪 Script de prueba
├── integration-examples.ts           📚 Ejemplos de integración
├── package.json                      📦 Dependencias
├── tsconfig.json                     ⚙️ Config TypeScript
├── .env.example                      🔐 Template de variables
├── .gitignore                        🚫 Seguridad Git
├── README.md                         📖 Docs completas
├── DEPLOYMENT.md                     🚀 Guía de despliegue
└── PROJECT_OVERVIEW.md               🎯 Visión general
```

## 🔑 Obtener Credenciales de Medplum

1. Ve a https://app.medplum.com
2. Settings → Clients → Create new client
3. Copia Client ID y Client Secret
4. Pégalos en tu archivo `.env`

## 🧪 Probar el Bot

```bash
# El test script creará:
# - 1 paciente de prueba
# - 1 médico de prueba
# - 2 observaciones de presión arterial
# - 2 recordatorios (communications)

npm run test
```

## 🚀 Desplegar a Producción

```bash
# Login en Medplum CLI
medplum login

# Desplegar el bot
npm run deploy
```

Luego sigue la guía en **DEPLOYMENT.md** para:
- Configurar ejecución automática diaria
- Integrar con sistemas de notificación
- Configurar monitoreo

## 💡 Recursos de Ayuda

- 📖 Documentación completa: `README.md`
- 🚀 Guía de despliegue: `DEPLOYMENT.md`
- 🎯 Visión general: `PROJECT_OVERVIEW.md`
- 💻 Ejemplos de código: `integration-examples.ts`

## 🆘 Problemas Comunes

**Error de autenticación**
```bash
# Verifica credenciales en .env
medplum login
```

**Bot no encuentra observaciones**
```bash
# Ejecuta el test para crear datos de prueba
npm run test
```

**Falta alguna dependencia**
```bash
# Reinstalar
rm -rf node_modules package-lock.json
npm install
```

## 📊 Recursos FHIR Involucrados

- **Observation** (LOINC 85354-9): Blood Pressure Panel
- **Communication**: Recordatorios creados por el bot
- **Patient**: Información del paciente
- **Practitioner**: Médico tratante

## 🎉 ¡Listo para Empezar!

1. ✅ Descomprime el ZIP
2. ✅ Lee `PROJECT_OVERVIEW.md`
3. ✅ Configura `.env`
4. ✅ Ejecuta `npm run test`
5. ✅ Revisa los resultados en Medplum Console

---

**¿Preguntas?** Consulta la documentación completa en los archivos .md incluidos.

**Versión**: 1.0.0  
**Compatible con**: Medplum 3.x, FHIR R4  
**Licencia**: Apache-2.0
