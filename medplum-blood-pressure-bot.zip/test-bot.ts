/**
 * Script de prueba para el bot de recordatorios de presión arterial
 * Este archivo te permite crear datos de prueba y ejecutar el bot localmente
 */

import { MedplumClient } from '@medplum/core';
import type { Observation, Patient, Practitioner } from '@medplum/fhirtypes';

// Configuración de Medplum
const MEDPLUM_BASE_URL = process.env.MEDPLUM_BASE_URL || 'https://api.medplum.com';
const MEDPLUM_CLIENT_ID = process.env.MEDPLUM_CLIENT_ID || '';
const MEDPLUM_CLIENT_SECRET = process.env.MEDPLUM_CLIENT_SECRET || '';

/**
 * Crear paciente de prueba
 */
async function createTestPatient(medplum: MedplumClient): Promise<Patient> {
  return await medplum.createResource<Patient>({
    resourceType: 'Patient',
    name: [
      {
        given: ['María', 'Elena'],
        family: 'González',
      },
    ],
    telecom: [
      {
        system: 'phone',
        value: '+54 9 11 1234-5678',
        use: 'mobile',
      },
      {
        system: 'email',
        value: 'maria.gonzalez@example.com',
      },
    ],
    gender: 'female',
    birthDate: '1975-03-15',
    address: [
      {
        line: ['Av. Corrientes 1234'],
        city: 'Buenos Aires',
        state: 'CABA',
        postalCode: '1043',
        country: 'Argentina',
      },
    ],
  });
}

/**
 * Crear médico de prueba
 */
async function createTestPractitioner(medplum: MedplumClient): Promise<Practitioner> {
  return await medplum.createResource<Practitioner>({
    resourceType: 'Practitioner',
    name: [
      {
        given: ['Carlos'],
        family: 'Fernández',
        prefix: ['Dr.'],
      },
    ],
    telecom: [
      {
        system: 'phone',
        value: '+54 11 4321-8765',
        use: 'work',
      },
    ],
    qualification: [
      {
        code: {
          text: 'Cardiólogo',
        },
      },
    ],
  });
}

/**
 * Crear observación de presión arterial normal
 */
async function createNormalBPObservation(
  medplum: MedplumClient,
  patient: Patient,
  practitioner: Practitioner
): Promise<Observation> {
  return await medplum.createResource<Observation>({
    resourceType: 'Observation',
    status: 'final',
    category: [
      {
        coding: [
          {
            system: 'http://terminology.hl7.org/CodeSystem/observation-category',
            code: 'vital-signs',
            display: 'Vital Signs',
          },
        ],
      },
    ],
    code: {
      coding: [
        {
          system: 'http://loinc.org',
          code: '85354-9',
          display: 'Blood pressure panel',
        },
      ],
      text: 'Blood Pressure',
    },
    subject: {
      reference: `Patient/${patient.id}`,
      display: `${patient.name?.[0]?.given?.[0]} ${patient.name?.[0]?.family}`,
    },
    performer: [
      {
        reference: `Practitioner/${practitioner.id}`,
        display: `${practitioner.name?.[0]?.prefix?.[0]} ${practitioner.name?.[0]?.family}`,
      },
    ],
    effectiveDateTime: new Date().toISOString(),
    issued: new Date().toISOString(),
    component: [
      {
        code: {
          coding: [
            {
              system: 'http://loinc.org',
              code: '8480-6',
              display: 'Systolic blood pressure',
            },
          ],
        },
        valueQuantity: {
          value: 118,
          unit: 'mmHg',
          system: 'http://unitsofmeasure.org',
          code: 'mm[Hg]',
        },
      },
      {
        code: {
          coding: [
            {
              system: 'http://loinc.org',
              code: '8462-4',
              display: 'Diastolic blood pressure',
            },
          ],
        },
        valueQuantity: {
          value: 78,
          unit: 'mmHg',
          system: 'http://unitsofmeasure.org',
          code: 'mm[Hg]',
        },
      },
    ],
    interpretation: [
      {
        coding: [
          {
            system: 'http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation',
            code: 'N',
            display: 'Normal',
          },
        ],
      },
    ],
  });
}

/**
 * Crear observación de presión arterial elevada
 */
async function createHighBPObservation(
  medplum: MedplumClient,
  patient: Patient,
  practitioner: Practitioner
): Promise<Observation> {
  return await medplum.createResource<Observation>({
    resourceType: 'Observation',
    status: 'final',
    category: [
      {
        coding: [
          {
            system: 'http://terminology.hl7.org/CodeSystem/observation-category',
            code: 'vital-signs',
            display: 'Vital Signs',
          },
        ],
      },
    ],
    code: {
      coding: [
        {
          system: 'http://loinc.org',
          code: '85354-9',
          display: 'Blood pressure panel',
        },
      ],
      text: 'Blood Pressure',
    },
    subject: {
      reference: `Patient/${patient.id}`,
      display: `${patient.name?.[0]?.given?.[0]} ${patient.name?.[0]?.family}`,
    },
    performer: [
      {
        reference: `Practitioner/${practitioner.id}`,
        display: `${practitioner.name?.[0]?.prefix?.[0]} ${practitioner.name?.[0]?.family}`,
      },
    ],
    effectiveDateTime: new Date().toISOString(),
    issued: new Date().toISOString(),
    component: [
      {
        code: {
          coding: [
            {
              system: 'http://loinc.org',
              code: '8480-6',
              display: 'Systolic blood pressure',
            },
          ],
        },
        valueQuantity: {
          value: 152,
          unit: 'mmHg',
          system: 'http://unitsofmeasure.org',
          code: 'mm[Hg]',
        },
      },
      {
        code: {
          coding: [
            {
              system: 'http://loinc.org',
              code: '8462-4',
              display: 'Diastolic blood pressure',
            },
          ],
        },
        valueQuantity: {
          value: 94,
          unit: 'mmHg',
          system: 'http://unitsofmeasure.org',
          code: 'mm[Hg]',
        },
      },
    ],
    interpretation: [
      {
        coding: [
          {
            system: 'http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation',
            code: 'H',
            display: 'High',
          },
        ],
      },
    ],
  });
}

/**
 * Script principal de prueba
 */
async function main() {
  console.log('🏥 Iniciando prueba del bot de presión arterial...\n');

  // Inicializar cliente Medplum
  const medplum = new MedplumClient({
    baseUrl: MEDPLUM_BASE_URL,
    clientId: MEDPLUM_CLIENT_ID,
    clientSecret: MEDPLUM_CLIENT_SECRET,
  });

  try {
    // Autenticar
    console.log('🔐 Autenticando con Medplum...');
    await medplum.startClientLogin(MEDPLUM_CLIENT_ID, MEDPLUM_CLIENT_SECRET);
    console.log('✅ Autenticación exitosa\n');

    // Crear recursos de prueba
    console.log('👤 Creando paciente de prueba...');
    const patient = await createTestPatient(medplum);
    console.log(`✅ Paciente creado: ${patient.name?.[0]?.given?.[0]} ${patient.name?.[0]?.family} (${patient.id})\n`);

    console.log('👨‍⚕️ Creando médico de prueba...');
    const practitioner = await createTestPractitioner(medplum);
    console.log(`✅ Médico creado: ${practitioner.name?.[0]?.prefix?.[0]} ${practitioner.name?.[0]?.family} (${practitioner.id})\n`);

    // Crear observaciones de presión arterial
    console.log('📊 Creando observación de presión arterial normal...');
    const normalBP = await createNormalBPObservation(medplum, patient, practitioner);
    console.log(`✅ Observación creada: 118/78 mmHg (${normalBP.id})\n`);

    console.log('📊 Creando observación de presión arterial elevada...');
    const highBP = await createHighBPObservation(medplum, patient, practitioner);
    console.log(`✅ Observación creada: 152/94 mmHg (${highBP.id})\n`);

    // Ejecutar el bot
    console.log('🤖 Ejecutando bot de recordatorios...');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
    
    // Importar y ejecutar el handler del bot
    const { handler } = await import('./send-blood-pressure-reminders');
    const result = await handler(medplum, { input: { daysToCheck: 7 } });

    console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('✅ Bot ejecutado exitosamente');
    console.log(`📧 Communications creadas: ${result.entry?.filter(e => e.resource?.resourceType === 'Communication').length || 0}`);

    // Mostrar las Communications creadas
    console.log('\n📬 Communications generadas:\n');
    result.entry
      ?.filter(e => e.resource?.resourceType === 'Communication')
      .forEach((entry, index) => {
        const comm = entry.resource as any;
        console.log(`${index + 1}. Communication/${comm.id}`);
        console.log(`   Priority: ${comm.priority}`);
        console.log(`   Subject: ${comm.subject?.reference}`);
        console.log(`   About: ${comm.about?.[0]?.reference}`);
        console.log(`   Message preview: ${comm.payload?.[0]?.contentString?.substring(0, 100)}...`);
        console.log('');
      });

    console.log('🎉 Prueba completada exitosamente!');
    console.log('\n💡 Próximos pasos:');
    console.log('   1. Revisa las Communications creadas en Medplum Console');
    console.log('   2. Verifica los valores de presión arterial');
    console.log('   3. Configura el bot para ejecución automática diaria');

  } catch (error) {
    console.error('❌ Error durante la prueba:', error);
    process.exit(1);
  }
}

// Ejecutar el script
if (require.main === module) {
  main();
}
