// SPDX-FileCopyrightText: Copyright Orangebot, Inc. and Medplum contributors
// SPDX-License-Identifier: Apache-2.0
import { createReference, getDisplayString } from '@medplum/core';
import type { BotEvent, MedplumClient } from '@medplum/core';
import type { Observation, Reference, Patient, Practitioner, Bundle, Communication } from '@medplum/fhirtypes';

/**
 * Helper function to determine if blood pressure is abnormal
 * @param observation - Blood pressure observation
 * @returns true if blood pressure is outside normal ranges
 */
function isBloodPressureAbnormal(observation: Observation): boolean {
  if (!observation.component || observation.component.length < 2) {
    return false;
  }

  // Get systolic (component 0) and diastolic (component 1) values
  const systolic = observation.component.find((c) => 
    c.code.coding?.some((coding) => coding.code === '8480-6') // Systolic BP LOINC code
  );
  const diastolic = observation.component.find((c) => 
    c.code.coding?.some((coding) => coding.code === '8462-4') // Diastolic BP LOINC code
  );

  const systolicValue = systolic?.valueQuantity?.value;
  const diastolicValue = diastolic?.valueQuantity?.value;

  if (!systolicValue || !diastolicValue) {
    return false;
  }

  // Define abnormal ranges: Systolic > 140 or < 90, Diastolic > 90 or < 60
  return systolicValue > 140 || systolicValue < 90 || diastolicValue > 90 || diastolicValue < 60;
}

/**
 * Helper function to format blood pressure values
 * @param observation - Blood pressure observation
 * @returns Formatted string like "120/80 mmHg"
 */
function formatBloodPressure(observation: Observation): string {
  if (!observation.component || observation.component.length < 2) {
    return 'No disponible';
  }

  const systolic = observation.component.find((c) => 
    c.code.coding?.some((coding) => coding.code === '8480-6')
  );
  const diastolic = observation.component.find((c) => 
    c.code.coding?.some((coding) => coding.code === '8462-4')
  );

  const systolicValue = systolic?.valueQuantity?.value || '?';
  const diastolicValue = diastolic?.valueQuantity?.value || '?';
  const unit = systolic?.valueQuantity?.unit || 'mmHg';

  return `${systolicValue}/${diastolicValue} ${unit}`;
}

/**
 * Helper function to send a blood pressure control reminder.
 * Creates a Communication resource referencing the blood pressure Observation.
 * @param medplum - The Medplum client
 * @param observation - The blood pressure observation
 * @returns The created Communication resource
 */
async function sendBloodPressureReminder(
  medplum: MedplumClient, 
  observation: Observation
): Promise<Communication> {
  // Get patient details from the observation subject field
  const patientRef = observation.subject;
  if (!patientRef?.reference) {
    throw new Error('Patient not found on observation');
  }
  
  const patient = await medplum.readReference(patientRef as Reference<Patient>);
  const firstName = patient.name?.[0]?.given?.[0] || 'Estimado/a paciente';

  // Get practitioner details (if available from performer field)
  let providerName = 'su equipo médico';
  if (observation.performer && observation.performer.length > 0) {
    const practitionerRef = observation.performer.find((p) => 
      p.reference?.startsWith('Practitioner/')
    );
    
    if (practitionerRef) {
      try {
        const practitioner = await medplum.readReference(practitionerRef as Reference<Practitioner>);
        providerName = getDisplayString(practitioner) || providerName;
      } catch (err) {
        console.error('Failed to fetch practitioner:', err);
      }
    }
  }

  // Format observation date
  const observationDate = observation.effectiveDateTime 
    ? new Date(observation.effectiveDateTime).toLocaleDateString('es-AR', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      })
    : 'fecha reciente';

  // Get blood pressure values
  const bpValue = formatBloodPressure(observation);
  const isAbnormal = isBloodPressureAbnormal(observation);

  // Create personalized message based on BP status
  let message = `Hola ${firstName},\n\n`;
  
  if (isAbnormal) {
    message += `Le informamos que su última medición de presión arterial del ${observationDate} registró valores de ${bpValue}.\n\n`;
    message += `Estos valores están fuera del rango normal. Es importante que:\n`;
    message += `• Registre su presión arterial regularmente\n`;
    message += `• Mantenga un estilo de vida saludable\n`;
    message += `• Contacte a ${providerName} si presenta síntomas como dolor de cabeza, mareos o visión borrosa\n\n`;
    message += `Por favor, no dude en comunicarse con nosotros si tiene alguna duda.`;
  } else {
    message += `Le recordamos la importancia de realizar el control periódico de su presión arterial.\n\n`;
    message += `Su última medición del ${observationDate} fue de ${bpValue}.\n\n`;
    message += `Para mantener su salud cardiovascular, le recomendamos:\n`;
    message += `• Continuar con sus controles regulares\n`;
    message += `• Mantener una dieta balanceada y actividad física\n`;
    message += `• Registrar sus mediciones en casa si es posible\n\n`;
    message += `${providerName} está disponible para cualquier consulta.`;
  }

  // Create Communication resource with reference to the Observation
  const communication = await medplum.createResource<Communication>({
    resourceType: 'Communication',
    status: 'in-progress',
    subject: createReference(patient),
    sender: observation.performer?.[0] || { reference: 'Organization/default' },
    recipient: [createReference(patient)],
    payload: [
      {
        contentString: message,
      },
    ],
    category: [
      {
        coding: [
          {
            system: 'http://terminology.hl7.org/CodeSystem/communication-category',
            code: 'notification',
            display: 'Notification',
          },
        ],
      },
    ],
    priority: isAbnormal ? 'urgent' : 'routine',
    topic: {
      coding: [
        {
          system: 'http://loinc.org',
          code: '85354-9',
          display: 'Blood pressure panel',
        },
      ],
      text: 'Recordatorio de Control de Presión Arterial',
    },
    // Reference to the blood pressure observation
    about: [createReference(observation)],
    sent: new Date().toISOString(),
    extension: [
      {
        url: 'https://medplum.com/blood-pressure-reminder-sent',
        valueBoolean: true,
      },
      {
        url: 'https://medplum.com/blood-pressure-value',
        valueString: bpValue,
      },
      {
        url: 'https://medplum.com/blood-pressure-abnormal',
        valueBoolean: isAbnormal,
      },
    ],
  });

  return communication;
}

/**
 * Main bot handler to send blood pressure control reminders.
 * This bot searches for recent blood pressure observations and sends notifications to patients.
 * 
 * Two modes of operation:
 * 1. Check for abnormal blood pressure readings in the last 7 days (high priority)
 * 2. Send routine reminders for patients who need regular monitoring
 * 
 * Schedule this bot to run daily to keep patients informed about their BP control.
 * 
 * @param medplum - The Medplum client
 * @param event - The bot event (can include custom parameters)
 * @returns A Bundle containing the processed observations
 */
export async function handler(medplum: MedplumClient, event: BotEvent): Promise<Bundle> {
  // Get current time and time window for searching observations
  const now = new Date();
  const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

  // Custom parameter to define the search window (default: 7 days)
  const daysToCheck = event.input?.daysToCheck || 7;
  const searchFromDate = new Date(now.getTime() - daysToCheck * 24 * 60 * 60 * 1000);

  console.log(`Searching for blood pressure observations from ${searchFromDate.toISOString()}`);

  // Search for blood pressure observations in the specified time window
  // LOINC code 85354-9 is for Blood Pressure Panel
  const observations = await medplum.searchResources('Observation', {
    code: '85354-9', // Blood pressure panel LOINC code
    date: `ge${searchFromDate.toISOString()}`,
    _sort: '-date',
  });

  console.log(`Found ${observations.length} blood pressure observations`);

  const processedObservations: Observation[] = [];
  const sentCommunications: Communication[] = [];

  // Process each observation
  for (const observation of observations) {
    try {
      // Check if a reminder was already sent for this observation
      const existingCommunication = await medplum.searchResources('Communication', {
        about: `Observation/${observation.id}`,
        _count: 1,
      });

      if (existingCommunication.length > 0) {
        console.log(`Reminder already sent for observation ${observation.id}, skipping`);
        continue;
      }

      // Send reminder
      const communication = await sendBloodPressureReminder(medplum, observation);
      processedObservations.push(observation);
      sentCommunications.push(communication);
      
      const isAbnormal = isBloodPressureAbnormal(observation);
      console.log(
        `Sent ${isAbnormal ? 'URGENT' : 'routine'} reminder for observation ${observation.id} ` +
        `(Patient: ${observation.subject?.reference})`
      );
    } catch (err) {
      console.error(`Failed to send reminder for observation ${observation.id}:`, err);
    }
  }

  console.log(`Successfully sent ${sentCommunications.length} reminders`);

  // Return bundle with processed observations and created communications
  return {
    resourceType: 'Bundle',
    type: 'collection',
    total: processedObservations.length,
    entry: [
      ...processedObservations.map((obs) => ({
        resource: obs,
        fullUrl: `Observation/${obs.id}`,
      })),
      ...sentCommunications.map((comm) => ({
        resource: comm,
        fullUrl: `Communication/${comm.id}`,
      })),
    ],
  };
}
