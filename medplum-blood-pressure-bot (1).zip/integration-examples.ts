/**
 * Ejemplos de Integración - Bot de Presión Arterial
 * 
 * Este archivo contiene ejemplos de cómo integrar el bot de recordatorios
 * de presión arterial con otros sistemas y servicios.
 */

import { MedplumClient } from '@medplum/core';
import type { Communication, Patient, Observation } from '@medplum/fhirtypes';

// ============================================================================
// EJEMPLO 1: Consultar Communications de un Paciente
// ============================================================================

/**
 * Obtener todos los recordatorios de presión arterial de un paciente
 */
async function getPatientBloodPressureReminders(
  medplum: MedplumClient,
  patientId: string
): Promise<Communication[]> {
  const communications = await medplum.searchResources('Communication', {
    recipient: `Patient/${patientId}`,
    'topic': '85354-9', // LOINC code for Blood Pressure Panel
    _sort: '-sent',
    _count: 20,
  });

  return communications;
}

// ============================================================================
// EJEMPLO 2: Portal del Paciente - Mostrar Recordatorios Recientes
// ============================================================================

interface BloodPressureReminder {
  id: string;
  date: string;
  message: string;
  priority: 'urgent' | 'routine';
  bloodPressureValue: string;
  isAbnormal: boolean;
  observationId: string;
}

/**
 * Formatear Communications para mostrar en un portal de paciente
 */
async function getFormattedReminders(
  medplum: MedplumClient,
  patientId: string
): Promise<BloodPressureReminder[]> {
  const communications = await getPatientBloodPressureReminders(medplum, patientId);

  return communications.map((comm) => {
    const bpValue = comm.extension?.find(
      (ext) => ext.url === 'https://medplum.com/blood-pressure-value'
    )?.valueString || 'N/A';

    const isAbnormal = comm.extension?.find(
      (ext) => ext.url === 'https://medplum.com/blood-pressure-abnormal'
    )?.valueBoolean || false;

    return {
      id: comm.id || '',
      date: comm.sent || '',
      message: comm.payload?.[0]?.contentString || '',
      priority: (comm.priority as 'urgent' | 'routine') || 'routine',
      bloodPressureValue: bpValue,
      isAbnormal,
      observationId: comm.about?.[0]?.reference?.split('/')?.[1] || '',
    };
  });
}

// Ejemplo de uso en un componente React
const PatientRemindersExample = `
import React, { useEffect, useState } from 'react';
import { useMedplum } from '@medplum/react';

export function BloodPressureReminders({ patientId }) {
  const medplum = useMedplum();
  const [reminders, setReminders] = useState([]);

  useEffect(() => {
    async function loadReminders() {
      const data = await getFormattedReminders(medplum, patientId);
      setReminders(data);
    }
    loadReminders();
  }, [patientId]);

  return (
    <div className="reminders-container">
      <h2>Recordatorios de Presión Arterial</h2>
      {reminders.map((reminder) => (
        <div 
          key={reminder.id} 
          className={\`reminder \${reminder.priority}\`}
        >
          <div className="reminder-header">
            <span className="bp-value">{reminder.bloodPressureValue}</span>
            {reminder.isAbnormal && (
              <span className="badge urgent">⚠️ Atención</span>
            )}
          </div>
          <p>{reminder.message}</p>
          <small>{new Date(reminder.date).toLocaleDateString('es-AR')}</small>
        </div>
      ))}
    </div>
  );
}
`;

// ============================================================================
// EJEMPLO 3: Bot Secundario - Enviar SMS via Twilio
// ============================================================================

/**
 * Bot que escucha nuevas Communications y envía SMS
 * Este bot debe suscribirse a Communications con el tag "blood-pressure-reminder"
 */
async function sendSMSHandler(medplum: MedplumClient, event: any): Promise<void> {
  const communication = event.input as Communication;

  // Verificar que es un recordatorio de presión arterial
  const isBPReminder = communication.extension?.some(
    (ext) => ext.url === 'https://medplum.com/blood-pressure-reminder-sent'
  );

  if (!isBPReminder || communication.status === 'completed') {
    return;
  }

  // Obtener el paciente y su número de teléfono
  const patient = await medplum.readReference(communication.subject as any);
  const phoneNumber = patient.telecom?.find(
    (t) => t.system === 'phone' && t.use === 'mobile'
  )?.value;

  if (!phoneNumber) {
    console.log(`No phone number found for patient ${patient.id}`);
    return;
  }

  // Enviar SMS via Twilio (requiere configuración de Twilio)
  const message = communication.payload?.[0]?.contentString || '';
  
  // Código de ejemplo - requiere configuración real de Twilio
  /*
  const twilio = require('twilio')(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);
  
  await twilio.messages.create({
    body: message,
    from: TWILIO_PHONE_NUMBER,
    to: phoneNumber
  });
  */

  // Actualizar el estado de la Communication a 'completed'
  await medplum.updateResource({
    ...communication,
    status: 'completed',
    sent: new Date().toISOString(),
  });

  console.log(`SMS sent to ${phoneNumber} for Communication ${communication.id}`);
}

// ============================================================================
// EJEMPLO 4: Analítica - Dashboard de Presión Arterial
// ============================================================================

interface BloodPressureStats {
  totalPatients: number;
  abnormalReadings: number;
  normalReadings: number;
  urgentReminders: number;
  routineReminders: number;
  averageSystolic: number;
  averageDiastolic: number;
}

/**
 * Obtener estadísticas de presión arterial para un dashboard
 */
async function getBloodPressureStats(
  medplum: MedplumClient,
  startDate: Date,
  endDate: Date
): Promise<BloodPressureStats> {
  // Buscar todas las observaciones en el rango de fechas
  const observations = await medplum.searchResources('Observation', {
    code: '85354-9',
    date: `ge${startDate.toISOString()}`,
    _count: 1000,
  });

  // Buscar todas las communications en el mismo período
  const communications = await medplum.searchResources('Communication', {
    topic: '85354-9',
    sent: `ge${startDate.toISOString()}`,
    _count: 1000,
  });

  // Calcular estadísticas
  const uniquePatients = new Set(
    observations.map((obs) => obs.subject?.reference).filter(Boolean)
  );

  let totalSystolic = 0;
  let totalDiastolic = 0;
  let abnormalCount = 0;
  let normalCount = 0;

  observations.forEach((obs) => {
    const systolic = obs.component?.find(
      (c) => c.code.coding?.some((coding) => coding.code === '8480-6')
    )?.valueQuantity?.value;

    const diastolic = obs.component?.find(
      (c) => c.code.coding?.some((coding) => coding.code === '8462-4')
    )?.valueQuantity?.value;

    if (systolic && diastolic) {
      totalSystolic += systolic;
      totalDiastolic += diastolic;

      if (systolic > 140 || systolic < 90 || diastolic > 90 || diastolic < 60) {
        abnormalCount++;
      } else {
        normalCount++;
      }
    }
  });

  const urgentReminders = communications.filter((c) => c.priority === 'urgent').length;
  const routineReminders = communications.filter((c) => c.priority === 'routine').length;

  return {
    totalPatients: uniquePatients.size,
    abnormalReadings: abnormalCount,
    normalReadings: normalCount,
    urgentReminders,
    routineReminders,
    averageSystolic: observations.length > 0 ? totalSystolic / observations.length : 0,
    averageDiastolic: observations.length > 0 ? totalDiastolic / observations.length : 0,
  };
}

// ============================================================================
// EJEMPLO 5: Webhook - Integración con Sistemas Externos
// ============================================================================

/**
 * Endpoint webhook para recibir notificaciones de nuevas Communications
 * Puede ser usado para integrar con sistemas de terceros
 */
interface WebhookPayload {
  event: 'communication.created';
  resource: Communication;
  timestamp: string;
}

async function webhookHandler(payload: WebhookPayload): Promise<void> {
  const { resource: communication } = payload;

  // Verificar si es un recordatorio de presión arterial
  const isBPReminder = communication.extension?.some(
    (ext) => ext.url === 'https://medplum.com/blood-pressure-reminder-sent'
  );

  if (!isBPReminder) {
    return;
  }

  // Enviar a sistema externo (ejemplo: Slack, Microsoft Teams, etc.)
  const isAbnormal = communication.extension?.find(
    (ext) => ext.url === 'https://medplum.com/blood-pressure-abnormal'
  )?.valueBoolean;

  const bpValue = communication.extension?.find(
    (ext) => ext.url === 'https://medplum.com/blood-pressure-value'
  )?.valueString;

  // Ejemplo: enviar notificación a Slack
  /*
  await fetch(SLACK_WEBHOOK_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      text: isAbnormal 
        ? `⚠️ ALERTA: Presión arterial anormal detectada (${bpValue})`
        : `✅ Recordatorio de presión arterial enviado (${bpValue})`,
      attachments: [{
        color: isAbnormal ? 'danger' : 'good',
        fields: [
          { title: 'Paciente', value: communication.subject?.reference, short: true },
          { title: 'Valor', value: bpValue, short: true },
          { title: 'Prioridad', value: communication.priority, short: true },
        ]
      }]
    })
  });
  */

  console.log(`Webhook processed for Communication ${communication.id}`);
}

// ============================================================================
// EJEMPLO 6: Subscription - Suscripción Automática a Communications
// ============================================================================

/**
 * Crear una suscripción FHIR para recibir notificaciones automáticas
 * cuando se crean nuevas Communications de presión arterial
 */
async function createBloodPressureSubscription(medplum: MedplumClient): Promise<void> {
  await medplum.createResource({
    resourceType: 'Subscription',
    status: 'active',
    reason: 'Notificar nuevos recordatorios de presión arterial',
    criteria: 'Communication?topic=85354-9',
    channel: {
      type: 'rest-hook',
      endpoint: 'https://your-webhook-endpoint.com/blood-pressure-notifications',
      payload: 'application/fhir+json',
      header: ['Authorization: Bearer YOUR_API_KEY'],
    },
    extension: [
      {
        url: 'https://medplum.com/subscription-filter',
        valueString: 'extension.url="https://medplum.com/blood-pressure-reminder-sent"',
      },
    ],
  });

  console.log('Subscription created successfully');
}

// ============================================================================
// EJEMPLO 7: Reportes - Generar Reporte PDF de Presión Arterial
// ============================================================================

interface PatientBPReport {
  patient: Patient;
  observations: Observation[];
  communications: Communication[];
  summary: {
    totalReadings: number;
    abnormalReadings: number;
    averageSystolic: number;
    averageDiastolic: number;
    trend: 'improving' | 'stable' | 'worsening';
  };
}

/**
 * Generar un reporte completo de presión arterial para un paciente
 */
async function generatePatientBPReport(
  medplum: MedplumClient,
  patientId: string,
  startDate: Date,
  endDate: Date
): Promise<PatientBPReport> {
  const patient = await medplum.readResource('Patient', patientId);

  const observations = await medplum.searchResources('Observation', {
    subject: `Patient/${patientId}`,
    code: '85354-9',
    date: `ge${startDate.toISOString()}`,
    _sort: 'date',
    _count: 100,
  });

  const communications = await medplum.searchResources('Communication', {
    recipient: `Patient/${patientId}`,
    topic: '85354-9',
    sent: `ge${startDate.toISOString()}`,
    _sort: '-sent',
  });

  // Calcular promedios y tendencias
  let totalSystolic = 0;
  let totalDiastolic = 0;
  let abnormalCount = 0;

  observations.forEach((obs) => {
    const systolic = obs.component?.find(
      (c) => c.code.coding?.some((coding) => coding.code === '8480-6')
    )?.valueQuantity?.value;

    const diastolic = obs.component?.find(
      (c) => c.code.coding?.some((coding) => coding.code === '8462-4')
    )?.valueQuantity?.value;

    if (systolic && diastolic) {
      totalSystolic += systolic;
      totalDiastolic += diastolic;

      if (systolic > 140 || diastolic > 90) {
        abnormalCount++;
      }
    }
  });

  const avgSystolic = observations.length > 0 ? totalSystolic / observations.length : 0;
  const avgDiastolic = observations.length > 0 ? totalDiastolic / observations.length : 0;

  // Determinar tendencia (simplificado)
  const recentAvg = observations.slice(-3).reduce((sum, obs) => {
    const systolic = obs.component?.find(
      (c) => c.code.coding?.some((coding) => coding.code === '8480-6')
    )?.valueQuantity?.value || 0;
    return sum + systolic;
  }, 0) / Math.min(3, observations.length);

  let trend: 'improving' | 'stable' | 'worsening' = 'stable';
  if (recentAvg < avgSystolic - 5) trend = 'improving';
  if (recentAvg > avgSystolic + 5) trend = 'worsening';

  return {
    patient,
    observations,
    communications,
    summary: {
      totalReadings: observations.length,
      abnormalReadings: abnormalCount,
      averageSystolic: avgSystolic,
      averageDiastolic: avgDiastolic,
      trend,
    },
  };
}

// ============================================================================
// EXPORTAR EJEMPLOS
// ============================================================================

export {
  getPatientBloodPressureReminders,
  getFormattedReminders,
  sendSMSHandler,
  getBloodPressureStats,
  webhookHandler,
  createBloodPressureSubscription,
  generatePatientBPReport,
};

// Nota: Estos son ejemplos conceptuales. 
// Para implementación en producción, asegúrate de:
// - Manejar errores adecuadamente
// - Implementar autenticación y autorización
// - Validar datos de entrada
// - Usar variables de entorno para configuración
// - Cumplir con regulaciones de privacidad (HIPAA, GDPR, etc.)
