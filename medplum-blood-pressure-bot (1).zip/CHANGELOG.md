# Changelog

Historial de cambios del proyecto Bot de Presión Arterial Medplum.

## [1.0.1] - 2025-11-04

### 🐛 Correcciones

- **test-bot.ts**: Corregido error de TypeScript al pasar `BotEvent` incompleto
  - Agregadas propiedades requeridas: `bot`, `contentType`, `secrets`
  - El objeto `BotEvent` ahora cumple con la interfaz completa de Medplum
  
- **send-blood-pressure-reminders.ts**: Mejorado manejo del input del evento
  - Cambiado de `event.input?.daysToCheck` a verificación de tipo segura
  - Ahora maneja correctamente cuando `event.input` puede ser de diferentes tipos

### 📝 Detalles Técnicos

**Antes:**
```typescript
// ❌ Error: Propiedades faltantes en BotEvent
const result = await handler(medplum, { input: { daysToCheck: 7 } });

// ❌ Acceso directo sin type checking
const daysToCheck = event.input?.daysToCheck || 7;
```

**Después:**
```typescript
// ✅ BotEvent completo
const botEvent = {
  bot: { reference: 'Bot/test-bot' },
  contentType: 'application/json',
  input: { daysToCheck: 7 },
  secrets: {}
};
const result = await handler(medplum, botEvent);

// ✅ Type-safe access
const input = typeof event.input === 'object' ? event.input as Record<string, any> : {};
const daysToCheck = input.daysToCheck || 7;
```

### ✅ Verificación

```bash
# Ahora debería funcionar sin errores
npm run test
```

---

## [1.0.0] - 2025-11-04

### 🎉 Lanzamiento Inicial

- Bot completo de recordatorios de presión arterial
- Integración con recursos FHIR R4 (Observation, Communication)
- Detección automática de valores anormales
- Mensajes personalizados en español
- Scripts de prueba y ejemplos de integración
- Documentación completa (README, DEPLOYMENT, QUICKSTART)

### 📦 Archivos Incluidos

- `send-blood-pressure-reminders.ts` - Bot principal
- `test-bot.ts` - Script de prueba
- `integration-examples.ts` - Ejemplos de integración
- `package.json` - Configuración del proyecto
- `tsconfig.json` - Configuración TypeScript
- `.env.example` - Template de variables de entorno
- `.gitignore` - Archivos a ignorar
- `README.md` - Documentación completa
- `DEPLOYMENT.md` - Guía de despliegue
- `PROJECT_OVERVIEW.md` - Visión general
- `QUICKSTART.md` - Inicio rápido

### 🎯 Funcionalidades

- ✅ Búsqueda de observaciones de presión arterial
- ✅ Detección de valores anormales (>140/90 o <90/60 mmHg)
- ✅ Creación de recursos Communication FHIR R4
- ✅ Prevención de recordatorios duplicados
- ✅ Priorización automática (urgent/routine)
- ✅ Mensajes personalizados
- ✅ Soporte para Argentina (español)

---

## Formato

Este changelog sigue las convenciones de [Keep a Changelog](https://keepachangelog.com/es-ES/1.0.0/)
y el proyecto adhiere a [Semantic Versioning](https://semver.org/lang/es/).

### Tipos de Cambios

- **Added** (Agregado): para nuevas funcionalidades
- **Changed** (Cambiado): para cambios en funcionalidades existentes
- **Deprecated** (Obsoleto): para funcionalidades que serán removidas
- **Removed** (Removido): para funcionalidades removidas
- **Fixed** (Corregido): para corrección de errores
- **Security** (Seguridad): para vulnerabilidades
