# Bot de Recordatorios de Control de Presión Arterial

Bot de Medplum para enviar notificaciones automáticas a pacientes sobre el control de presión arterial, basado en recursos FHIR R4.

## 📋 Descripción

Este bot busca observaciones de presión arterial recientes y envía recordatorios personalizados a los pacientes mediante recursos `Communication`. Las notificaciones varían según si los valores son normales o anormales.

## 🎯 Funcionalidades

- ✅ Busca observaciones de presión arterial en los últimos 7 días (configurable)
- ✅ Detecta valores de presión arterial anormales (>140/90 o <90/60 mmHg)
- ✅ Crea recursos `Communication` FHIR R4 con referencia a `Observation`
- ✅ Mensajes personalizados según el estado de la presión arterial
- ✅ Prioridad "urgent" para valores anormales, "routine" para normales
- ✅ Previene envío de recordatorios duplicados
- ✅ Soporte para pacientes en español (Argentina)

## 📦 Recursos FHIR Utilizados

### Observation (Blood Pressure)
```typescript
{
  resourceType: 'Observation',
  code: {
    coding: [{
      system: 'http://loinc.org',
      code: '85354-9',  // Blood pressure panel
      display: 'Blood pressure panel'
    }]
  },
  component: [
    {
      code: {
        coding: [{
          system: 'http://loinc.org',
          code: '8480-6',  // Systolic BP
          display: 'Systolic blood pressure'
        }]
      },
      valueQuantity: { value: 120, unit: 'mmHg' }
    },
    {
      code: {
        coding: [{
          system: 'http://loinc.org',
          code: '8462-4',  // Diastolic BP
          display: 'Diastolic blood pressure'
        }]
      },
      valueQuantity: { value: 80, unit: 'mmHg' }
    }
  ],
  subject: { reference: 'Patient/123' },
  effectiveDateTime: '2025-11-04T10:00:00Z'
}
```

### Communication (creada por el bot)
```typescript
{
  resourceType: 'Communication',
  status: 'in-progress',
  priority: 'urgent' | 'routine',
  subject: { reference: 'Patient/123' },
  about: [{ reference: 'Observation/456' }],  // ← Referencia a la observación
  topic: {
    coding: [{
      system: 'http://loinc.org',
      code: '85354-9',
      display: 'Blood pressure panel'
    }]
  },
  payload: [{
    contentString: 'Mensaje personalizado...'
  }]
}
```

## 🚀 Instalación

### 1. Crear el Bot en Medplum

```bash
# Instalar Medplum CLI
npm install -g @medplum/cli

# Iniciar sesión
medplum login

# Desplegar el bot
medplum bot deploy send-blood-pressure-reminders.ts
```

### 2. Configurar en Medplum Console

1. Ve a **Bots** en tu proyecto Medplum
2. Crea un nuevo Bot
3. Sube el archivo `send-blood-pressure-reminders.ts`
4. Guarda y activa el bot

### 3. Programar Ejecución Automática

Configura una tarea programada (cron job) para ejecutar el bot diariamente:

```json
{
  "resourceType": "PlanDefinition",
  "status": "active",
  "action": [{
    "trigger": [{
      "type": "periodic",
      "timingTiming": {
        "repeat": {
          "frequency": 1,
          "period": 1,
          "periodUnit": "d",
          "timeOfDay": ["08:00:00"]
        }
      }
    }],
    "definitionCanonical": "Bot/[BOT-ID]"
  }]
}
```

## ⚙️ Configuración

### Parámetros del Bot

Puedes personalizar el comportamiento del bot mediante el objeto `event.input`:

```typescript
{
  "daysToCheck": 7  // Número de días hacia atrás para buscar observaciones
}
```

### Rangos de Presión Arterial

El bot considera valores anormales cuando:
- **Sistólica**: > 140 mmHg o < 90 mmHg
- **Diastólica**: > 90 mmHg o < 60 mmHg

Puedes modificar estos valores en la función `isBloodPressureAbnormal()`.

## 📊 Ejemplo de Uso

### Escenario 1: Presión Arterial Normal

**Observation registrada:**
- Sistólica: 120 mmHg
- Diastólica: 80 mmHg
- Fecha: 2025-11-01

**Communication creada:**
```
Hola María,

Le recordamos la importancia de realizar el control periódico de su presión arterial.

Su última medición del lunes, 1 de noviembre de 2025 fue de 120/80 mmHg.

Para mantener su salud cardiovascular, le recomendamos:
• Continuar con sus controles regulares
• Mantener una dieta balanceada y actividad física
• Registrar sus mediciones en casa si es posible

Dr. González está disponible para cualquier consulta.
```
**Priority:** `routine`

### Escenario 2: Presión Arterial Elevada

**Observation registrada:**
- Sistólica: 155 mmHg
- Diastólica: 95 mmHg
- Fecha: 2025-11-03

**Communication creada:**
```
Hola Juan,

Le informamos que su última medición de presión arterial del viernes, 3 de noviembre de 2025 registró valores de 155/95 mmHg.

Estos valores están fuera del rango normal. Es importante que:
• Registre su presión arterial regularmente
• Mantenga un estilo de vida saludable
• Contacte a Dr. González si presenta síntomas como dolor de cabeza, mareos o visión borrosa

Por favor, no dude en comunicarse con nosotros si tiene alguna duda.
```
**Priority:** `urgent`

## 🔄 Integración con Otros Sistemas

### Envío de SMS/Email

Puedes crear un bot secundario que se suscriba a los recursos `Communication` creados y envíe notificaciones por SMS (Twilio) o email:

```typescript
// Bot subscription
{
  "resourceType": "Subscription",
  "status": "active",
  "criteria": "Communication?_tag=blood-pressure-reminder",
  "channel": {
    "type": "rest-hook",
    "endpoint": "Bot/[SMS-BOT-ID]"
  }
}
```

### Integración con Portal del Paciente

Los pacientes pueden ver sus `Communication` en un portal personalizado:

```typescript
const communications = await medplum.search('Communication', {
  recipient: `Patient/${patientId}`,
  topic: '85354-9',
  _sort: '-sent'
});
```

## 📈 Monitoreo y Logs

El bot registra información detallada en la consola:

```
Searching for blood pressure observations from 2025-10-28T10:00:00Z
Found 15 blood pressure observations
Sent URGENT reminder for observation obs-123 (Patient: Patient/patient-456)
Sent routine reminder for observation obs-124 (Patient: Patient/patient-789)
Reminder already sent for observation obs-125, skipping
Successfully sent 12 reminders
```

## 🧪 Testing

### Crear una Observation de Prueba

```typescript
const testObservation = await medplum.createResource({
  resourceType: 'Observation',
  status: 'final',
  code: {
    coding: [{
      system: 'http://loinc.org',
      code: '85354-9',
      display: 'Blood pressure panel'
    }]
  },
  component: [
    {
      code: {
        coding: [{
          system: 'http://loinc.org',
          code: '8480-6'
        }]
      },
      valueQuantity: { value: 145, unit: 'mmHg' }
    },
    {
      code: {
        coding: [{
          system: 'http://loinc.org',
          code: '8462-4'
        }]
      },
      valueQuantity: { value: 92, unit: 'mmHg' }
    }
  ],
  subject: { reference: 'Patient/test-patient-123' },
  effectiveDateTime: new Date().toISOString()
});
```

### Ejecutar el Bot Manualmente

```typescript
const result = await medplum.executeBot(
  { reference: 'Bot/blood-pressure-reminder-bot' },
  { daysToCheck: 7 }
);
console.log(result);
```

## 🛠️ Personalización

### Cambiar el Idioma de los Mensajes

Modifica la función `sendBloodPressureReminder()` para cambiar los textos:

```typescript
let message = `Hello ${firstName},\n\n`;
message += `Your last blood pressure reading on ${observationDate} was ${bpValue}.\n\n`;
// ... resto del mensaje en inglés
```

### Ajustar los Criterios de Búsqueda

Modifica el handler principal para buscar por otros criterios:

```typescript
const observations = await medplum.searchResources('Observation', {
  code: '85354-9',
  date: `ge${searchFromDate.toISOString()}`,
  status: 'final',  // ← Solo observaciones finales
  'value-quantity': 'gt140'  // ← Filtrar por valor
});
```

## 📚 Referencias

- [Medplum Bot Documentation](https://www.medplum.com/docs/bots)
- [FHIR Observation Resource](https://www.hl7.org/fhir/observation.html)
- [FHIR Communication Resource](https://www.hl7.org/fhir/communication.html)
- [LOINC Blood Pressure Codes](https://loinc.org/)

## 🤝 Contribuciones

Si encuentras mejoras o tienes sugerencias, no dudes en compartirlas.

## 📄 Licencia

Apache-2.0

---

**Nota**: Este bot está diseñado para enviar recordatorios informativos. No reemplaza el juicio clínico profesional. Los valores de presión arterial anormales deben ser evaluados por un profesional de la salud.
