# 🏥 Bot de Presión Arterial para Medplum - Visión General del Proyecto

## 📁 Estructura del Proyecto

```
medplum-blood-pressure-bot/
├── send-blood-pressure-reminders.ts  # ⭐ Bot principal
├── test-bot.ts                       # 🧪 Script de prueba
├── integration-examples.ts           # 📚 Ejemplos de integración
├── package.json                      # 📦 Configuración NPM
├── tsconfig.json                     # ⚙️ Configuración TypeScript
├── .env.example                      # 🔐 Template de variables de entorno
├── .gitignore                        # 🚫 Archivos a ignorar en Git
├── README.md                         # 📖 Documentación principal
└── DEPLOYMENT.md                     # 🚀 Guía de despliegue
```

## 📄 Descripción de Archivos

### ⭐ `send-blood-pressure-reminders.ts` (ARCHIVO PRINCIPAL)

**Propósito**: Bot principal que busca observaciones de presión arterial y envía recordatorios a pacientes.

**Características clave**:
- ✅ Busca `Observation` de presión arterial (código LOINC `85354-9`)
- ✅ Detecta valores anormales (>140/90 o <90/60 mmHg)
- ✅ Crea recursos `Communication` FHIR R4
- ✅ Mensajes personalizados en español (Argentina)
- ✅ Previene recordatorios duplicados
- ✅ Prioridad automática según valores (urgent/routine)

**Funciones principales**:
```typescript
- handler(): Función principal del bot
- sendBloodPressureReminder(): Crea Communications
- isBloodPressureAbnormal(): Valida rangos de presión
- formatBloodPressure(): Formatea valores para mostrar
```

**Recursos FHIR involucrados**:
- **Input**: `Observation` (Blood Pressure Panel - LOINC 85354-9)
- **Output**: `Communication` con referencia a `Observation`
- **Referencias**: `Patient`, `Practitioner`

---

### 🧪 `test-bot.ts`

**Propósito**: Script para probar el bot localmente antes del despliegue.

**Qué hace**:
1. Crea un paciente de prueba (María Elena González)
2. Crea un médico de prueba (Dr. Carlos Fernández)
3. Crea 2 observaciones de presión arterial:
   - Una normal (118/78 mmHg)
   - Una elevada (152/94 mmHg)
4. Ejecuta el bot
5. Muestra las Communications generadas

**Cómo usar**:
```bash
# Configurar variables de entorno
cp .env.example .env
nano .env  # Agregar credenciales

# Ejecutar prueba
npm run test
```

**Salida esperada**:
```
🏥 Iniciando prueba del bot de presión arterial...
✅ Paciente creado: María Elena González
✅ Médico creado: Dr. Carlos Fernández
✅ Observación creada: 118/78 mmHg
✅ Observación creada: 152/94 mmHg
🤖 Ejecutando bot...
📧 Communications creadas: 2
🎉 Prueba completada exitosamente!
```

---

### 📚 `integration-examples.ts`

**Propósito**: Ejemplos de código para integrar el bot con otros sistemas.

**Ejemplos incluidos**:

1. **Portal del Paciente**: Mostrar recordatorios en una app
2. **Bot de SMS**: Enviar notificaciones por Twilio
3. **Dashboard de Analytics**: Estadísticas de presión arterial
4. **Webhooks**: Integración con sistemas externos
5. **Subscriptions FHIR**: Notificaciones automáticas
6. **Reportes**: Generar informes PDF

**Cómo usar**:
```typescript
import { getFormattedReminders } from './integration-examples';

// Obtener recordatorios de un paciente
const reminders = await getFormattedReminders(medplum, 'patient-123');
```

---

### 📦 `package.json`

**Propósito**: Configuración del proyecto Node.js y dependencias.

**Dependencias**:
- `@medplum/core`: SDK principal de Medplum
- `@medplum/fhirtypes`: Tipos TypeScript para FHIR R4

**Scripts disponibles**:
```bash
npm run build      # Compilar TypeScript
npm run deploy     # Desplegar bot a Medplum
npm run test       # Ejecutar pruebas
```

---

### ⚙️ `tsconfig.json`

**Propósito**: Configuración del compilador TypeScript.

**Características**:
- Target: ES2020
- Strict mode activado
- Source maps habilitados
- Declaraciones de tipos generadas

---

### 🔐 `.env.example`

**Propósito**: Template para variables de entorno.

**Variables requeridas**:
```env
MEDPLUM_BASE_URL=https://api.medplum.com
MEDPLUM_CLIENT_ID=tu-client-id
MEDPLUM_CLIENT_SECRET=tu-secret
```

**Cómo usar**:
```bash
cp .env.example .env
# Editar .env con tus credenciales reales
```

**⚠️ IMPORTANTE**: Nunca commitear el archivo `.env` a Git.

---

### 🚫 `.gitignore`

**Propósito**: Prevenir que archivos sensibles se suban a Git.

**Archivos ignorados**:
- `node_modules/`
- `.env` y variantes
- Archivos compilados (`*.js`, `*.d.ts`)
- Logs
- Build outputs

---

### 📖 `README.md`

**Propósito**: Documentación completa del proyecto.

**Secciones**:
- 📋 Descripción general
- 🎯 Funcionalidades
- 📦 Recursos FHIR utilizados
- 🚀 Instalación
- ⚙️ Configuración
- 📊 Ejemplos de uso
- 🔄 Integraciones
- 📈 Monitoreo
- 🧪 Testing

---

### 🚀 `DEPLOYMENT.md`

**Propósito**: Guía paso a paso para desplegar el bot en producción.

**Pasos incluidos**:
1. ✅ Pre-requisitos
2. ⚙️ Configuración del proyecto
3. 🔑 Obtener credenciales de Medplum
4. 📝 Crear el bot en Medplum
5. ⏰ Programar ejecución automática
6. 🧪 Crear datos de prueba
7. 📊 Configurar monitoreo
8. 🔧 Integraciones adicionales
9. ✅ Checklist final
10. 🆘 Solución de problemas

---

## 🔄 Flujo de Trabajo del Bot

```
┌─────────────────────────────────────────────────────────────┐
│ 1. TRIGGER (Ejecución Diaria a las 8:00 AM)                │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ 2. BUSCAR OBSERVATIONS                                      │
│    - Código LOINC: 85354-9 (Blood Pressure Panel)          │
│    - Últimos 7 días (configurable)                         │
│    - Estado: final                                          │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ 3. PARA CADA OBSERVATION                                    │
│    ├─ Verificar si ya existe Communication                 │
│    ├─ Si existe → Skip                                     │
│    └─ Si no existe → Continuar                             │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ 4. OBTENER DATOS DEL PACIENTE                               │
│    - Leer Patient desde subject                            │
│    - Obtener nombre, datos de contacto                     │
│    - Obtener Practitioner (si está disponible)             │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ 5. ANALIZAR VALORES DE PRESIÓN ARTERIAL                    │
│    - Extraer systolic (8480-6) y diastolic (8462-4)       │
│    - ¿Anormal? Sistólica >140 o <90, Diastólica >90 o <60 │
│    - Formatear valor: "120/80 mmHg"                        │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ 6. CREAR MENSAJE PERSONALIZADO                             │
│    ├─ Si ANORMAL → Mensaje de alerta + prioridad "urgent" │
│    └─ Si NORMAL → Mensaje de recordatorio + "routine"     │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ 7. CREAR COMMUNICATION                                      │
│    - resourceType: Communication                           │
│    - status: in-progress                                   │
│    - subject: Patient reference                            │
│    - about: Observation reference ⭐                       │
│    - payload: Mensaje personalizado                        │
│    - priority: urgent | routine                            │
│    - extensions: metadata adicional                        │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ 8. LOGGING Y RETORNO                                        │
│    - Log de Communications creadas                         │
│    - Retornar Bundle con resultados                        │
│    - Métricas para monitoreo                               │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎯 Casos de Uso

### Caso 1: Paciente con Presión Normal
**Entrada**: Observation con 118/78 mmHg  
**Salida**: Communication con prioridad "routine"  
**Mensaje**: Recordatorio preventivo con consejos de salud

### Caso 2: Paciente con Presión Elevada
**Entrada**: Observation con 155/95 mmHg  
**Salida**: Communication con prioridad "urgent"  
**Mensaje**: Alerta + recomendaciones + contactar médico

### Caso 3: Sin Observaciones Recientes
**Entrada**: No hay Observations en últimos 7 días  
**Salida**: No se crean Communications  
**Acción**: El bot termina sin errores

### Caso 4: Communication Ya Existe
**Entrada**: Observation con Communication previa  
**Salida**: Se omite (skip)  
**Acción**: Previene duplicados

---

## 🔌 Integraciones Posibles

### 📱 Notificaciones
- **SMS**: Twilio, AWS SNS
- **Email**: SendGrid, AWS SES
- **Push**: Firebase, OneSignal

### 📊 Analytics
- **Dashboards**: Grafana, PowerBI
- **Métricas**: Prometheus, DataDog
- **Reportes**: PDF con jsPDF

### 🏥 Sistemas de Salud
- **EHR**: Epic, Cerner
- **Telemedicina**: Doxy.me
- **Dispositivos**: Omron, Withings

### 💬 Comunicación
- **Chat**: Slack, Microsoft Teams
- **CRM**: Salesforce Health Cloud
- **Portal**: Aplicación React/Next.js

---

## 📊 Métricas Clave

El bot rastrea:
- ✅ Observations procesadas
- ✅ Communications creadas
- ✅ % de presiones anormales
- ✅ Tiempo de ejecución
- ✅ Errores y excepciones

---

## 🔒 Seguridad y Cumplimiento

✅ Cumple con FHIR R4  
✅ Compatible con HIPAA (con configuración adecuada)  
✅ Autenticación OAuth 2.0  
✅ Encriptación en tránsito (HTTPS)  
✅ No almacena credenciales en código  
✅ Logs sin PHI sensible  

---

## 🚀 Inicio Rápido

```bash
# 1. Instalar dependencias
npm install

# 2. Configurar entorno
cp .env.example .env
# Editar .env con tus credenciales

# 3. Probar localmente
npm run test

# 4. Desplegar a Medplum
npm run deploy
```

---

## 📞 Soporte

- 📚 Documentación: Ver `README.md`
- 🚀 Despliegue: Ver `DEPLOYMENT.md`
- 💡 Ejemplos: Ver `integration-examples.ts`
- 🐛 Issues: GitHub Issues
- 💬 Comunidad: Medplum Discord

---

## 📝 Licencia

Apache-2.0

---

**Versión**: 1.0.0  
**Última actualización**: Noviembre 2025  
**Autor**: Creado con Claude 4 Sonnet  
**Basado en**: Medplum Demo Bots
