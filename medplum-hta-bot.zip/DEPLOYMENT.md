# Guía de Despliegue - Bot HTA en Medplum

Esta guía proporciona instrucciones paso a paso para desplegar el Bot de Hipertensión Arterial en su instancia de Medplum.

## 📋 Pre-requisitos

Antes de comenzar, asegúrese de tener:

- ✅ Acceso a https://api.epa-bienestar.com.ar/fhir/r4
- ✅ Credenciales de administrador de Medplum
- ✅ Node.js versión 22 o superior instalado
- ✅ Git instalado (opcional, para clonar el repositorio)

## 🔧 Paso 1: Preparación del Código

### 1.1 Instalar Dependencias

```bash
cd /ruta/al/proyecto/medplum-hta-bot
npm install
```

### 1.2 Compilar el Código TypeScript

```bash
npm run build
```

Esto generará el archivo `dist/index.js` que será desplegado en Medplum.

### 1.3 Verificar la Compilación

```bash
ls -la dist/
# Debería ver index.js y otros archivos compilados
```

## 🚀 Paso 2: Configuración en Medplum

### Opción A: Despliegue desde la Interfaz Web

#### 2.1 Acceder a Medplum

1. Abra su navegador y vaya a: https://app.medplum.com
2. Inicie sesión con sus credenciales de administrador
3. Seleccione su proyecto: **EPA Bienestar**

#### 2.2 Crear el Bot

1. En el menú lateral, navegue a: **Project** → **Bots**
2. Haga clic en **Create New Bot**
3. Complete los campos:
   - **Name**: `HTA Alert Bot`
   - **Description**: `Bot automático para detección de Hipertensión Arterial no controlada`
   - **Runtime Version**: `awslambda` (por defecto)

#### 2.3 Cargar el Código

1. Abra el archivo `dist/index.js` en un editor de texto
2. Copie todo el contenido
3. Pegue el código en el editor de código del Bot en Medplum
4. Haga clic en **Save**

#### 2.4 Configurar la Subscription (Trigger)

1. Dentro de la configuración del Bot, vaya a **Subscriptions**
2. Haga clic en **Create Subscription**
3. Configure los siguientes campos:

```json
{
  "resourceType": "Subscription",
  "status": "active",
  "reason": "Monitoreo de Presión Arterial para detección de HTA crítica",
  "criteria": "Observation?code=http://loinc.org|85354-9,http://loinc.org|8480-6,http://loinc.org|8462-4",
  "channel": {
    "type": "rest-hook",
    "endpoint": "Bot/[BOT-ID]"
  }
}
```

> **Nota**: Reemplace `[BOT-ID]` con el ID real de su Bot.

4. Haga clic en **Save Subscription**

### Opción B: Despliegue con Medplum CLI

#### 2.1 Instalar Medplum CLI

```bash
npm install -g @medplum/cli
```

#### 2.2 Configurar Credenciales

```bash
medplum login

# Se le solicitará:
# - Server URL: https://api.epa-bienestar.com.ar
# - Client ID: [su client ID]
# - Client Secret: [su client secret]
```

#### 2.3 Crear archivo de configuración

Cree o edite el archivo `medplum.config.json`:

```json
{
  "bots": [
    {
      "name": "HTA Alert Bot",
      "id": "hta-alert-bot",
      "description": "Bot automático para detección de Hipertensión Arterial no controlada",
      "source": "dist/index.js",
      "criteria": "Observation?code=http://loinc.org|85354-9,http://loinc.org|8480-6,http://loinc.org|8462-4"
    }
  ]
}
```

#### 2.4 Desplegar el Bot

```bash
medplum bot deploy hta-alert-bot
```

## 🧪 Paso 3: Testing del Bot

### 3.1 Crear un Patient de Prueba (si no existe)

```bash
curl -X POST https://api.epa-bienestar.com.ar/fhir/r4/Patient \
  -H "Content-Type: application/fhir+json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "resourceType": "Patient",
    "name": [{
      "family": "Prueba",
      "given": ["María", "Test"]
    }],
    "gender": "female",
    "birthDate": "1965-03-15"
  }'
```

Guarde el ID del Patient creado.

### 3.2 Crear un Practitioner de Prueba (si no existe)

```bash
curl -X POST https://api.epa-bienestar.com.ar/fhir/r4/Practitioner \
  -H "Content-Type: application/fhir+json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "resourceType": "Practitioner",
    "name": [{
      "family": "Pérez",
      "given": ["Juan"],
      "prefix": ["Dr."]
    }],
    "active": true
  }'
```

### 3.3 Probar con HTA Stage 2 (≥160/100)

Use el archivo de ejemplo `examples/test-observation.json`:

```bash
curl -X POST https://api.epa-bienestar.com.ar/fhir/r4/Observation \
  -H "Content-Type: application/fhir+json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d @examples/test-observation.json
```

### 3.4 Verificar que se crearon los recursos

#### Verificar Communication

```bash
curl -X GET "https://api.epa-bienestar.com.ar/fhir/r4/Communication?_tag=hta-alert&_sort=-_lastUpdated&_count=1" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

Debería ver un Communication con prioridad "urgent" y el mensaje de alerta.

#### Verificar Task

```bash
curl -X GET "https://api.epa-bienestar.com.ar/fhir/r4/Task?_tag=hta-followup&status=requested&_sort=-_lastUpdated&_count=1" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

Debería ver un Task con status "requested" y prioridad "urgent".

### 3.5 Probar con Crisis Hipertensiva (≥180/120)

```bash
curl -X POST https://api.epa-bienestar.com.ar/fhir/r4/Observation \
  -H "Content-Type: application/fhir+json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d @examples/test-crisis.json
```

Verifique que se genere una alerta con prioridad "stat" (emergencia).

## 📊 Paso 4: Monitoreo y Logs

### 4.1 Ver Logs del Bot (Interfaz Web)

1. Vaya a **Project** → **Bots** → **HTA Alert Bot**
2. Haga clic en **Logs**
3. Filtre por fecha/hora para ver las ejecuciones recientes

### 4.2 Ver Logs con CLI

```bash
medplum bot logs hta-alert-bot --tail
```

### 4.3 Queries útiles para monitoreo

```bash
# Ver todas las alertas del día
GET /Communication?_tag=hta-alert&sent=ge2025-12-04

# Ver tareas pendientes
GET /Task?_tag=hta-followup&status=requested

# Ver ejecuciones del bot en AuditEvent
GET /AuditEvent?entity=Bot/[BOT-ID]
```

## 🔍 Troubleshooting

### El Bot no se ejecuta cuando creo una Observation

**Verificaciones:**

1. ✅ Asegúrese de que la Subscription esté en estado `active`
2. ✅ Verifique que los códigos LOINC sean correctos (85354-9, 8480-6, 8462-4)
3. ✅ Revise los logs del Bot para ver errores
4. ✅ Confirme que el Bot esté desplegado y activo

### El Bot se ejecuta pero no crea Communication/Task

**Verificaciones:**

1. ✅ Confirme que los valores de PA sean ≥160/100
2. ✅ Verifique que el Observation tenga la estructura correcta (component)
3. ✅ Revise los logs para ver mensajes de error específicos
4. ✅ Confirme que el Bot tenga permisos para crear recursos

### Error: "No se pudo obtener Practitioner"

**Solución:**

Cree al menos un Practitioner activo en el sistema:

```bash
POST /Practitioner
{
  "resourceType": "Practitioner",
  "active": true,
  "name": [{"family": "Sistema", "given": ["Bot"]}]
}
```

## 🔐 Consideraciones de Seguridad

1. **Permisos del Bot**: Asegúrese de que el Bot tenga permisos para:
   - Leer `Observation`, `Patient`, `Practitioner`
   - Crear `Communication`, `Task`

2. **AccessPolicy**: Configure un AccessPolicy específico para el Bot:

```json
{
  "resourceType": "AccessPolicy",
  "name": "HTA Bot Policy",
  "resource": [
    {
      "resourceType": "Observation",
      "criteria": "Observation?code=85354-9,8480-6,8462-4",
      "readonly": true
    },
    {
      "resourceType": "Communication"
    },
    {
      "resourceType": "Task"
    }
  ]
}
```

## 📈 Próximos Pasos

Una vez desplegado exitosamente:

1. ✅ Configure notificaciones por email/SMS (integración con Communication)
2. ✅ Cree un dashboard para visualizar las alertas activas
3. ✅ Implemente reportes periódicos de HTA no controlada
4. ✅ Integre con el sistema de turnos para agendar seguimientos automáticos

## 🆘 Soporte

Para asistencia técnica:
- Email: soporte@epa-bienestar.com.ar
- Documentación Medplum: https://www.medplum.com/docs/bots

---

**¡Bot desplegado con éxito!** 🎉

El sistema ahora monitoreará automáticamente todas las mediciones de Presión Arterial y generará alertas cuando detecte valores críticos.
