# 🚀 Guía de Inicio Rápido - Bot HTA Medplum

**Objetivo**: Tener el Bot funcionando en menos de 15 minutos.

## ⚡ Inicio Rápido (3 pasos)

### Paso 1: Instalar y Compilar (2 min)

```bash
cd medplum-hta-bot
npm install
npm run build
```

### Paso 2: Desplegar en Medplum (5 min)

#### Opción A: Interfaz Web (Recomendado para primera vez)

1. Ir a https://app.medplum.com
2. Login → Seleccionar proyecto "EPA Bienestar"
3. **Project** → **Bots** → **Create New Bot**
4. Nombre: `HTA Alert Bot`
5. Copiar contenido de `dist/index.js` en el editor
6. **Save**

#### Opción B: CLI (Más rápido si ya tienes credenciales)

```bash
npm install -g @medplum/cli
medplum login
medplum bot deploy hta-alert-bot --source dist/index.js
```

### Paso 3: Configurar Subscription (3 min)

En Medplum, dentro del Bot creado:

**Subscriptions** → **Create Subscription**

```json
{
  "resourceType": "Subscription",
  "status": "active",
  "reason": "Monitoreo de Presión Arterial",
  "criteria": "Observation?code=http://loinc.org|85354-9,http://loinc.org|8480-6,http://loinc.org|8462-4",
  "channel": {
    "type": "rest-hook",
    "endpoint": "Bot/[REEMPLAZAR-CON-BOT-ID]"
  }
}
```

**Save Subscription**

---

## ✅ Verificar que Funciona (5 min)

### Test 1: Crear Observation de Prueba

```bash
curl -X POST https://api.epa-bienestar.com.ar/fhir/r4/Observation \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/fhir+json" \
  -d '{
    "resourceType": "Observation",
    "status": "final",
    "code": {
      "coding": [{
        "system": "http://loinc.org",
        "code": "85354-9",
        "display": "Blood pressure panel"
      }]
    },
    "subject": {
      "reference": "Patient/test-patient-123",
      "display": "Test Patient"
    },
    "effectiveDateTime": "2025-12-04T10:00:00-03:00",
    "component": [
      {
        "code": {
          "coding": [{
            "system": "http://loinc.org",
            "code": "8480-6",
            "display": "Systolic blood pressure"
          }]
        },
        "valueQuantity": {
          "value": 165,
          "unit": "mmHg",
          "system": "http://unitsofmeasure.org",
          "code": "mm[Hg]"
        }
      },
      {
        "code": {
          "coding": [{
            "system": "http://loinc.org",
            "code": "8462-4",
            "display": "Diastolic blood pressure"
          }]
        },
        "valueQuantity": {
          "value": 105,
          "unit": "mmHg",
          "system": "http://unitsofmeasure.org",
          "code": "mm[Hg]"
        }
      }
    ]
  }'
```

### Test 2: Verificar Communication Creado

```bash
curl -X GET "https://api.epa-bienestar.com.ar/fhir/r4/Communication?_tag=hta-alert&_sort=-sent&_count=1" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Resultado Esperado**: Un Communication con priority "urgent"

### Test 3: Verificar Task Creado

```bash
curl -X GET "https://api.epa-bienestar.com.ar/fhir/r4/Task?_tag=hta-followup&status=requested&_sort=-_lastUpdated&_count=1" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Resultado Esperado**: Un Task con status "requested"

---

## 🎯 ¿Qué hace el Bot?

### Escenario de Uso Real

```
1. Paciente se mide la presión → 165/105 mmHg
2. Enfermera ingresa en sistema → Crea Observation
3. Bot detecta HTA Stage 2 (≥160/100)
4. Bot crea automáticamente:
   ├─ Communication (alerta al doctor)
   └─ Task (tarea de seguimiento en 48h)
5. Doctor ve alerta en su dashboard
6. Doctor llama al paciente
7. Doctor marca Task como completada
```

### Umbrales de Alerta

| PA Sistólica | PA Diastólica | Alerta | Prioridad | Plazo |
|--------------|---------------|--------|-----------|-------|
| < 160 | < 100 | ❌ No | - | - |
| ≥ 160 | ≥ 100 | ✅ Sí | Urgent | 48h |
| ≥ 180 | ≥ 120 | 🔴 Emergencia | Stat | 2h |

---

## 📋 Checklist de Implementación

- [ ] Node.js 22+ instalado
- [ ] Dependencias instaladas (`npm install`)
- [ ] Código compilado (`npm run build`)
- [ ] Bot creado en Medplum
- [ ] Código del bot cargado
- [ ] Subscription configurada y activa
- [ ] Test con Observation de prueba exitoso
- [ ] Communication generado verificado
- [ ] Task generado verificado
- [ ] Logs del bot revisados sin errores

---

## 🔧 Troubleshooting Rápido

### ❌ "Bot no se ejecuta"

**Solución**:
1. Verificar que Subscription esté `"status": "active"`
2. Verificar que el `criteria` incluya los códigos LOINC correctos
3. Revisar logs del Bot en Medplum

### ❌ "Communication no se crea"

**Solución**:
1. Verificar que PA sea ≥ 160/100
2. Revisar logs del Bot para errores
3. Confirmar que el Bot tenga permisos para crear Communication

### ❌ "Cannot find Practitioner"

**Solución**:
```bash
# Crear un Practitioner activo
curl -X POST https://api.epa-bienestar.com.ar/fhir/r4/Practitioner \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/fhir+json" \
  -d '{
    "resourceType": "Practitioner",
    "active": true,
    "name": [{
      "family": "Sistema",
      "given": ["Bot"]
    }]
  }'
```

---

## 📚 Próximos Pasos

Una vez que el bot está funcionando:

1. **Integrar con Dashboard**: Ver [EXAMPLES.md](EXAMPLES.md) para queries de dashboard
2. **Personalizar Umbrales**: Editar `src/bloodPressureEvaluator.ts`
3. **Agregar Notificaciones SMS/Email**: Ver [EXAMPLES.md](EXAMPLES.md)
4. **Configurar Reportes**: Ver [DEPLOYMENT.md](DEPLOYMENT.md)

---

## 📞 Soporte

- **Documentación Completa**: [README.md](README.md)
- **Arquitectura**: [ARCHITECTURE.md](ARCHITECTURE.md)
- **Despliegue Detallado**: [DEPLOYMENT.md](DEPLOYMENT.md)
- **Ejemplos**: [EXAMPLES.md](EXAMPLES.md)

---

**¡Listo para producción en 15 minutos!** 🎉
