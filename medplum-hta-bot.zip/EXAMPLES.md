# Ejemplos de Uso - Bot HTA Medplum

Este documento proporciona ejemplos prácticos de uso del Bot de Hipertensión Arterial.

## 📊 Casos de Uso Clínicos

### Caso 1: Paciente con HTA Stage 2 - Seguimiento Urgente

**Escenario**: María González, 58 años, paciente conocida con HTA en tratamiento con enalapril. Se registra una PA de 165/105 mmHg.

**Flujo Automatizado**:

1. **Input**: Observation de PA creada
```json
{
  "resourceType": "Observation",
  "status": "final",
  "code": {
    "coding": [{
      "system": "http://loinc.org",
      "code": "85354-9"
    }]
  },
  "subject": { "reference": "Patient/maria-gonzalez-123" },
  "component": [
    {
      "code": { "coding": [{ "system": "http://loinc.org", "code": "8480-6" }] },
      "valueQuantity": { "value": 165, "unit": "mmHg" }
    },
    {
      "code": { "coding": [{ "system": "http://loinc.org", "code": "8462-4" }] },
      "valueQuantity": { "value": 105, "unit": "mmHg" }
    }
  ]
}
```

2. **Bot detecta**: HTA Stage 2 (≥160/100)

3. **Communication generado**:
```
⚠️ HIPERTENSIÓN NO CONTROLADA ⚠️

ALERTA AUTOMÁTICA DE PRESIÓN ARTERIAL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Paciente: María González
Fecha/Hora: miércoles, 4 de diciembre de 2025, 10:30

VALORES REGISTRADOS:
• Presión Arterial: 165/105 mmHg
• Clasificación: Hipertensión Arterial Estadio 2 - No Controlada

ACCIÓN REQUERIDA:
Contactar al paciente dentro de las 24-48 horas.
Verificar adherencia al tratamiento.
Evaluar necesidad de ajuste de medicación.
Descartar causas secundarias o factores desencadenantes.
```

4. **Task creado**:
   - Status: `requested`
   - Priority: `urgent`
   - Owner: Dr. Juan Pérez
   - Plazo: 48 horas

**Acción del Profesional**:
```bash
# El Dr. Pérez completa la tarea
PUT /Task/task-123
{
  "status": "completed",
  "output": [{
    "type": { "text": "Resultado del Seguimiento" },
    "valueString": "Paciente contactada. Adherencia irregular por olvidos. Se ajustó esquema a enalapril 20mg + hidroclorotiazida 12.5mg. Control en 7 días."
  }]
}
```

---

### Caso 2: Crisis Hipertensiva - Acción Inmediata

**Escenario**: Ana Rodríguez, 62 años, se mide la PA en casa y obtiene 188/128 mmHg. Reporta cefalea intensa.

**Flujo Automatizado**:

1. **Input**: Observation con valores críticos

2. **Bot detecta**: Crisis Hipertensiva (≥180/120)

3. **Communication generado**:
```
🔴 EMERGENCIA HIPERTENSIVA 🔴

ALERTA AUTOMÁTICA DE PRESIÓN ARTERIAL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Paciente: Ana Rodríguez
Fecha/Hora: miércoles, 4 de diciembre de 2025, 14:15

VALORES REGISTRADOS:
• Presión Arterial: 188/128 mmHg
• Clasificación: Crisis Hipertensiva - Emergencia Médica

ACCIÓN REQUERIDA:
ACCIÓN INMEDIATA: Contactar al paciente de inmediato.
Evaluar síntomas de daño orgánico (cefalea severa, disnea, dolor torácico, cambios visuales).
Considerar derivación a emergencias si presenta síntomas.
```

4. **Task creado**:
   - Status: `requested`
   - Priority: `stat` (máxima urgencia)
   - Plazo: 2 horas

**Acción del Profesional**:
```bash
# Respuesta inmediata
# 1. Llamar a la paciente
# 2. Evaluar síntomas
# 3. Derivar a emergencias si es necesario
```

---

### Caso 3: PA Normal - Sin Alerta

**Escenario**: Laura Martínez, control de rutina, PA: 118/76 mmHg.

**Flujo**:
1. **Input**: Observation de PA normal
2. **Bot evalúa**: Presión Normal (<120/<80)
3. **Resultado**: No se generan alertas ni tareas
4. **Log del Bot**: "Valores de PA dentro de rangos aceptables - No se requiere alerta"

---

## 🔍 Queries FHIR Útiles

### Dashboard del Profesional

```bash
# Ver todas mis tareas pendientes de HTA
GET /Task?owner=Practitioner/123&status=requested&_tag=hta-followup&_sort=priority,-_lastUpdated

# Ver solo emergencias
GET /Task?owner=Practitioner/123&status=requested&priority=stat&_tag=hta-followup

# Ver pacientes con HTA no controlada
GET /Communication?_tag=HTA_STAGE_2&sent=ge2025-12-01
```

### Reportes Administrativos

```bash
# Total de alertas generadas este mes
GET /Communication?_tag=hta-alert&sent=ge2025-12-01&_summary=count

# Distribución por nivel de severidad
GET /Communication?_tag=HYPERTENSIVE_CRISIS&sent=ge2025-12-01&_summary=count
GET /Communication?_tag=HTA_STAGE_2&sent=ge2025-12-01&_summary=count

# Tiempo promedio de resolución de Tasks
GET /Task?_tag=hta-followup&status=completed&lastModified=ge2025-12-01
```

### Auditoría y Seguimiento

```bash
# Ver historial de PA de un paciente
GET /Observation?patient=Patient/123&code=85354-9&_sort=-date

# Ver todas las comunicaciones de un paciente
GET /Communication?subject=Patient/123&_tag=hta-alert&_sort=-sent

# Ver tasks completadas de un paciente
GET /Task?for=Patient/123&_tag=hta-followup&status=completed
```

---

## 🧪 Scripts de Testing

### Script 1: Simular una semana de mediciones

```bash
#!/bin/bash

# Configuración
PATIENT_ID="patient-test-123"
API_URL="https://api.epa-bienestar.com.ar/fhir/r4"
TOKEN="YOUR_TOKEN"

# Día 1: PA Normal
curl -X POST "$API_URL/Observation" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/fhir+json" \
  -d '{
    "resourceType": "Observation",
    "status": "final",
    "code": {"coding": [{"system": "http://loinc.org", "code": "85354-9"}]},
    "subject": {"reference": "Patient/'$PATIENT_ID'"},
    "effectiveDateTime": "2025-12-01T08:00:00-03:00",
    "component": [
      {"code": {"coding": [{"system": "http://loinc.org", "code": "8480-6"}]}, "valueQuantity": {"value": 118, "unit": "mmHg"}},
      {"code": {"coding": [{"system": "http://loinc.org", "code": "8462-4"}]}, "valueQuantity": {"value": 76, "unit": "mmHg"}}
    ]
  }'

# Día 3: PA Elevada (sin alerta)
curl -X POST "$API_URL/Observation" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/fhir+json" \
  -d '{
    "resourceType": "Observation",
    "status": "final",
    "code": {"coding": [{"system": "http://loinc.org", "code": "85354-9"}]},
    "subject": {"reference": "Patient/'$PATIENT_ID'"},
    "effectiveDateTime": "2025-12-03T08:00:00-03:00",
    "component": [
      {"code": {"coding": [{"system": "http://loinc.org", "code": "8480-6"}]}, "valueQuantity": {"value": 135, "unit": "mmHg"}},
      {"code": {"coding": [{"system": "http://loinc.org", "code": "8462-4"}]}, "valueQuantity": {"value": 85, "unit": "mmHg"}}
    ]
  }'

# Día 5: HTA Stage 2 (¡ALERTA!)
curl -X POST "$API_URL/Observation" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/fhir+json" \
  -d '{
    "resourceType": "Observation",
    "status": "final",
    "code": {"coding": [{"system": "http://loinc.org", "code": "85354-9"}]},
    "subject": {"reference": "Patient/'$PATIENT_ID'"},
    "effectiveDateTime": "2025-12-05T08:00:00-03:00",
    "component": [
      {"code": {"coding": [{"system": "http://loinc.org", "code": "8480-6"}]}, "valueQuantity": {"value": 165, "unit": "mmHg"}},
      {"code": {"coding": [{"system": "http://loinc.org", "code": "8462-4"}]}, "valueQuantity": {"value": 105, "unit": "mmHg"}}
    ]
  }'

echo "Mediciones creadas. Verificar alertas generadas."
```

### Script 2: Completar una tarea de seguimiento

```typescript
import { MedplumClient } from '@medplum/core';
import { completeTask } from './src/taskCreator';

async function completarSeguimiento() {
  const medplum = new MedplumClient({
    baseUrl: 'https://api.epa-bienestar.com.ar/fhir/r4',
    clientId: 'YOUR_CLIENT_ID',
    clientSecret: 'YOUR_CLIENT_SECRET',
  });

  await medplum.startClientLogin(clientId, clientSecret);

  // Completar la tarea
  const task = await completeTask(
    medplum,
    'task-abc-123',
    'Paciente contactada exitosamente',
    `
    Seguimiento realizado el 04/12/2025:
    - Paciente refiere adherencia irregular por olvidos
    - Sin síntomas de daño orgánico
    - Se ajustó esquema: Enalapril 20mg + HCTZ 12.5mg c/24hs
    - Se educó sobre importancia de adherencia
    - Control de PA en 7 días
    - Nueva cita programada para 11/12/2025
    `
  );

  console.log('Task completada:', task.id);
}

completarSeguimiento();
```

---

## 📈 Integración con Otros Sistemas

### Ejemplo: Enviar SMS cuando se genera una alerta

```typescript
// En communicationCreator.ts, agregar:

async function sendSMSNotification(
  medplum: MedplumClient,
  communication: Communication
): Promise<void> {
  // Obtener teléfono del practitioner
  const practitionerRef = communication.recipient?.[0];
  if (!practitionerRef) return;

  const practitioner = await medplum.readReference(practitionerRef);
  const phone = practitioner.telecom?.find(t => t.system === 'phone')?.value;

  if (phone) {
    // Integrar con servicio SMS (ej: Twilio)
    await fetch('https://api.twilio.com/2010-04-01/Accounts/YOUR_ACCOUNT/Messages.json', {
      method: 'POST',
      headers: {
        'Authorization': 'Basic ' + btoa('YOUR_SID:YOUR_TOKEN'),
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        To: phone,
        From: '+5491123456789',
        Body: `ALERTA HTA: Paciente con PA crítica requiere seguimiento urgente. Ver tarea en sistema.`,
      }),
    });
  }
}
```

### Ejemplo: Integración con sistema de turnos

```typescript
// Crear turno automático de seguimiento

async function createFollowUpAppointment(
  medplum: MedplumClient,
  task: Task
): Promise<Appointment> {
  const followUpDate = new Date();
  followUpDate.setDate(followUpDate.getDate() + 7); // 7 días después

  const appointment: Appointment = {
    resourceType: 'Appointment',
    status: 'proposed',
    serviceType: [{
      coding: [{
        system: 'http://epa-bienestar.com.ar/fhir/CodeSystem/service-types',
        code: 'hta-followup',
        display: 'Seguimiento de HTA',
      }],
    }],
    appointmentType: {
      coding: [{
        system: 'http://terminology.hl7.org/CodeSystem/v2-0276',
        code: 'FOLLOWUP',
        display: 'Follow-up',
      }],
    },
    reasonReference: [task.focus!],
    start: followUpDate.toISOString(),
    end: new Date(followUpDate.getTime() + 30 * 60 * 1000).toISOString(), // 30 min
    participant: [
      {
        actor: task.for,
        status: 'needs-action',
      },
      {
        actor: task.owner,
        status: 'accepted',
      },
    ],
  };

  return await medplum.createResource(appointment);
}
```

---

## 🎯 Mejores Prácticas

### 1. Registro Completo de Observations

✅ **Bueno**:
```json
{
  "component": [
    {"code": {...}, "valueQuantity": {"value": 165, "unit": "mmHg", "system": "http://unitsofmeasure.org"}},
    {"code": {...}, "valueQuantity": {"value": 105, "unit": "mmHg", "system": "http://unitsofmeasure.org"}}
  ],
  "effectiveDateTime": "2025-12-04T10:30:00-03:00",
  "performer": [{"reference": "Practitioner/123"}]
}
```

❌ **Evitar**:
```json
{
  "component": [
    {"valueQuantity": {"value": 165}}, // Sin código LOINC
    {"valueQuantity": {"value": 105}}
  ]
  // Sin fecha ni performer
}
```

### 2. Completar Tasks con Detalle

✅ **Bueno**:
```json
{
  "status": "completed",
  "output": [{
    "valueString": "Contacto exitoso. Ajuste de medicación realizado. Control en 7 días."
  }],
  "note": [{
    "text": "Paciente refiere adherencia irregular. Se educó sobre importancia del tratamiento."
  }]
}
```

❌ **Evitar**:
```json
{
  "status": "completed"
  // Sin detalles del seguimiento
}
```

---

Este documento será actualizado continuamente con nuevos casos de uso y ejemplos prácticos.
