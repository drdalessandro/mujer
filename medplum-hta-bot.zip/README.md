# Bot de Medplum para Gestión Automatizada de Hipertensión Arterial (HTA)

Sistema automatizado de alerta y gestión de tareas clínicas para detectar y gestionar valores de Presión Arterial fuera de rango en pacientes con HTA, utilizando la infraestructura FHIR R4 de Medplum.

## 🎯 Objetivo

Transformar la simple carga de datos de presión arterial en **acción clínica inmediata y estructurada**, mediante la detección automática de:
- **HTA Stage 2 No Controlada** (≥ 160/100 mmHg)
- **Crisis Hipertensiva** (≥ 180/120 mmHg)

## 🏗️ Arquitectura del Sistema

```
┌─────────────────────────────────────────────────────────────────┐
│                     FLUJO DE TRABAJO                             │
└─────────────────────────────────────────────────────────────────┘

1. ENTRADA DE DATOS
   └─> Observation (PA) creado/actualizado manualmente
        └─> Códigos LOINC: 85354-9, 8480-6, 8462-4

2. TRIGGER AUTOMÁTICO
   └─> Bot de Medplum se activa
        └─> Escucha eventos de Observation

3. EVALUACIÓN
   └─> Lógica de negocio
        ├─> Sístole ≥ 160 mmHg ó Diástole ≥ 100 mmHg
        │   └─> HTA Stage 2 (ALERTA)
        │
        └─> Sístole ≥ 180 mmHg ó Diástole ≥ 120 mmHg
            └─> Crisis Hipertensiva (EMERGENCIA)

4. GENERACIÓN AUTOMÁTICA DE RECURSOS
   ├─> Communication (Notificación/Alerta)
   │    ├─> Priority: urgent | stat
   │    ├─> Recipient: Practitioner responsable
   │    └─> Payload: Detalles de la alerta
   │
   └─> Task (Flujo de trabajo)
        ├─> Status: requested
        ├─> Owner: Practitioner
        ├─> Focus: Observation crítica
        └─> Restriction: Plazo máximo de respuesta
```

## 📋 Recursos FHIR Involucrados

### Observation (Entrada)
```json
{
  "resourceType": "Observation",
  "status": "final",
  "code": {
    "coding": [{
      "system": "http://loinc.org",
      "code": "85354-9",
      "display": "Blood pressure panel"
    }]
  },
  "subject": { "reference": "Patient/123" },
  "component": [
    {
      "code": {
        "coding": [{
          "system": "http://loinc.org",
          "code": "8480-6",
          "display": "Systolic blood pressure"
        }]
      },
      "valueQuantity": { "value": 165, "unit": "mmHg" }
    },
    {
      "code": {
        "coding": [{
          "system": "http://loinc.org",
          "code": "8462-4",
          "display": "Diastolic blood pressure"
        }]
      },
      "valueQuantity": { "value": 105, "unit": "mmHg" }
    }
  ]
}
```

### Communication (Alerta)
Generado automáticamente cuando PA ≥ 160/100:
- **Priority**: `urgent` o `stat`
- **Recipient**: Practitioner responsable
- **Payload**: Texto detallado de la alerta
- **ReasonReference**: Link a la Observation crítica

### Task (Seguimiento)
Generado automáticamente para gestión del flujo de trabajo:
- **Status**: `requested` → `in-progress` → `completed`
- **Owner**: Practitioner asignado
- **Focus**: Observation de PA crítica
- **Restriction**: Plazo según urgencia (2h para crisis, 48h para Stage 2)

## 🚀 Instalación y Despliegue

### Requisitos Previos
- Node.js ≥ 22.0.0
- Cuenta en Medplum (https://api.epa-bienestar.com.ar/fhir/r4)
- Credenciales de acceso a la API FHIR

### Paso 1: Instalación de Dependencias

```bash
npm install
```

### Paso 2: Compilación del Proyecto

```bash
npm run build
```

### Paso 3: Despliegue en Medplum

#### Opción A: Desde la Interfaz Web de Medplum

1. Acceder a https://app.medplum.com
2. Navegar a **Project Settings** → **Bots**
3. Crear un nuevo Bot
4. Copiar el contenido de `dist/index.js`
5. Configurar el trigger:
   - **Resource Type**: `Observation`
   - **Criteria**: `Observation?code=85354-9,8480-6,8462-4`
   - **Event**: `create`, `update`

#### Opción B: Mediante Medplum CLI

```bash
# Instalar Medplum CLI
npm install -g @medplum/cli

# Autenticarse
medplum login

# Desplegar el bot
medplum bot deploy \
  --bot-name "HTA Alert Bot" \
  --source dist/index.js \
  --resource-type Observation \
  --criteria "Observation?code=85354-9,8480-6,8462-4"
```

## 📊 Umbrales Clínicos Configurados

| Clasificación | Sistólica (mmHg) | Diastólica (mmHg) | Acción del Bot |
|---------------|------------------|-------------------|----------------|
| Normal | < 120 | < 80 | Sin acción |
| Elevada | 120-129 | < 80 | Sin acción |
| HTA Stage 1 | 130-159 | 80-99 | Sin acción |
| **HTA Stage 2** | **≥ 160** | **≥ 100** | **✓ Alerta + Task** |
| **Crisis Hipertensiva** | **≥ 180** | **≥ 120** | **✓ Alerta Emergencia + Task Urgente** |

## 🔔 Tipos de Alertas Generadas

### HTA Stage 2 (160/100 - 179/119)
- **Priority**: `urgent`
- **Plazo de seguimiento**: 24-48 horas
- **Acción recomendada**:
  - Contactar al paciente
  - Verificar adherencia al tratamiento
  - Evaluar ajuste de medicación

### Crisis Hipertensiva (≥ 180/120)
- **Priority**: `stat` (máxima urgencia)
- **Plazo de seguimiento**: 2 horas
- **Acción recomendada**:
  - Contacto inmediato
  - Evaluar síntomas de daño orgánico
  - Considerar derivación a emergencias

## 📱 Uso del Sistema

### Para Profesionales de Salud

#### Ver Tareas Pendientes
```typescript
import { MedplumClient } from '@medplum/core';
import { getPendingTasks } from './taskCreator.js';

const medplum = new MedplumClient();
const tasks = await getPendingTasks(medplum, 'Practitioner/123');
```

#### Completar una Tarea
```typescript
import { completeTask } from './taskCreator.js';

await completeTask(
  medplum,
  'Task/456',
  'Paciente contactada. PA controlada con ajuste de medicación.',
  'Se aumentó dosis de enalapril a 20mg/día'
);
```

#### Dashboard de Tareas Urgentes
```bash
# Query FHIR para obtener todas las tareas urgentes de HTA
GET /fhir/r4/Task?status=requested&priority=urgent,stat&_tag=hta-followup
```

## 🧪 Testing

### Crear una Observation de Prueba

```bash
curl -X POST https://api.epa-bienestar.com.ar/fhir/r4/Observation \
  -H "Content-Type: application/fhir+json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "resourceType": "Observation",
    "status": "final",
    "code": {
      "coding": [{
        "system": "http://loinc.org",
        "code": "85354-9"
      }]
    },
    "subject": { "reference": "Patient/123" },
    "component": [
      {
        "code": {
          "coding": [{
            "system": "http://loinc.org",
            "code": "8480-6"
          }]
        },
        "valueQuantity": { "value": 165, "unit": "mmHg" }
      },
      {
        "code": {
          "coding": [{
            "system": "http://loinc.org",
            "code": "8462-4"
          }]
        },
        "valueQuantity": { "value": 105, "unit": "mmHg" }
      }
    ]
  }'
```

### Verificar Recursos Creados

```bash
# Verificar Communication
GET /fhir/r4/Communication?_tag=hta-alert&_sort=-_lastUpdated

# Verificar Task
GET /fhir/r4/Task?_tag=hta-followup&status=requested
```

## 📁 Estructura del Proyecto

```
medplum-hta-bot/
├── src/
│   ├── index.ts                    # Handler principal del Bot
│   ├── bloodPressureEvaluator.ts   # Lógica de evaluación de PA
│   ├── communicationCreator.ts     # Generador de Communication
│   ├── taskCreator.ts              # Generador de Task
│   ├── types.ts                    # Definiciones de tipos
│   └── utils.ts                    # Utilidades
├── dist/                           # Código compilado
├── package.json
├── tsconfig.json
└── README.md
```

## 🔐 Seguridad y Privacidad

- ✅ Cumple con FHIR R4
- ✅ Compatible con SMART on FHIR
- ✅ Logs auditables de todas las acciones
- ✅ Referencias encriptadas entre recursos
- ✅ Control de acceso basado en roles (RBAC)

## 🛠️ Comandos Útiles

```bash
# Desarrollo con watch mode
npm run dev

# Compilar
npm run build

# Linting
npm run lint

# Formatear código
npm run format

# Tests
npm test
```

## 📈 Métricas y Monitoreo

### Queries útiles para dashboards

```bash
# Total de alertas generadas hoy
GET /Communication?_tag=hta-alert&sent=ge2025-12-04

# Tareas pendientes por profesional
GET /Task?owner=Practitioner/123&status=requested

# Crisis hipertensivas del último mes
GET /Communication?_tag=HYPERTENSIVE_CRISIS&sent=ge2025-11-04
```

## 🤝 Contribución

Para reportar bugs o sugerir mejoras, contactar al equipo de EPA Bienestar.

## 📄 Licencia

MIT License - EPA Bienestar

## 🔗 Enlaces Útiles

- **API FHIR EPA Bienestar**: https://api.epa-bienestar.com.ar/fhir/r4
- **Documentación Medplum**: https://www.medplum.com/docs
- **FHIR R4 Specification**: https://hl7.org/fhir/R4/
- **LOINC Codes**: https://loinc.org/

---

**Desarrollado por EPA Bienestar IA** | Sistema de Gestión de Hipertensión Arterial
