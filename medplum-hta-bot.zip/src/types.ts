/**
 * Definiciones de Tipos y Constantes para el Bot HTA
 */

import { Reference } from '@medplum/fhirtypes';

/**
 * Configuración del Bot
 */
export interface BotConfiguration {
  /**
   * URL de la API FHIR de Medplum
   */
  fhirServerUrl: string;

  /**
   * Umbrales personalizados para alertas (opcional)
   */
  thresholds?: {
    stage2Systolic?: number;
    stage2Diastolic?: number;
    crisisSystolic?: number;
    crisisDiastolic?: number;
  };

  /**
   * Configuración de notificaciones
   */
  notifications?: {
    enableSMS?: boolean;
    enableEmail?: boolean;
    defaultRecipient?: Reference;
  };
}

/**
 * Códigos LOINC para Presión Arterial
 */
export const LOINC_BP_CODES = {
  BLOOD_PRESSURE_PANEL: '85354-9',
  SYSTOLIC_BP: '8480-6',
  DIASTOLIC_BP: '8462-4',
} as const;

/**
 * Códigos SNOMED CT relacionados con HTA
 */
export const SNOMED_HTA_CODES = {
  HYPERTENSIVE_DISORDER: '38341003',
  ESSENTIAL_HYPERTENSION: '59621000',
  HYPERTENSIVE_CRISIS: '706882009',
  MALIGNANT_HYPERTENSION: '70272006',
} as const;

/**
 * Tags del sistema EPA Bienestar
 */
export const EPA_TAGS = {
  HTA_ALERT: 'hta-alert',
  HTA_FOLLOWUP: 'hta-followup',
  AUTOMATED: 'automated',
} as const;

/**
 * Sistema de códigos EPA Bienestar
 */
export const EPA_SYSTEMS = {
  TAGS: 'http://epa-bienestar.com.ar/fhir/tags',
  CLINICAL_TASKS: 'http://epa-bienestar.com.ar/fhir/CodeSystem/clinical-tasks',
} as const;

/**
 * Resultado de la evaluación de PA
 */
export interface BPEvaluationResult {
  isAlert: boolean;
  level: string;
  description: string;
  communicationId?: string;
  taskId?: string;
  error?: string;
}

/**
 * Contexto extendido del evento del Bot
 */
export interface ExtendedBotContext {
  observationId: string;
  patientId: string;
  practitionerId?: string;
  systolic: number;
  diastolic: number;
  timestamp: string;
}
