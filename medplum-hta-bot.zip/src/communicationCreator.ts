/**
 * Generador de Recursos Communication (FHIR R4)
 *
 * Crea recursos Communication para notificar alertas de HTA
 * a los profesionales de salud
 */

import { MedplumClient } from '@medplum/core';
import { Communication, Observation, Reference } from '@medplum/fhirtypes';
import { BloodPressureValues, HTAClassification, getAlertMessage } from './bloodPressureEvaluator.js';

export interface CommunicationContext {
  observation: Observation;
  patient: Reference;
  practitioner?: Reference;
  classification: HTAClassification;
  bpValues: BloodPressureValues;
}

/**
 * Crea un recurso Communication para alertar sobre valores críticos de PA
 *
 * @param medplum - Cliente de Medplum
 * @param context - Contexto con la información necesaria para la alerta
 * @returns El recurso Communication creado
 */
export async function createCommunicationAlert(
  medplum: MedplumClient,
  context: CommunicationContext
): Promise<Communication> {
  const { observation, patient, practitioner, classification, bpValues } = context;

  // Obtener el nombre del paciente para personalizar el mensaje
  const patientName = await getPatientDisplayName(medplum, patient);

  // Construir el mensaje de alerta
  const alertText = buildAlertText(patientName, bpValues, classification);

  // Crear el recurso Communication
  const communication: Communication = {
    resourceType: 'Communication',
    status: 'completed',
    priority: classification.priority,
    subject: patient,
    recipient: practitioner ? [practitioner] : undefined,
    sent: new Date().toISOString(),
    payload: [
      {
        contentString: alertText,
      },
    ],
    reasonReference: [
      {
        reference: `Observation/${observation.id}`,
        display: `PA: ${bpValues.systolic}/${bpValues.diastolic} mmHg`,
      },
    ],
    category: [
      {
        coding: [
          {
            system: 'http://terminology.hl7.org/CodeSystem/communication-category',
            code: 'alert',
            display: 'Alert',
          },
        ],
        text: 'Alerta Clínica Automática',
      },
    ],
    meta: {
      tag: [
        {
          system: 'http://epa-bienestar.com.ar/fhir/tags',
          code: 'hta-alert',
          display: 'Alerta HTA Automatizada',
        },
        {
          system: 'http://epa-bienestar.com.ar/fhir/tags',
          code: classification.level,
          display: classification.description,
        },
      ],
    },
  };

  // Crear el recurso en el servidor FHIR
  const createdCommunication = await medplum.createResource(communication);

  console.log(`Communication creado: ${createdCommunication.id}`);

  return createdCommunication;
}

/**
 * Construye el texto de la alerta
 */
function buildAlertText(
  patientName: string,
  bpValues: BloodPressureValues,
  classification: HTAClassification
): string {
  const timestamp = new Date().toLocaleString('es-AR', {
    dateStyle: 'full',
    timeStyle: 'short',
  });

  let severity = '';
  if (classification.level === 'HYPERTENSIVE_CRISIS') {
    severity = '🔴 EMERGENCIA HIPERTENSIVA 🔴';
  } else if (classification.level === 'HTA_STAGE_2') {
    severity = '⚠️ HIPERTENSIÓN NO CONTROLADA ⚠️';
  }

  return `
${severity}

ALERTA AUTOMÁTICA DE PRESIÓN ARTERIAL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Paciente: ${patientName}
Fecha/Hora: ${timestamp}

VALORES REGISTRADOS:
• Presión Arterial: ${bpValues.systolic}/${bpValues.diastolic} mmHg
• Clasificación: ${classification.description}

ACCIÓN REQUERIDA:
${classification.recommendedAction}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Sistema: Bot HTA - EPA Bienestar
API FHIR: https://api.epa-bienestar.com.ar/fhir/r4
`.trim();
}

/**
 * Obtiene el nombre del paciente desde la referencia
 */
async function getPatientDisplayName(medplum: MedplumClient, patientRef: Reference): Promise<string> {
  // Si la referencia ya tiene display, usarlo
  if (patientRef.display) {
    return patientRef.display;
  }

  // Intentar cargar el recurso Patient
  try {
    const patientId = patientRef.reference?.split('/')[1];
    if (patientId) {
      const patient = await medplum.readResource('Patient', patientId);
      if (patient.name && patient.name.length > 0) {
        const name = patient.name[0];
        const fullName = `${name.given?.join(' ') || ''} ${name.family || ''}`.trim();
        return fullName || 'Paciente';
      }
    }
  } catch (error) {
    console.warn('No se pudo obtener el nombre del paciente:', error);
  }

  return 'Paciente';
}

/**
 * Crea una Communication de seguimiento (cuando el profesional completa la acción)
 */
export async function createFollowUpCommunication(
  medplum: MedplumClient,
  originalCommunication: Communication,
  followUpNotes: string
): Promise<Communication> {
  const followUp: Communication = {
    resourceType: 'Communication',
    status: 'completed',
    subject: originalCommunication.subject,
    recipient: originalCommunication.recipient,
    sent: new Date().toISOString(),
    inResponseTo: [
      {
        reference: `Communication/${originalCommunication.id}`,
      },
    ],
    payload: [
      {
        contentString: `SEGUIMIENTO DE ALERTA HTA\n\n${followUpNotes}`,
      },
    ],
    category: [
      {
        coding: [
          {
            system: 'http://terminology.hl7.org/CodeSystem/communication-category',
            code: 'notification',
            display: 'Notification',
          },
        ],
      },
    ],
  };

  return await medplum.createResource(followUp);
}
