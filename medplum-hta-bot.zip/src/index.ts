/**
 * Bot de Medplum para Detección Automática de Hipertensión Arterial
 *
 * Este bot escucha eventos de creación/actualización de recursos Observation
 * de tipo Presión Arterial y genera alertas automáticas cuando detecta valores
 * críticos según los umbrales clínicos definidos.
 *
 * @module medplum-hta-bot
 */

import { BotEvent, MedplumClient } from '@medplum/core';
import { Observation, Communication, Task, Reference } from '@medplum/fhirtypes';
import { evaluateBloodPressure, BloodPressureValues, HTAClassification } from './bloodPressureEvaluator.js';
import { createCommunicationAlert } from './communicationCreator.js';
import { createFollowUpTask } from './taskCreator.js';

/**
 * Códigos LOINC para Presión Arterial
 */
const LOINC_CODES = {
  BLOOD_PRESSURE_PANEL: '85354-9',
  SYSTOLIC_BP: '8480-6',
  DIASTOLIC_BP: '8462-4',
};

/**
 * Handler principal del Bot
 * Se ejecuta automáticamente cuando se crea o actualiza un Observation
 *
 * @param medplum - Cliente de Medplum para interactuar con la API FHIR
 * @param event - Evento que disparó el bot (creación o actualización de recurso)
 */
export async function handler(medplum: MedplumClient, event: BotEvent): Promise<void> {
  const observation = event.input as Observation;

  console.log(`Bot HTA iniciado - Observation ID: ${observation.id}`);

  // Paso 1: Verificar que sea una Observation de Presión Arterial
  if (!isBloodPressureObservation(observation)) {
    console.log('Observation no es de Presión Arterial - Bot finalizado');
    return;
  }

  // Paso 2: Extraer valores de Sístole y Diástole
  const bpValues = extractBloodPressureValues(observation);

  if (!bpValues) {
    console.warn('No se pudieron extraer valores de PA de la Observation');
    return;
  }

  console.log(`Valores de PA extraídos - Sistólica: ${bpValues.systolic}, Diastólica: ${bpValues.diastolic}`);

  // Paso 3: Evaluar la clasificación de HTA
  const classification = evaluateBloodPressure(bpValues);

  console.log(`Clasificación HTA: ${classification.level} - ${classification.description}`);

  // Paso 4: Si hay alerta (HTA Stage 2 o Crisis Hipertensiva), generar recursos
  if (classification.requiresAlert) {
    console.log('⚠️ ALERTA HTA DETECTADA - Generando Communication y Task');

    try {
      // Obtener referencias necesarias
      const patientRef = observation.subject;
      const practitionerRef = await getPractitionerReference(medplum, observation);

      if (!patientRef) {
        console.error('No se encontró referencia al paciente en la Observation');
        return;
      }

      // Crear recurso Communication (Alerta)
      const communication = await createCommunicationAlert(
        medplum,
        {
          observation,
          patient: patientRef,
          practitioner: practitionerRef,
          classification,
          bpValues,
        }
      );

      console.log(`✓ Communication creado - ID: ${communication.id}`);

      // Crear recurso Task (Seguimiento)
      const task = await createFollowUpTask(
        medplum,
        {
          observation,
          patient: patientRef,
          practitioner: practitionerRef,
          classification,
          bpValues,
        }
      );

      console.log(`✓ Task creado - ID: ${task.id}`);
      console.log('Bot HTA completado exitosamente');

    } catch (error) {
      console.error('Error al crear recursos de alerta:', error);
      throw error;
    }
  } else {
    console.log('Valores de PA dentro de rangos aceptables - No se requiere alerta');
  }
}

/**
 * Verifica si la Observation es de tipo Presión Arterial
 * usando los códigos LOINC estándar
 */
function isBloodPressureObservation(observation: Observation): boolean {
  if (!observation.code?.coding) {
    return false;
  }

  return observation.code.coding.some(
    (coding) =>
      coding.system === 'http://loinc.org' &&
      (coding.code === LOINC_CODES.BLOOD_PRESSURE_PANEL ||
       coding.code === LOINC_CODES.SYSTOLIC_BP ||
       coding.code === LOINC_CODES.DIASTOLIC_BP)
  );
}

/**
 * Extrae los valores de Presión Arterial (Sístole y Diástole)
 * de un recurso Observation FHIR
 */
function extractBloodPressureValues(observation: Observation): BloodPressureValues | null {
  let systolic: number | undefined;
  let diastolic: number | undefined;

  // Caso 1: Los valores están en components (estructura recomendada)
  if (observation.component && observation.component.length > 0) {
    for (const component of observation.component) {
      const code = component.code?.coding?.[0]?.code;
      const value = component.valueQuantity?.value;

      if (value !== undefined) {
        if (code === LOINC_CODES.SYSTOLIC_BP) {
          systolic = value;
        } else if (code === LOINC_CODES.DIASTOLIC_BP) {
          diastolic = value;
        }
      }
    }
  }

  // Caso 2: Valor único (para Observations simples)
  if (observation.valueQuantity?.value !== undefined) {
    const code = observation.code?.coding?.[0]?.code;
    if (code === LOINC_CODES.SYSTOLIC_BP) {
      systolic = observation.valueQuantity.value;
    } else if (code === LOINC_CODES.DIASTOLIC_BP) {
      diastolic = observation.valueQuantity.value;
    }
  }

  if (systolic !== undefined && diastolic !== undefined) {
    return { systolic, diastolic };
  }

  return null;
}

/**
 * Obtiene la referencia al Practitioner responsable
 * Primero intenta desde observation.performer, luego busca un practitioner por defecto
 */
async function getPractitionerReference(
  medplum: MedplumClient,
  observation: Observation
): Promise<Reference | undefined> {
  // Intentar obtener del performer
  if (observation.performer && observation.performer.length > 0) {
    return observation.performer[0];
  }

  // Si no hay performer, buscar un practitioner activo en el sistema
  try {
    const practitioners = await medplum.searchResources('Practitioner', {
      active: 'true',
      _count: '1',
    });

    if (practitioners.length > 0) {
      return {
        reference: `Practitioner/${practitioners[0].id}`,
        display: `${practitioners[0].name?.[0]?.given?.join(' ')} ${practitioners[0].name?.[0]?.family}`,
      };
    }
  } catch (error) {
    console.warn('No se pudo obtener Practitioner:', error);
  }

  return undefined;
}
