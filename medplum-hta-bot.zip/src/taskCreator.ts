/**
 * Generador de Recursos Task (FHIR R4)
 *
 * Crea recursos Task para asegurar el seguimiento estructurado
 * de alertas de HTA por parte del equipo de salud
 */

import { MedplumClient } from '@medplum/core';
import { Task, Observation, Reference, CodeableConcept } from '@medplum/fhirtypes';
import { BloodPressureValues, HTAClassification } from './bloodPressureEvaluator.js';

export interface TaskContext {
  observation: Observation;
  patient: Reference;
  practitioner?: Reference;
  classification: HTAClassification;
  bpValues: BloodPressureValues;
}

/**
 * Crea un recurso Task para gestionar el seguimiento de la alerta de HTA
 *
 * @param medplum - Cliente de Medplum
 * @param context - Contexto con la información necesaria
 * @returns El recurso Task creado
 */
export async function createFollowUpTask(
  medplum: MedplumClient,
  context: TaskContext
): Promise<Task> {
  const { observation, patient, practitioner, classification, bpValues } = context;

  // Calcular la fecha límite según la urgencia
  const restriction = calculateRestriction(classification);

  // Definir el código de la tarea
  const taskCode = getTaskCode(classification);

  // Construir la descripción de la tarea
  const description = buildTaskDescription(bpValues, classification);

  // Crear el recurso Task
  const task: Task = {
    resourceType: 'Task',
    status: 'requested',
    intent: 'order',
    priority: classification.priority,
    code: taskCode,
    description,
    for: patient,
    authoredOn: new Date().toISOString(),
    owner: practitioner,
    focus: {
      reference: `Observation/${observation.id}`,
      display: `PA: ${bpValues.systolic}/${bpValues.diastolic} mmHg`,
    },
    restriction,
    businessStatus: {
      text: 'Pendiente de Contacto',
    },
    meta: {
      tag: [
        {
          system: 'http://epa-bienestar.com.ar/fhir/tags',
          code: 'hta-followup',
          display: 'Seguimiento HTA',
        },
        {
          system: 'http://epa-bienestar.com.ar/fhir/tags',
          code: classification.level,
          display: classification.description,
        },
      ],
    },
    // Inputs para la tarea (información adicional)
    input: [
      {
        type: {
          text: 'Valor Sistólico',
        },
        valueInteger: Math.round(bpValues.systolic),
      },
      {
        type: {
          text: 'Valor Diastólico',
        },
        valueInteger: Math.round(bpValues.diastolic),
      },
      {
        type: {
          text: 'Clasificación',
        },
        valueString: classification.description,
      },
      {
        type: {
          text: 'Acción Recomendada',
        },
        valueString: classification.recommendedAction,
      },
    ],
  };

  // Crear el recurso en el servidor FHIR
  const createdTask = await medplum.createResource(task);

  console.log(`Task creado: ${createdTask.id}`);

  return createdTask;
}

/**
 * Calcula la restricción temporal de la tarea según la urgencia
 */
function calculateRestriction(classification: HTAClassification): Task['restriction'] {
  const now = new Date();
  let period;

  if (classification.level === 'HYPERTENSIVE_CRISIS') {
    // Crisis: 2 horas
    const end = new Date(now.getTime() + 2 * 60 * 60 * 1000);
    period = {
      start: now.toISOString(),
      end: end.toISOString(),
    };
  } else if (classification.level === 'HTA_STAGE_2') {
    // HTA Stage 2: 48 horas
    const end = new Date(now.getTime() + 48 * 60 * 60 * 1000);
    period = {
      start: now.toISOString(),
      end: end.toISOString(),
    };
  } else {
    // Otros casos: 7 días
    const end = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    period = {
      start: now.toISOString(),
      end: end.toISOString(),
    };
  }

  return {
    period,
  };
}

/**
 * Obtiene el código de la tarea según la clasificación
 */
function getTaskCode(classification: HTAClassification): CodeableConcept {
  if (classification.level === 'HYPERTENSIVE_CRISIS') {
    return {
      coding: [
        {
          system: 'http://epa-bienestar.com.ar/fhir/CodeSystem/clinical-tasks',
          code: 'emergency-bp-followup',
          display: 'Seguimiento de Emergencia Hipertensiva',
        },
      ],
      text: 'Contacto Inmediato - Crisis Hipertensiva',
    };
  }

  if (classification.level === 'HTA_STAGE_2') {
    return {
      coding: [
        {
          system: 'http://epa-bienestar.com.ar/fhir/CodeSystem/clinical-tasks',
          code: 'urgent-bp-followup',
          display: 'Seguimiento Urgente de HTA No Controlada',
        },
      ],
      text: 'Verificación de HTA No Controlada',
    };
  }

  return {
    coding: [
      {
        system: 'http://epa-bienestar.com.ar/fhir/CodeSystem/clinical-tasks',
        code: 'routine-bp-followup',
        display: 'Seguimiento de Rutina de Presión Arterial',
      },
    ],
    text: 'Seguimiento de Presión Arterial',
  };
}

/**
 * Construye la descripción de la tarea
 */
function buildTaskDescription(bpValues: BloodPressureValues, classification: HTAClassification): string {
  return `
Seguimiento de Presión Arterial Elevada

Valores registrados: ${bpValues.systolic}/${bpValues.diastolic} mmHg
Clasificación: ${classification.description}

ACCIONES A REALIZAR:
${classification.recommendedAction}

CHECKLIST:
☐ Contactar al paciente
☐ Verificar adherencia al tratamiento
☐ Evaluar síntomas asociados
☐ Registrar nueva medición de PA
☐ Ajustar tratamiento si es necesario
☐ Documentar seguimiento
`.trim();
}

/**
 * Actualiza el estado de una Task cuando se completa
 */
export async function completeTask(
  medplum: MedplumClient,
  taskId: string,
  outcome: string,
  notes?: string
): Promise<Task> {
  const task = await medplum.readResource('Task', taskId);

  const updatedTask: Task = {
    ...task,
    status: 'completed',
    businessStatus: {
      text: 'Completado',
    },
    lastModified: new Date().toISOString(),
    output: [
      {
        type: {
          text: 'Resultado del Seguimiento',
        },
        valueString: outcome,
      },
    ],
  };

  if (notes) {
    updatedTask.note = [
      ...(task.note || []),
      {
        text: notes,
        time: new Date().toISOString(),
      },
    ];
  }

  return await medplum.updateResource(updatedTask);
}

/**
 * Cancela una Task (por ejemplo, si fue creada por error)
 */
export async function cancelTask(
  medplum: MedplumClient,
  taskId: string,
  reason: string
): Promise<Task> {
  const task = await medplum.readResource('Task', taskId);

  const cancelledTask: Task = {
    ...task,
    status: 'cancelled',
    businessStatus: {
      text: 'Cancelado',
    },
    statusReason: {
      text: reason,
    },
    lastModified: new Date().toISOString(),
  };

  return await medplum.updateResource(cancelledTask);
}

/**
 * Busca todas las Tasks pendientes de un profesional
 */
export async function getPendingTasks(
  medplum: MedplumClient,
  practitionerId: string
): Promise<Task[]> {
  return await medplum.searchResources('Task', {
    owner: `Practitioner/${practitionerId}`,
    status: 'requested',
    _sort: '-_lastUpdated',
  });
}

/**
 * Busca todas las Tasks de HTA urgentes
 */
export async function getUrgentHTATasks(medplum: MedplumClient): Promise<Task[]> {
  return await medplum.searchResources('Task', {
    status: 'requested',
    priority: 'urgent,stat',
    _tag: 'http://epa-bienestar.com.ar/fhir/tags|hta-followup',
    _sort: 'priority,-_lastUpdated',
  });
}
