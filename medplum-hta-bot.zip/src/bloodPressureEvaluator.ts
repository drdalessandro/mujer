/**
 * Módulo de Evaluación de Presión Arterial
 *
 * Clasifica los valores de PA según las guías clínicas internacionales
 * (ACC/AHA 2017 y adaptaciones locales)
 */

export interface BloodPressureValues {
  systolic: number;
  diastolic: number;
}

export interface HTAClassification {
  level: HTALevel;
  description: string;
  requiresAlert: boolean;
  requiresUrgentAction: boolean;
  priority: 'routine' | 'urgent' | 'stat';
  recommendedAction: string;
}

export enum HTALevel {
  NORMAL = 'NORMAL',
  ELEVATED = 'ELEVATED',
  HTA_STAGE_1 = 'HTA_STAGE_1',
  HTA_STAGE_2 = 'HTA_STAGE_2',
  HYPERTENSIVE_CRISIS = 'HYPERTENSIVE_CRISIS',
}

/**
 * Umbrales clínicos para clasificación de HTA
 * Basado en guías ACC/AHA 2017 y consensos locales
 */
const THRESHOLDS = {
  NORMAL: {
    systolic: 120,
    diastolic: 80,
  },
  ELEVATED: {
    systolic: 130,
    diastolic: 80,
  },
  HTA_STAGE_1: {
    systolic: 140,
    diastolic: 90,
  },
  HTA_STAGE_2: {
    systolic: 160,  // ← Umbral crítico especificado
    diastolic: 100, // ← Umbral crítico especificado
  },
  HYPERTENSIVE_CRISIS: {
    systolic: 180,
    diastolic: 120,
  },
};

/**
 * Evalúa los valores de presión arterial y retorna la clasificación
 *
 * @param values - Valores de presión sistólica y diastólica
 * @returns Clasificación de HTA con nivel de alerta y acciones recomendadas
 */
export function evaluateBloodPressure(values: BloodPressureValues): HTAClassification {
  const { systolic, diastolic } = values;

  // Crisis Hipertensiva (≥ 180/120)
  if (systolic >= THRESHOLDS.HYPERTENSIVE_CRISIS.systolic || diastolic >= THRESHOLDS.HYPERTENSIVE_CRISIS.diastolic) {
    return {
      level: HTALevel.HYPERTENSIVE_CRISIS,
      description: 'Crisis Hipertensiva - Emergencia Médica',
      requiresAlert: true,
      requiresUrgentAction: true,
      priority: 'stat',
      recommendedAction:
        'ACCIÓN INMEDIATA: Contactar al paciente de inmediato. ' +
        'Evaluar síntomas de daño orgánico (cefalea severa, disnea, dolor torácico, cambios visuales). ' +
        'Considerar derivación a emergencias si presenta síntomas.',
    };
  }

  // HTA Stage 2 No Controlada (≥ 160/100)
  if (systolic >= THRESHOLDS.HTA_STAGE_2.systolic || diastolic >= THRESHOLDS.HTA_STAGE_2.diastolic) {
    return {
      level: HTALevel.HTA_STAGE_2,
      description: 'Hipertensión Arterial Estadio 2 - No Controlada',
      requiresAlert: true,
      requiresUrgentAction: true,
      priority: 'urgent',
      recommendedAction:
        'Contactar al paciente dentro de las 24-48 horas. ' +
        'Verificar adherencia al tratamiento. ' +
        'Evaluar necesidad de ajuste de medicación. ' +
        'Descartar causas secundarias o factores desencadenantes.',
    };
  }

  // HTA Stage 1 (140-159 / 90-99)
  if (systolic >= THRESHOLDS.HTA_STAGE_1.systolic || diastolic >= THRESHOLDS.HTA_STAGE_1.diastolic) {
    return {
      level: HTALevel.HTA_STAGE_1,
      description: 'Hipertensión Arterial Estadio 1',
      requiresAlert: false,
      requiresUrgentAction: false,
      priority: 'routine',
      recommendedAction:
        'Seguimiento de rutina. ' +
        'Reforzar cambios en estilo de vida. ' +
        'Evaluar en próximo control programado.',
    };
  }

  // Presión Arterial Elevada (120-129 / <80)
  if (systolic >= THRESHOLDS.ELEVATED.systolic && diastolic < THRESHOLDS.ELEVATED.diastolic) {
    return {
      level: HTALevel.ELEVATED,
      description: 'Presión Arterial Elevada',
      requiresAlert: false,
      requiresUrgentAction: false,
      priority: 'routine',
      recommendedAction:
        'Monitoreo periódico. ' +
        'Reforzar cambios en estilo de vida (dieta DASH, ejercicio, reducción de sal). ' +
        'Mediciones frecuentes para seguimiento.',
    };
  }

  // Presión Arterial Normal (<120 / <80)
  return {
    level: HTALevel.NORMAL,
    description: 'Presión Arterial Normal',
    requiresAlert: false,
    requiresUrgentAction: false,
    priority: 'routine',
    recommendedAction: 'Continuar con controles de rutina y mantenimiento de hábitos saludables.',
  };
}

/**
 * Determina si un valor requiere generación de alerta
 * (HTA Stage 2 o Crisis Hipertensiva)
 */
export function requiresAlert(values: BloodPressureValues): boolean {
  const classification = evaluateBloodPressure(values);
  return classification.requiresAlert;
}

/**
 * Obtiene un mensaje de texto legible para la alerta
 */
export function getAlertMessage(values: BloodPressureValues, classification: HTAClassification): string {
  return (
    `⚠️ ALERTA HTA - ${classification.level}\n\n` +
    `Presión Arterial Registrada: ${values.systolic}/${values.diastolic} mmHg\n` +
    `Clasificación: ${classification.description}\n\n` +
    `${classification.recommendedAction}`
  );
}
