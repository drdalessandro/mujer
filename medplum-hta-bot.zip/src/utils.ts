/**
 * Funciones de utilidad para el Bot HTA
 */

import { Reference } from '@medplum/fhirtypes';

/**
 * Formatea un valor de presión arterial para visualización
 */
export function formatBloodPressure(systolic: number, diastolic: number): string {
  return `${Math.round(systolic)}/${Math.round(diastolic)} mmHg`;
}

/**
 * Extrae el ID de una referencia FHIR
 */
export function extractIdFromReference(reference?: Reference | string): string | undefined {
  if (!reference) return undefined;

  if (typeof reference === 'string') {
    return reference.split('/').pop();
  }

  return reference.reference?.split('/').pop();
}

/**
 * Valida que los valores de PA sean números válidos
 */
export function validateBPValues(systolic: number, diastolic: number): boolean {
  if (isNaN(systolic) || isNaN(diastolic)) {
    return false;
  }

  if (systolic <= 0 || diastolic <= 0) {
    return false;
  }

  if (systolic > 300 || diastolic > 200) {
    return false;
  }

  if (diastolic >= systolic) {
    return false;
  }

  return true;
}

/**
 * Formatea una fecha en formato legible en español
 */
export function formatDate(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date;

  return d.toLocaleString('es-AR', {
    dateStyle: 'full',
    timeStyle: 'short',
  });
}

/**
 * Crea una referencia FHIR a partir de un tipo y un ID
 */
export function createReference(resourceType: string, id: string, display?: string): Reference {
  return {
    reference: `${resourceType}/${id}`,
    display,
  };
}

/**
 * Determina si una referencia es del tipo especificado
 */
export function isReferenceType(reference: Reference | undefined, resourceType: string): boolean {
  if (!reference?.reference) return false;
  return reference.reference.startsWith(`${resourceType}/`);
}

/**
 * Logger con timestamp
 */
export class Logger {
  private prefix: string;

  constructor(prefix: string) {
    this.prefix = prefix;
  }

  info(message: string, ...args: any[]): void {
    console.log(`[${new Date().toISOString()}] [${this.prefix}] INFO:`, message, ...args);
  }

  warn(message: string, ...args: any[]): void {
    console.warn(`[${new Date().toISOString()}] [${this.prefix}] WARN:`, message, ...args);
  }

  error(message: string, ...args: any[]): void {
    console.error(`[${new Date().toISOString()}] [${this.prefix}] ERROR:`, message, ...args);
  }

  debug(message: string, ...args: any[]): void {
    if (process.env.DEBUG) {
      console.debug(`[${new Date().toISOString()}] [${this.prefix}] DEBUG:`, message, ...args);
    }
  }
}

/**
 * Manejo seguro de errores
 */
export function safeStringify(obj: any): string {
  try {
    return JSON.stringify(obj, null, 2);
  } catch {
    return String(obj);
  }
}

/**
 * Calcula la presión arterial media (MAP)
 */
export function calculateMAP(systolic: number, diastolic: number): number {
  return diastolic + (systolic - diastolic) / 3;
}

/**
 * Calcula la presión de pulso
 */
export function calculatePulsePressure(systolic: number, diastolic: number): number {
  return systolic - diastolic;
}
