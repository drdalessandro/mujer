# Arquitectura del Bot HTA - Documentación Técnica

## 🏛️ Arquitectura General

```
┌─────────────────────────────────────────────────────────────────────────┐
│                     EPA BIENESTAR - SISTEMA HTA                          │
│                   https://api.epa-bienestar.com.ar/fhir/r4              │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │
        ┌───────────────────────────┴───────────────────────────┐
        │                                                        │
        ▼                                                        ▼
┌──────────────────┐                                  ┌──────────────────┐
│   MEDPLUM BOT    │                                  │  RECURSOS FHIR   │
│   (Node.js 22)   │◄─────────────────────────────────┤                  │
│                  │         Subscription             │  • Patient       │
│  • Handler       │         (Webhook)                │  • Practitioner  │
│  • Evaluator     │                                  │  • Observation   │
│  • Generators    │                                  │                  │
└──────────────────┘                                  └──────────────────┘
        │
        │ Crea recursos
        │
        ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                         RECURSOS GENERADOS                               │
│  ┌─────────────────────┐              ┌─────────────────────┐           │
│  │   Communication     │              │       Task          │           │
│  │   (Alerta)          │              │   (Seguimiento)     │           │
│  │                     │              │                     │           │
│  │  Priority: urgent   │              │  Status: requested  │           │
│  │  Recipient: Dr.     │              │  Owner: Dr.         │           │
│  │  Payload: Alert     │              │  Deadline: 48h      │           │
│  └─────────────────────┘              └─────────────────────┘           │
└─────────────────────────────────────────────────────────────────────────┘
```

## 🔄 Flujo de Datos Detallado

### 1. Ingreso de Datos (Manual)

```
Usuario/Sistema
     │
     │ Crea/Actualiza
     ▼
Observation (FHIR R4)
├─ resourceType: "Observation"
├─ code: LOINC 85354-9 (Blood Pressure Panel)
├─ subject: Reference(Patient)
└─ component: [
     ├─ Sistólica (LOINC 8480-6): 165 mmHg
     └─ Diastólica (LOINC 8462-4): 105 mmHg
   ]
```

### 2. Trigger del Bot (Automático)

```
Medplum Subscription
     │
     │ Detecta nuevo/updated Observation
     │ con code = 85354-9, 8480-6, o 8462-4
     │
     ▼
Bot Handler
handler(medplum, event)
     │
     ├─ Valida que sea BP Observation ✓
     ├─ Extrae valores Sistólica/Diastólica
     └─ Llama a evaluateBloodPressure()
```

### 3. Evaluación de Presión Arterial

```
bloodPressureEvaluator.ts
evaluateBloodPressure({ systolic, diastolic })
     │
     ├─ Sistólica ≥ 180 o Diastólica ≥ 120?
     │  └─ SÍ → HYPERTENSIVE_CRISIS
     │          priority: "stat"
     │          requiresAlert: true
     │
     ├─ Sistólica ≥ 160 o Diastólica ≥ 100?
     │  └─ SÍ → HTA_STAGE_2
     │          priority: "urgent"
     │          requiresAlert: true
     │
     ├─ Sistólica ≥ 140 o Diastólica ≥ 90?
     │  └─ SÍ → HTA_STAGE_1
     │          requiresAlert: false
     │
     └─ Retorna HTAClassification
```

### 4. Generación de Recursos (Si requiere alerta)

```
Si classification.requiresAlert === true:

┌──────────────────────────────┐
│  createCommunicationAlert()  │
└──────────────────────────────┘
         │
         ├─ Obtiene nombre del paciente
         ├─ Construye mensaje de alerta
         ├─ Define prioridad (urgent/stat)
         └─ Crea Communication en FHIR
              │
              └─ Resultado: Communication ID

┌──────────────────────────────┐
│  createFollowUpTask()        │
└──────────────────────────────┘
         │
         ├─ Calcula deadline según urgencia
         │   • Crisis: 2 horas
         │   • Stage 2: 48 horas
         ├─ Define código de tarea
         ├─ Genera descripción con checklist
         └─ Crea Task en FHIR
              │
              └─ Resultado: Task ID
```

## 📦 Módulos y Responsabilidades

### index.ts (Handler Principal)
**Responsabilidad**: Punto de entrada del Bot, orquestación del flujo

```typescript
handler(medplum, event)
  ├─ isBloodPressureObservation()
  ├─ extractBloodPressureValues()
  ├─ evaluateBloodPressure()
  ├─ getPractitionerReference()
  ├─ createCommunicationAlert()
  └─ createFollowUpTask()
```

### bloodPressureEvaluator.ts
**Responsabilidad**: Lógica clínica de evaluación de PA

```typescript
Interfaces:
  • BloodPressureValues
  • HTAClassification
  • HTALevel (enum)

Funciones:
  • evaluateBloodPressure()
  • requiresAlert()
  • getAlertMessage()

Constantes:
  • THRESHOLDS (umbrales clínicos)
```

### communicationCreator.ts
**Responsabilidad**: Generación de recursos Communication

```typescript
Funciones:
  • createCommunicationAlert()      → Crea alerta inicial
  • createFollowUpCommunication()   → Crea comunicación de seguimiento
  • buildAlertText()                → Formatea mensaje
  • getPatientDisplayName()         → Obtiene nombre del paciente
```

### taskCreator.ts
**Responsabilidad**: Generación y gestión de recursos Task

```typescript
Funciones:
  • createFollowUpTask()       → Crea tarea de seguimiento
  • completeTask()             → Marca tarea como completada
  • cancelTask()               → Cancela una tarea
  • getPendingTasks()          → Lista tareas pendientes
  • getUrgentHTATasks()        → Lista tareas urgentes de HTA

Helpers:
  • calculateRestriction()     → Calcula deadline
  • getTaskCode()              → Define código de tarea
  • buildTaskDescription()     → Genera descripción
```

### types.ts
**Responsabilidad**: Definiciones de tipos y constantes

```typescript
Interfaces:
  • BotConfiguration
  • BPEvaluationResult
  • ExtendedBotContext

Constantes:
  • LOINC_BP_CODES
  • SNOMED_HTA_CODES
  • EPA_TAGS
  • EPA_SYSTEMS
```

### utils.ts
**Responsabilidad**: Funciones de utilidad

```typescript
Funciones:
  • formatBloodPressure()
  • extractIdFromReference()
  • validateBPValues()
  • formatDate()
  • createReference()
  • calculateMAP()              → Presión Arterial Media
  • calculatePulsePressure()    → Presión de Pulso

Clases:
  • Logger                      → Logger con timestamps
```

## 🔐 Seguridad y Permisos

### AccessPolicy Requerida

```json
{
  "resourceType": "AccessPolicy",
  "name": "HTA Bot Policy",
  "resource": [
    {
      "resourceType": "Observation",
      "criteria": "Observation?code=85354-9,8480-6,8462-4",
      "readonly": true
    },
    {
      "resourceType": "Patient",
      "readonly": true
    },
    {
      "resourceType": "Practitioner",
      "readonly": true
    },
    {
      "resourceType": "Communication",
      "writeonly": false
    },
    {
      "resourceType": "Task",
      "writeonly": false
    }
  ]
}
```

### Flujo de Autenticación

```
Bot Execution Context
     │
     ├─ Bot Identity (ClientApplication)
     │    └─ Scopes: system/*.read, system/Communication.write, system/Task.write
     │
     └─ MedplumClient
          └─ Autenticado automáticamente por Medplum runtime
```

## 📊 Modelo de Datos

### Observation (Input)

```
Observation
├─ id: "obs-123"
├─ status: "final"
├─ code:
│   └─ coding:
│       ├─ system: "http://loinc.org"
│       └─ code: "85354-9"
├─ subject:
│   └─ reference: "Patient/patient-456"
├─ effectiveDateTime: "2025-12-04T10:30:00-03:00"
├─ performer:
│   └─ reference: "Practitioner/pract-789"
└─ component:
    ├─ [0]:
    │   ├─ code: LOINC 8480-6 (Systolic)
    │   └─ valueQuantity: 165 mmHg
    └─ [1]:
        ├─ code: LOINC 8462-4 (Diastolic)
        └─ valueQuantity: 105 mmHg
```

### Communication (Output)

```
Communication
├─ id: "comm-abc"
├─ status: "completed"
├─ priority: "urgent" | "stat"
├─ subject: Reference(Patient)
├─ recipient: [Reference(Practitioner)]
├─ sent: "2025-12-04T10:30:05-03:00"
├─ payload:
│   └─ contentString: "⚠️ ALERTA HTA..."
├─ reasonReference:
│   └─ Reference(Observation/obs-123)
├─ category:
│   └─ coding: "alert"
└─ meta:
    └─ tag:
        ├─ "hta-alert"
        └─ "HTA_STAGE_2"
```

### Task (Output)

```
Task
├─ id: "task-xyz"
├─ status: "requested" → "in-progress" → "completed"
├─ intent: "order"
├─ priority: "urgent" | "stat"
├─ code:
│   └─ coding: "urgent-bp-followup"
├─ description: "Seguimiento de PA..."
├─ for: Reference(Patient)
├─ owner: Reference(Practitioner)
├─ authoredOn: "2025-12-04T10:30:05-03:00"
├─ focus: Reference(Observation/obs-123)
├─ restriction:
│   └─ period:
│       ├─ start: "2025-12-04T10:30:05-03:00"
│       └─ end: "2025-12-06T10:30:05-03:00" (48h)
├─ businessStatus: "Pendiente de Contacto"
├─ input:
│   ├─ Valor Sistólico: 165
│   ├─ Valor Diastólico: 105
│   └─ Acción Recomendada: "..."
└─ meta:
    └─ tag:
        ├─ "hta-followup"
        └─ "HTA_STAGE_2"
```

## ⚡ Performance y Escalabilidad

### Tiempo de Ejecución Esperado

```
Observation creada
     │
     ├─ < 100ms → Subscription trigger
     ├─ < 50ms  → Bot handler inicia
     ├─ < 10ms  → Evaluación de PA
     ├─ < 200ms → Creación de Communication
     ├─ < 200ms → Creación de Task
     │
     └─ TOTAL: ~560ms desde Observation a recursos generados
```

### Volumen Soportado

- **Observations/día**: ~10,000
- **Alertas generadas/día**: ~500-1000 (5-10% de observations)
- **Tasks concurrentes**: Ilimitadas (gestionadas por FHIR server)

### Optimizaciones

1. **Índices FHIR**: Asegurar índices en:
   - `Observation.code`
   - `Task.owner + Task.status`
   - `Communication._tag`

2. **Caching**: Datos estáticos cacheados:
   - Practitioner references
   - Patient names (opcional)

## 🧪 Testing Strategy

### Unit Tests

```typescript
// Ejemplo de test
describe('evaluateBloodPressure', () => {
  it('detecta HTA Stage 2 con 160/100', () => {
    const result = evaluateBloodPressure({ systolic: 160, diastolic: 100 });
    expect(result.level).toBe(HTALevel.HTA_STAGE_2);
    expect(result.requiresAlert).toBe(true);
  });

  it('detecta Crisis con 180/120', () => {
    const result = evaluateBloodPressure({ systolic: 180, diastolic: 120 });
    expect(result.level).toBe(HTALevel.HYPERTENSIVE_CRISIS);
    expect(result.priority).toBe('stat');
  });
});
```

### Integration Tests

```bash
# Test end-to-end
1. Crear Patient
2. Crear Practitioner
3. Crear Observation con PA 165/105
4. Verificar Communication creado
5. Verificar Task creado
6. Completar Task
7. Verificar Task.status = completed
```

## 📈 Monitoreo y Métricas

### Métricas Clave

```
KPIs del Bot:
├─ Tasa de ejecución exitosa: > 99%
├─ Tiempo promedio de ejecución: < 1s
├─ Alertas generadas/día: tracking
├─ Tasks completadas/24h: > 90%
├─ Tasks vencidas: < 5%
└─ Errores: < 0.1%
```

### Logs Estructurados

```typescript
// Ejemplo de log
{
  "timestamp": "2025-12-04T10:30:05.123Z",
  "level": "info",
  "botId": "hta-alert-bot",
  "observationId": "obs-123",
  "patientId": "patient-456",
  "classification": "HTA_STAGE_2",
  "values": { "systolic": 165, "diastolic": 105 },
  "communicationId": "comm-abc",
  "taskId": "task-xyz",
  "executionTime": 523
}
```

## 🔄 Ciclo de Vida Completo

```
1. DETECCIÓN
   Observation creada → Bot triggered

2. EVALUACIÓN
   Valores extraídos → Clasificación HTA

3. ALERTA
   Communication creado → Profesional notificado

4. ASIGNACIÓN
   Task creado → Profesional asignado

5. SEGUIMIENTO
   Profesional contacta paciente

6. ACCIÓN
   Ajuste de tratamiento / Derivación

7. DOCUMENTACIÓN
   Task completado con notas

8. CIERRE
   Communication de seguimiento (opcional)

9. AUDITORÍA
   AuditEvent registrado automáticamente
```

---

**Actualización**: Diciembre 2025
**Versión del Bot**: 1.0.0
**FHIR Version**: R4
**Node.js**: ≥22.0.0
