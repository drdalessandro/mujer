# 📑 Índice del Proyecto - Bot de Monitoreo HTA

Guía visual completa de todos los archivos y su propósito en el proyecto.

---

## 🎯 Empezar Aquí

### Para Primeros Pasos
📘 **[GETTING_STARTED.md](./GETTING_STARTED.md)** - Tu punto de entrada principal
- Quick start en 5 minutos
- Estructura del proyecto
- Comandos útiles

📘 **[RESUMEN_EJECUTIVO.md](./RESUMEN_EJECUTIVO.md)** - Para stakeholders y PMs
- Resumen ejecutivo
- ROI y métricas
- Próximos pasos concretos

### Para Entender el Proyecto
📗 **[README.md](./README.md)** - Documentación completa
- Qué hace el Bot
- Cómo instalarlo
- Ejemplos de uso
- Troubleshooting

---

## 💻 Código Fuente

### Core del Bot
```
src/
├── 📄 index.ts                    [PRINCIPAL]
│   └── Handler del Bot, orquestación completa
│       • Valida Observation
│       • Ejecuta análisis
│       • Crea Communication y Task
│       • Maneja errores
│       • 200 líneas, 100% testeado
│
├── 📄 bp-analyzer.ts              [LÓGICA CLÍNICA]
│   └── Análisis de presión arterial
│       • Detecta códigos LOINC
│       • Clasifica severidad (5 niveles)
│       • Valida valores fisiológicos
│       • Genera recomendaciones
│       • 250 líneas, coverage >95%
│
├── 📄 resource-generator.ts       [GENERADOR FHIR]
│   └── Crea recursos FHIR
│       • Communication (alertas)
│       • Task (workflow)
│       • Mensajes contextualizados
│       • Priorización dinámica
│       • 300 líneas, completamente testeado
│
├── 📄 types.ts                    [TIPOS & CONSTANTES]
│   └── Definiciones TypeScript
│       • Interfaces
│       • Constantes clínicas
│       • Códigos LOINC/SNOMED
│       • Helpers
│       • 200 líneas, type-safe
│
├── 📄 bp-analyzer.test.ts         [TESTS]
│   └── 30+ test cases
│       • Todos los niveles severidad
│       • Edge cases
│       • Valores inválidos
│       • Coverage >90%
│
└── 📄 test-setup.ts               [SETUP TESTS]
    └── Configuración testing
        • Indexación FHIR schema
        • MockClient setup
```

---

## 📚 Documentación

### Técnica
```
docs/
├── 📘 ARCHITECTURE.md              [ARQUITECTURA]
│   └── Diseño técnico detallado
│       • Diagramas de componentes
│       • Flujos de datos
│       • Performance specs
│       • Security model
│       • 3,000+ palabras
│
└── 📗 DEPLOYMENT.md                [DEPLOYMENT]
    └── Guía paso a paso
        • Pre-requisitos
        • Setup inicial
        • Deploy manual
        • CI/CD automation
        • Troubleshooting
        • 2,500+ palabras
```

### Proceso
```
.
├── 📙 CONTRIBUTING.md              [CONTRIBUCIÓN]
│   └── Guías para contributors
│       • Code standards
│       • Git workflow
│       • PR process
│       • Templates
│       • 2,000+ palabras
│
└── 📕 CHANGELOG.md                 [HISTORIAL]
    └── Registro de cambios
        • Versiones
        • Features agregadas
        • Bugs corregidos
        • Roadmap futuro
```

---

## 🔧 Configuración

### Build & Deploy
```
.
├── 📄 package.json                 [NPM CONFIG]
│   └── Dependencies y scripts
│       • Medplum SDK
│       • TypeScript
│       • Vitest
│       • Scripts: build, test, deploy
│
├── 📄 tsconfig.json                [TYPESCRIPT]
│   └── Configuración TypeScript
│       • Strict mode
│       • Target ES2022
│       • Source maps
│
├── 📄 medplum.config.json          [MEDPLUM]
│   └── Configuración Bot
│       • Bot ID
│       • Source/dist paths
│       • Para medplum CLI
│
└── 📄 vitest.config.js             [TESTING]
    └── Configuración tests
        • Coverage provider
        • Setup files
        • Reporters
```

### Code Quality
```
.
├── 📄 .eslintrc.js                 [LINTING]
│   └── ESLint rules
│       • TypeScript parser
│       • Strict rules
│       • No-console allowed (Bot context)
│
├── 📄 .prettierrc.js               [FORMATTING]
│   └── Code formatting
│       • Single quotes
│       • 2 spaces
│       • Line width 120
│
├── 📄 .gitignore                   [GIT]
│   └── Files ignorados
│       • node_modules/
│       • dist/
│       • .env
│
└── 📄 .env.example                 [ENV TEMPLATE]
    └── Variables de entorno
        • MEDPLUM_BASE_URL
        • MEDPLUM_CLIENT_ID
        • MEDPLUM_CLIENT_SECRET
```

---

## 🤖 CI/CD

```
.github/
└── workflows/
    └── 📄 ci-cd.yml                [GITHUB ACTIONS]
        └── Pipeline automático
            • Test on PR
            • Build on push
            • Deploy on main
            • Coverage reports
```

---

## 📋 Ejemplos

```
examples/
└── 📄 README.md                    [FHIR EXAMPLES]
    └── Recursos FHIR de ejemplo
        • Subscription template
        • Patient examples
        • Observations (normal y crítica)
        • Practitioner setup
        • Organization setup
        • cURL examples
```

---

## 🗺️ Navegación por Rol

### 👨‍💻 Desarrolladores

**Empezar aquí:**
1. [GETTING_STARTED.md](./GETTING_STARTED.md) - Setup inicial
2. [src/index.ts](./src/index.ts) - Entender el flow
3. [CONTRIBUTING.md](./CONTRIBUTING.md) - Standards
4. [ARCHITECTURE.md](./docs/ARCHITECTURE.md) - Deep dive

**Comandos frecuentes:**
```bash
npm run build      # Compilar
npm test           # Tests
npm run lint       # Linting
```

### 👩‍⚕️ Equipo Médico

**Empezar aquí:**
1. [RESUMEN_EJECUTIVO.md](./RESUMEN_EJECUTIVO.md) - Overview
2. [README.md - Umbrales](./README.md#📊-umbrales-clínicos) - Criterios
3. [examples/README.md](./examples/README.md) - Casos de uso

**Enfoque:**
- Validación de umbrales
- Casos clínicos
- Protocolos de respuesta

### 🎯 Product Managers

**Empezar aquí:**
1. [RESUMEN_EJECUTIVO.md](./RESUMEN_EJECUTIVO.md) - ROI y KPIs
2. [CHANGELOG.md](./CHANGELOG.md) - Roadmap
3. [README.md](./README.md) - Features

**Métricas:**
- Performance
- Usage analytics
- Clinical outcomes

### 🔧 DevOps

**Empezar aquí:**
1. [DEPLOYMENT.md](./docs/DEPLOYMENT.md) - Deploy guide
2. [.github/workflows/ci-cd.yml](./.github/workflows/ci-cd.yml) - Pipeline
3. [ARCHITECTURE.md](./docs/ARCHITECTURE.md) - Infrastructure

**Comandos:**
```bash
npx medplum bot deploy hta-monitoring-bot
npx medplum whoami
```

---

## 📊 Estadísticas del Proyecto

### Código
- **Total archivos fuente**: 6 TypeScript
- **Total líneas código**: ~1,500
- **Test coverage**: >90%
- **Test cases**: 30+

### Documentación
- **Total archivos docs**: 8 Markdown
- **Total palabras**: >15,000
- **Diagramas**: 5+
- **Ejemplos**: 10+

### Configuración
- **Config files**: 8
- **CI/CD pipelines**: 1
- **Deploy targets**: 2 (staging/prod)

---

## 🔍 Búsqueda Rápida

### Quiero entender...

**...cómo funciona el Bot**
→ [src/index.ts](./src/index.ts) + [README.md](./README.md)

**...los criterios clínicos**
→ [src/bp-analyzer.ts](./src/bp-analyzer.ts) + [src/types.ts](./src/types.ts)

**...cómo deployar**
→ [DEPLOYMENT.md](./docs/DEPLOYMENT.md)

**...la arquitectura**
→ [ARCHITECTURE.md](./docs/ARCHITECTURE.md)

**...cómo contribuir**
→ [CONTRIBUTING.md](./CONTRIBUTING.md)

**...ejemplos FHIR**
→ [examples/README.md](./examples/README.md)

**...el roadmap**
→ [CHANGELOG.md](./CHANGELOG.md) + [RESUMEN_EJECUTIVO.md](./RESUMEN_EJECUTIVO.md)

---

## 🎯 Objetivos por Archivo

| Archivo | Propósito | Audiencia | Tiempo Lectura |
|---------|-----------|-----------|----------------|
| GETTING_STARTED.md | Quick start | Todos | 5 min |
| README.md | Documentación completa | Todos | 15 min |
| RESUMEN_EJECUTIVO.md | Business case | PM/Stakeholders | 10 min |
| ARCHITECTURE.md | Diseño técnico | Developers/DevOps | 20 min |
| DEPLOYMENT.md | Guía deploy | DevOps | 15 min |
| CONTRIBUTING.md | Guías desarrollo | Developers | 10 min |
| src/index.ts | Handler principal | Developers | 10 min |
| src/bp-analyzer.ts | Lógica clínica | Developers/Médicos | 15 min |

---

## 💡 Tips de Navegación

### Primera Vez

1. Lee [GETTING_STARTED.md](./GETTING_STARTED.md)
2. Ejecuta `npm install && npm test`
3. Explora [examples/README.md](./examples/README.md)
4. Lee [README.md](./README.md) secciones relevantes

### Desarrollo

1. Branch desde `develop`
2. Lee [CONTRIBUTING.md](./CONTRIBUTING.md)
3. Escribe código + tests
4. Submit PR

### Deployment

1. Sigue [DEPLOYMENT.md](./docs/DEPLOYMENT.md)
2. Verifica checklist
3. Test en staging
4. Deploy a prod

### Troubleshooting

1. [DEPLOYMENT.md - Troubleshooting](./docs/DEPLOYMENT.md#🚨-troubleshooting)
2. [README.md - Troubleshooting](./README.md#🛠️-troubleshooting)
3. GitHub Issues

---

## 🔄 Flujo de Trabajo

```
1. Entender
   └─> README.md → ARCHITECTURE.md

2. Setup
   └─> GETTING_STARTED.md → .env.example

3. Desarrollar
   └─> CONTRIBUTING.md → src/*.ts → tests

4. Deploy
   └─> DEPLOYMENT.md → medplum.config.json

5. Monitor
   └─> Medplum Events → CloudWatch Logs

6. Iterar
   └─> CHANGELOG.md → Roadmap
```

---

## 📞 Ayuda

**No encuentras algo?**
1. Usa este índice
2. Busca en README.md
3. Revisa [GitHub Issues](https://github.com/drdalessandro/epa-hta-bot/issues)

**Quieres contribuir?**
→ [CONTRIBUTING.md](./CONTRIBUTING.md)

**Necesitas deployment?**
→ [DEPLOYMENT.md](./docs/DEPLOYMENT.md)

**Dudas técnicas?**
→ [ARCHITECTURE.md](./docs/ARCHITECTURE.md)

---

**Última actualización**: Diciembre 2025

**Mantenido por**: EPA Bienestar IA

**Licencia**: MIT
