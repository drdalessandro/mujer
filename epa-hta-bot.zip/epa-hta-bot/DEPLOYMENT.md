# Guía de Deployment - EPA HTA Bot

## Pre-requisitos

### 1. Cuenta de Medplum
- Crear cuenta en [Medplum](https://app.medplum.com/)
- Configurar Project para EPA Bienestar IA
- Obtener credenciales de API

### 2. Herramientas Necesarias
```bash
node --version  # >= 18.x
npm --version   # >= 9.x
git --version
```

## Pasos de Deployment

### Paso 1: Configurar el Proyecto Medplum

1. Iniciar sesión en Medplum Console
2. Ir a **Project Settings** > **Bots**
3. Crear un nuevo Bot:
   - **Name**: `epa-hta-alert-bot`
   - **Description**: Bot de alertas automáticas de HTA
   - **Runtime**: AWS Lambda
   - **Timeout**: 10 segundos

4. Copiar el **Bot ID** generado

### Paso 2: Configurar medplum.config.json

Editar el archivo y reemplazar `CHANGE_THIS_TO_YOUR_BOT_ID`:

```json
{
  "bots": [
    {
      "name": "epa-hta-alert-bot",
      "id": "TU_BOT_ID_AQUÍ",
      "source": "src/index.ts",
      "dist": "dist/index.js"
    }
  ]
}
```

### Paso 3: Configurar Subscription

El bot necesita una **Subscription** para ejecutarse automáticamente:

1. En Medplum Console, ir a **Resources** > **Subscription**
2. Crear nueva Subscription:

```json
{
  "resourceType": "Subscription",
  "status": "active",
  "reason": "Alertas automáticas de HTA para EPA Bienestar IA",
  "criteria": "Observation?code=http://loinc.org|85354-9",
  "channel": {
    "type": "rest-hook",
    "endpoint": "Bot/[TU_BOT_ID]",
    "payload": "application/fhir+json"
  }
}
```

**IMPORTANTE**: Reemplazar `[TU_BOT_ID]` con el ID de tu bot.

### Paso 4: Instalar Dependencias

```bash
cd epa-hta-bot
npm install
```

### Paso 5: Compilar el Código

```bash
npm run build
```

Esto generará el archivo `dist/index.js` que se desplegará en Medplum.

### Paso 6: Desplegar a Medplum

```bash
npm run deploy
```

O manualmente:

1. Copiar el contenido de `dist/index.js`
2. En Medplum Console, ir a tu Bot
3. Pegar el código en el editor
4. Click en **Save**

### Paso 7: Verificar Deployment

#### Probar con Observation de Prueba

Crear una Observation de PA en Medplum:

```bash
curl -X POST https://api.medplum.com/fhir/R4/Observation \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/fhir+json" \
  -d @examples/observation-pa-critica.json
```

O usar Medplum Console:
1. Ir a **Resources** > **Observation** > **Create New**
2. Copiar contenido de `examples/observation-pa-critica.json`
3. Click en **Create**

#### Verificar Logs

En Medplum Console:
1. Ir a **Bots** > Tu Bot > **Logs**
2. Verificar que el bot se ejecutó
3. Revisar logs para errores

#### Verificar Recursos Creados

Verificar que se crearon:
- **Communication**: Búsqueda por `Communication?subject=Patient/[PATIENT_ID]`
- **Task**: Búsqueda por `Task?for=Patient/[PATIENT_ID]`

## Configuración de Practitioners

### Crear Practitioners del Equipo Médico

Crear recursos Practitioner para cada miembro del equipo:

```bash
# Dra. Analía Aquieri
curl -X POST https://api.medplum.com/fhir/R4/Practitioner \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/fhir+json" \
  -d @examples/practitioner-dra-aquieri.json
```

Repetir para:
- Dra. Verónica Crosa
- Dra. Marisa Pages
- Dra. Viviana Cavenago
- Mg. Giovanna Sanguinetti

## Configuración de Grupos de Pacientes

### Crear FHIR Groups para A/B/C/D

```json
{
  "resourceType": "Group",
  "type": "person",
  "actual": true,
  "code": {
    "text": "Grupo B - Planificación de Maternidad"
  },
  "name": "grupo-b-maternidad",
  "quantity": 0,
  "characteristic": [
    {
      "code": {
        "text": "Rango de Edad"
      },
      "valueRange": {
        "low": {
          "value": 28,
          "unit": "años"
        },
        "high": {
          "value": 40,
          "unit": "años"
        }
      },
      "exclude": false
    }
  ]
}
```

## Configuración de Notificaciones

### Configurar Email/SMS (Opcional)

Para enviar notificaciones reales:

1. En Medplum Console, configurar **Email Settings**
2. Configurar integración con servicio SMS (ej. Twilio)
3. Actualizar `createCommunicationAlert` para incluir envío

## Monitoreo y Mantenimiento

### Dashboard de Métricas

Crear queries para monitorear:

```bash
# Total de alertas generadas hoy
GET /Communication?sent=ge2025-12-04&category=alert&_summary=count

# Tasks pendientes
GET /Task?status=requested&_summary=count

# Observations procesados
GET /Observation?code=85354-9&date=ge2025-12-04&_summary=count
```

### Logs

Monitorear logs regularmente:
- Errores de ejecución
- Tiempo de respuesta
- Alertas generadas

### Actualizaciones

Para actualizar el bot:

```bash
# 1. Hacer cambios en src/
# 2. Compilar
npm run build

# 3. Desplegar
npm run deploy
```

## Troubleshooting

### El bot no se ejecuta

1. Verificar que la Subscription esté activa
2. Verificar criterios de la Subscription
3. Revisar logs del bot

### No se crean Communication/Task

1. Verificar que existan Practitioners en el sistema
2. Revisar logs de errores
3. Verificar permisos del bot

### Errores de compilación

```bash
# Limpiar y reinstalar
npm run clean
rm -rf node_modules package-lock.json
npm install
npm run build
```

## Rollback

Si hay problemas:

1. En Medplum Console, ir al Bot
2. Ver **History** de versiones anteriores
3. Restaurar versión anterior

## Seguridad

### Mejores Prácticas

1. **No hardcodear credenciales** en el código
2. Usar **variables de entorno** para configuración sensible
3. Implementar **rate limiting** para evitar abuso
4. **Auditar logs** regularmente
5. Mantener **TypeScript strict mode** habilitado

### Cumplimiento

- ✅ HIPAA Compliant (Medplum + AWS)
- ✅ Encriptación en tránsito (TLS)
- ✅ Encriptación en reposo (AWS)
- ✅ Logs auditables
- ✅ Control de acceso basado en roles

## Soporte

Para ayuda:
- Documentación Medplum: https://docs.medplum.com
- GitHub Issues: https://github.com/drdalessandro/epa-hta-bot/issues
- Email: alejandro@epa-bienestar.com.ar

---

**Última actualización**: Diciembre 2025  
**Versión**: 1.0.0  
**Autor**: Alejandro D'Alessandro - EPA Bienestar IA
