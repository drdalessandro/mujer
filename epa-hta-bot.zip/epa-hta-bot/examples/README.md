# Ejemplos de Recursos FHIR para Configuración

Este directorio contiene ejemplos de recursos FHIR necesarios para configurar y operar el Bot de Monitoreo de HTA.

## 📋 Subscription para Activación Automática

La Subscription configura el trigger automático del Bot cuando se crean o actualizan Observations de presión arterial.

### Crear en Medplum

1. Navegar a `https://app.medplum.com/Subscription`
2. Click en "New..."
3. Copiar y pegar el JSON de `subscription.json`
4. Reemplazar `TU_BOT_ID` con el ID real de tu Bot
5. Guardar

### subscription.json

```json
{
  "resourceType": "Subscription",
  "status": "active",
  "reason": "Monitoreo automático de presión arterial crítica - EPA Bienestar IA",
  "criteria": "Observation?code=http://loinc.org|85354-9,http://loinc.org|8480-6,http://loinc.org|8462-4",
  "channel": {
    "type": "rest-hook",
    "endpoint": "Bot/TU_BOT_ID",
    "payload": "application/fhir+json",
    "header": ["Authorization: Bearer ${secret}"]
  },
  "meta": {
    "tag": [
      {
        "system": "http://epa-bienestar.com.ar/fhir/tags",
        "code": "cardiovascular-monitoring",
        "display": "Sistema de Monitoreo Cardiovascular"
      }
    ]
  }
}
```

## 👤 Patient de Ejemplo

### patient-ejemplo.json

```json
{
  "resourceType": "Patient",
  "identifier": [
    {
      "system": "http://epa-bienestar.com.ar/fhir/identifier/patient",
      "value": "EPA-12345"
    }
  ],
  "active": true,
  "name": [
    {
      "use": "official",
      "family": "González",
      "given": ["María", "Elena"]
    }
  ],
  "telecom": [
    {
      "system": "phone",
      "value": "+54 9 11 5555-1234",
      "use": "mobile"
    },
    {
      "system": "email",
      "value": "maria.gonzalez@example.com"
    }
  ],
  "gender": "female",
  "birthDate": "1985-03-15",
  "address": [
    {
      "use": "home",
      "type": "both",
      "text": "Av. Corrientes 1234, CABA",
      "city": "Buenos Aires",
      "state": "Buenos Aires",
      "postalCode": "C1043",
      "country": "AR"
    }
  ],
  "extension": [
    {
      "url": "http://epa-bienestar.com.ar/fhir/StructureDefinition/grupo-etario",
      "valueString": "Grupo B"
    }
  ]
}
```

## 📊 Observation de PA Normal

### observation-normal.json

```json
{
  "resourceType": "Observation",
  "status": "final",
  "category": [
    {
      "coding": [
        {
          "system": "http://terminology.hl7.org/CodeSystem/observation-category",
          "code": "vital-signs",
          "display": "Vital Signs"
        }
      ]
    }
  ],
  "code": {
    "coding": [
      {
        "system": "http://loinc.org",
        "code": "85354-9",
        "display": "Blood pressure panel with all children optional"
      }
    ],
    "text": "Presión Arterial"
  },
  "subject": {
    "reference": "Patient/TU_PATIENT_ID",
    "display": "María Elena González"
  },
  "effectiveDateTime": "2025-12-04T10:30:00Z",
  "component": [
    {
      "code": {
        "coding": [
          {
            "system": "http://loinc.org",
            "code": "8480-6",
            "display": "Systolic blood pressure"
          }
        ],
        "text": "Presión Sistólica"
      },
      "valueQuantity": {
        "value": 120,
        "unit": "mmHg",
        "system": "http://unitsofmeasure.org",
        "code": "mm[Hg]"
      }
    },
    {
      "code": {
        "coding": [
          {
            "system": "http://loinc.org",
            "code": "8462-4",
            "display": "Diastolic blood pressure"
          }
        ],
        "text": "Presión Diastólica"
      },
      "valueQuantity": {
        "value": 80,
        "unit": "mmHg",
        "system": "http://unitsofmeasure.org",
        "code": "mm[Hg]"
      }
    }
  ],
  "method": {
    "coding": [
      {
        "system": "http://snomed.info/sct",
        "code": "704042003",
        "display": "Non-invasive blood pressure measurement"
      }
    ]
  }
}
```

## ⚠️ Observation de PA Crítica

### observation-critica.json

```json
{
  "resourceType": "Observation",
  "status": "final",
  "category": [
    {
      "coding": [
        {
          "system": "http://terminology.hl7.org/CodeSystem/observation-category",
          "code": "vital-signs",
          "display": "Vital Signs"
        }
      ]
    }
  ],
  "code": {
    "coding": [
      {
        "system": "http://loinc.org",
        "code": "85354-9",
        "display": "Blood pressure panel with all children optional"
      }
    ],
    "text": "Presión Arterial"
  },
  "subject": {
    "reference": "Patient/TU_PATIENT_ID",
    "display": "María Elena González"
  },
  "effectiveDateTime": "2025-12-04T10:30:00Z",
  "component": [
    {
      "code": {
        "coding": [
          {
            "system": "http://loinc.org",
            "code": "8480-6",
            "display": "Systolic blood pressure"
          }
        ],
        "text": "Presión Sistólica"
      },
      "valueQuantity": {
        "value": 185,
        "unit": "mmHg",
        "system": "http://unitsofmeasure.org",
        "code": "mm[Hg]"
      },
      "interpretation": [
        {
          "coding": [
            {
              "system": "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
              "code": "HH",
              "display": "Critical high"
            }
          ]
        }
      ]
    },
    {
      "code": {
        "coding": [
          {
            "system": "http://loinc.org",
            "code": "8462-4",
            "display": "Diastolic blood pressure"
          }
        ],
        "text": "Presión Diastólica"
      },
      "valueQuantity": {
        "value": 125,
        "unit": "mmHg",
        "system": "http://unitsofmeasure.org",
        "code": "mm[Hg]"
      },
      "interpretation": [
        {
          "coding": [
            {
              "system": "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
              "code": "HH",
              "display": "Critical high"
            }
          ]
        }
      ]
    }
  ],
  "method": {
    "coding": [
      {
        "system": "http://snomed.info/sct",
        "code": "704042003",
        "display": "Non-invasive blood pressure measurement"
      }
    ]
  },
  "note": [
    {
      "text": "Paciente reporta cefalea intensa y alteraciones visuales"
    }
  ]
}
```

## 👩‍⚕️ Practitioner Responsable

### practitioner-cardiologa.json

```json
{
  "resourceType": "Practitioner",
  "identifier": [
    {
      "system": "http://www.sac.org.ar/matricula",
      "value": "MP-54321"
    }
  ],
  "active": true,
  "name": [
    {
      "use": "official",
      "family": "Aquieri",
      "given": ["Analía"],
      "prefix": ["Dra."]
    }
  ],
  "telecom": [
    {
      "system": "phone",
      "value": "+54 9 11 4444-5678",
      "use": "work"
    },
    {
      "system": "email",
      "value": "a.aquieri@epa-bienestar.com.ar",
      "use": "work"
    }
  ],
  "qualification": [
    {
      "code": {
        "coding": [
          {
            "system": "http://terminology.hl7.org/CodeSystem/v2-0360",
            "code": "MD",
            "display": "Doctor of Medicine"
          }
        ],
        "text": "Médica Cardióloga"
      },
      "issuer": {
        "display": "Sociedad Argentina de Cardiología"
      }
    }
  ]
}
```

## 🏥 Organization

### organization-epa.json

```json
{
  "resourceType": "Organization",
  "identifier": [
    {
      "system": "http://www.argentina.gob.ar/cuit",
      "value": "30-12345678-9"
    }
  ],
  "active": true,
  "type": [
    {
      "coding": [
        {
          "system": "http://terminology.hl7.org/CodeSystem/organization-type",
          "code": "prov",
          "display": "Healthcare Provider"
        }
      ]
    }
  ],
  "name": "EPA Bienestar IA",
  "telecom": [
    {
      "system": "phone",
      "value": "+54 11 5555-0000",
      "use": "work"
    },
    {
      "system": "email",
      "value": "info@epa-bienestar.com.ar",
      "use": "work"
    },
    {
      "system": "url",
      "value": "https://epa-bienestar.com.ar",
      "use": "work"
    }
  ],
  "address": [
    {
      "use": "work",
      "type": "both",
      "text": "Av. Libertador 1234, Buenos Aires",
      "city": "Buenos Aires",
      "state": "Buenos Aires",
      "country": "AR"
    }
  ]
}
```

---

## 🚀 Quick Start con Postman/cURL

### 1. Crear Patient

```bash
curl -X POST https://api.medplum.com/fhir/R4/Patient \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/fhir+json" \
  -d @examples/patient-ejemplo.json
```

### 2. Crear Observation Normal

```bash
curl -X POST https://api.medplum.com/fhir/R4/Observation \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/fhir+json" \
  -d @examples/observation-normal.json
```

### 3. Crear Observation Crítica (Activa el Bot)

```bash
curl -X POST https://api.medplum.com/fhir/R4/Observation \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/fhir+json" \
  -d @examples/observation-critica.json
```

---

## 📝 Notas

- Reemplazar `TU_BOT_ID`, `TU_PATIENT_ID`, etc. con IDs reales
- Los ejemplos usan datos ficticios
- Adaptar según necesidades específicas del proyecto
