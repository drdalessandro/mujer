# Inicio Rápido - EPA HTA Bot ⚡

Despliega el bot en **menos de 10 minutos**.

## 📋 Prerrequisitos

- [x] Cuenta Medplum ([crear aquí](https://app.medplum.com))
- [x] Node.js 18+ instalado
- [x] Git instalado

## 🚀 5 Pasos para Desplegar

### 1️⃣ Clonar el Repositorio (1 min)

```bash
git clone https://github.com/drdalessandro/epa-hta-bot.git
cd epa-hta-bot
```

### 2️⃣ Instalar Dependencias (2 min)

```bash
npm install
```

### 3️⃣ Crear Bot en Medplum (2 min)

1. Ir a [Medplum Console](https://app.medplum.com)
2. **Project Settings** > **Bots** > **Create New Bot**
3. Nombre: `epa-hta-alert-bot`
4. Runtime: `AWS Lambda`
5. Copiar el **Bot ID** generado

### 4️⃣ Configurar (1 min)

Editar `medplum.config.json`:

```json
{
  "bots": [
    {
      "name": "epa-hta-alert-bot",
      "id": "PEGAR_TU_BOT_ID_AQUI",  // ⬅️ Reemplazar
      "source": "src/index.ts",
      "dist": "dist/index.js"
    }
  ]
}
```

### 5️⃣ Compilar y Desplegar (2 min)

```bash
# Compilar
npm run build

# Desplegar
npm run deploy
```

## ✅ Verificar Instalación

### Crear Observation de Prueba

```bash
curl -X POST https://api.medplum.com/fhir/R4/Observation \
  -H "Authorization: Bearer TU_ACCESS_TOKEN" \
  -H "Content-Type: application/fhir+json" \
  -d '{
    "resourceType": "Observation",
    "status": "final",
    "category": [{
      "coding": [{
        "system": "http://terminology.hl7.org/CodeSystem/observation-category",
        "code": "vital-signs"
      }]
    }],
    "code": {
      "coding": [{
        "system": "http://loinc.org",
        "code": "85354-9",
        "display": "Blood pressure panel"
      }]
    },
    "subject": {
      "reference": "Patient/TU_PATIENT_ID"
    },
    "effectiveDateTime": "2025-12-04T10:30:00Z",
    "component": [
      {
        "code": {
          "coding": [{
            "system": "http://loinc.org",
            "code": "8480-6"
          }]
        },
        "valueQuantity": {
          "value": 165,
          "unit": "mmHg",
          "system": "http://unitsofmeasure.org",
          "code": "mm[Hg]"
        }
      },
      {
        "code": {
          "coding": [{
            "system": "http://loinc.org",
            "code": "8462-4"
          }]
        },
        "valueQuantity": {
          "value": 105,
          "unit": "mmHg",
          "system": "http://unitsofmeasure.org",
          "code": "mm[Hg]"
        }
      }
    ]
  }'
```

### Ver Logs del Bot

1. Medplum Console > **Bots** > Tu Bot
2. Pestaña **Logs**
3. Deberías ver: `✅ EPA-HTA Bot iniciado`

### Verificar Recursos Creados

```bash
# Ver Communication creado
curl https://api.medplum.com/fhir/R4/Communication?priority=urgent \
  -H "Authorization: Bearer TU_ACCESS_TOKEN"

# Ver Task creado
curl https://api.medplum.com/fhir/R4/Task?status=requested \
  -H "Authorization: Bearer TU_ACCESS_TOKEN"
```

## 🎯 Próximos Pasos

### 1. Crear Subscription (Automatización)

Para que el bot se ejecute automáticamente:

```json
{
  "resourceType": "Subscription",
  "status": "active",
  "reason": "EPA HTA Alerts",
  "criteria": "Observation?code=http://loinc.org|85354-9",
  "channel": {
    "type": "rest-hook",
    "endpoint": "Bot/TU_BOT_ID"
  }
}
```

Crear en: Medplum Console > **Resources** > **Subscription** > **Create New**

### 2. Agregar Practitioners

Usar el template: `examples/practitioner-dra-aquieri.json`

```bash
curl -X POST https://api.medplum.com/fhir/R4/Practitioner \
  -H "Authorization: Bearer TU_ACCESS_TOKEN" \
  -H "Content-Type: application/fhir+json" \
  -d @examples/practitioner-dra-aquieri.json
```

### 3. Crear Patients

Usar el template: `examples/patient-grupo-b.json`

```bash
curl -X POST https://api.medplum.com/fhir/R4/Patient \
  -H "Authorization: Bearer TU_ACCESS_TOKEN" \
  -H "Content-Type: application/fhir+json" \
  -d @examples/patient-grupo-b.json
```

## 🧪 Tests

```bash
# Ejecutar todos los tests
npm test

# Con cobertura
npm run test:coverage

# Modo watch (desarrollo)
npm run test:watch
```

## 🔧 Desarrollo

```bash
# Compilar en modo watch
npm run dev

# Verificar estilo
npm run lint

# Auto-formatear código
npm run format
```

## 📊 Umbrales Clínicos (SAC)

| Categoría | Sistólica | Diastólica | Alerta |
|-----------|-----------|------------|--------|
| Normal | < 130 | < 85 | No |
| Elevada | 130-139 | 85-89 | No |
| HTA Grado 1 | 140-159 | 90-99 | Moderada |
| HTA Grado 2 | 160-179 | 100-109 | Mayor ⚠️ |
| Crisis HTA | ≥ 180 | ≥ 120 | Crítica 🚨 |

## 🆘 Troubleshooting Rápido

### El bot no se ejecuta

```bash
# 1. Verificar que el bot existe
curl https://api.medplum.com/fhir/R4/Bot/TU_BOT_ID \
  -H "Authorization: Bearer TU_ACCESS_TOKEN"

# 2. Verificar Subscription
curl https://api.medplum.com/fhir/R4/Subscription?status=active \
  -H "Authorization: Bearer TU_ACCESS_TOKEN"
```

### Errores de compilación

```bash
# Limpiar y reinstalar
npm run clean
rm -rf node_modules package-lock.json
npm install
npm run build
```

### No se crean Communication/Task

- ✅ Verificar que existe al menos 1 Practitioner activo
- ✅ Revisar logs del bot para errores
- ✅ Verificar que el Patient ID es válido

## 📚 Documentación Completa

- [README.md](./README.md) - Documentación detallada
- [DEPLOYMENT.md](./DEPLOYMENT.md) - Guía de deployment paso a paso
- [CONTRIBUTING.md](./CONTRIBUTING.md) - Cómo contribuir

## 🤝 Equipo Médico

**Cardiólogas SAC:**
- Dra. Analía Aquieri
- Dra. Verónica Crosa
- Dra. Marisa Pages
- Dra. Viviana Cavenago

**Coordinación:**
- Mg. Giovanna Sanguinetti

## 📞 Soporte

- GitHub Issues: [Reportar problema](https://github.com/drdalessandro/epa-hta-bot/issues)
- Email: alejandro@epa-bienestar.com.ar
- Docs Medplum: [docs.medplum.com](https://docs.medplum.com)

---

**¡Listo! 🎉** El bot ahora monitorea automáticamente la presión arterial de tus pacientes.

EPA Bienestar IA - Buenos Aires, Argentina 🇦🇷
