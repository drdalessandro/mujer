/**
 * Tests para evaluación de umbrales de presión arterial
 * EPA Bienestar IA
 */

import { evaluateBloodPressure, getResponseTimeMinutes } from '../thresholds';
import { BPSeverity } from '../types';

describe('evaluateBloodPressure', () => {
  describe('PA Normal', () => {
    it('debe clasificar 120/80 como normal', () => {
      const result = evaluateBloodPressure(120, 80);
      expect(result.severity).toBe(BPSeverity.NORMAL);
      expect(result.requiresAlert).toBe(false);
      expect(result.priority).toBe('routine');
    });

    it('debe clasificar 125/82 como normal', () => {
      const result = evaluateBloodPressure(125, 82);
      expect(result.severity).toBe(BPSeverity.NORMAL);
      expect(result.requiresAlert).toBe(false);
    });
  });

  describe('PA Elevada', () => {
    it('debe clasificar 135/88 como elevada', () => {
      const result = evaluateBloodPressure(135, 88);
      expect(result.severity).toBe(BPSeverity.ELEVATED);
      expect(result.requiresAlert).toBe(false);
      expect(result.priority).toBe('routine');
    });

    it('debe clasificar 138/92 como elevada', () => {
      const result = evaluateBloodPressure(138, 92);
      expect(result.severity).toBe(BPSeverity.ELEVATED);
      expect(result.requiresAlert).toBe(false);
    });
  });

  describe('Alerta Moderada', () => {
    it('debe clasificar 155/98 como alerta moderada', () => {
      const result = evaluateBloodPressure(155, 98);
      expect(result.severity).toBe(BPSeverity.MODERATE_ALERT);
      expect(result.requiresAlert).toBe(true);
      expect(result.priority).toBe('urgent');
    });

    it('debe incluir mensaje de alerta', () => {
      const result = evaluateBloodPressure(155, 98);
      expect(result.message).toContain('ALERTA MODERADA HTA');
      expect(result.message).toContain('155/98');
    });
  });

  describe('Alerta Mayor', () => {
    it('debe clasificar 165/105 como alerta mayor', () => {
      const result = evaluateBloodPressure(165, 105);
      expect(result.severity).toBe(BPSeverity.MAJOR_ALERT);
      expect(result.requiresAlert).toBe(true);
      expect(result.priority).toBe('stat');
    });

    it('debe clasificar 178/108 como alerta mayor', () => {
      const result = evaluateBloodPressure(178, 108);
      expect(result.severity).toBe(BPSeverity.MAJOR_ALERT);
      expect(result.requiresAlert).toBe(true);
    });

    it('debe incluir mensaje urgente', () => {
      const result = evaluateBloodPressure(165, 105);
      expect(result.message).toContain('ALERTA MAYOR HTA');
      expect(result.message).toContain('urgente');
    });
  });

  describe('Crisis Hipertensiva', () => {
    it('debe clasificar 185/125 como crisis hipertensiva', () => {
      const result = evaluateBloodPressure(185, 125);
      expect(result.severity).toBe(BPSeverity.HYPERTENSIVE_CRISIS);
      expect(result.requiresAlert).toBe(true);
      expect(result.priority).toBe('stat');
    });

    it('debe clasificar 195/118 como crisis hipertensiva (sistólica alta)', () => {
      const result = evaluateBloodPressure(195, 118);
      expect(result.severity).toBe(BPSeverity.HYPERTENSIVE_CRISIS);
      expect(result.requiresAlert).toBe(true);
    });

    it('debe incluir mensaje de emergencia', () => {
      const result = evaluateBloodPressure(185, 125);
      expect(result.message).toContain('CRISIS HIPERTENSIVA');
      expect(result.message).toContain('INMEDIATA');
    });
  });

  describe('Umbrales de Embarazo', () => {
    it('debe usar umbrales más estrictos para embarazo', () => {
      const normalResult = evaluateBloodPressure(135, 88, false);
      const pregnancyResult = evaluateBloodPressure(135, 88, true);

      // Sin embarazo: elevada
      expect(normalResult.severity).toBe(BPSeverity.ELEVATED);
      // Con embarazo: alerta moderada
      expect(pregnancyResult.severity).toBe(BPSeverity.MODERATE_ALERT);
    });

    it('debe clasificar 145/92 como alerta moderada en embarazo', () => {
      const result = evaluateBloodPressure(145, 92, true);
      expect(result.severity).toBe(BPSeverity.MODERATE_ALERT);
      expect(result.requiresAlert).toBe(true);
    });
  });
});

describe('getResponseTimeMinutes', () => {
  it('debe retornar 30 minutos para crisis hipertensiva', () => {
    expect(getResponseTimeMinutes(BPSeverity.HYPERTENSIVE_CRISIS)).toBe(30);
  });

  it('debe retornar 120 minutos para alerta mayor', () => {
    expect(getResponseTimeMinutes(BPSeverity.MAJOR_ALERT)).toBe(120);
  });

  it('debe retornar 240 minutos para alerta moderada', () => {
    expect(getResponseTimeMinutes(BPSeverity.MODERATE_ALERT)).toBe(240);
  });

  it('debe retornar 1440 minutos (24h) para elevada', () => {
    expect(getResponseTimeMinutes(BPSeverity.ELEVATED)).toBe(1440);
  });

  it('debe retornar 2880 minutos (48h) para normal', () => {
    expect(getResponseTimeMinutes(BPSeverity.NORMAL)).toBe(2880);
  });
});

describe('Casos Edge', () => {
  it('debe manejar valores en el límite exacto', () => {
    const result = evaluateBloodPressure(160, 100);
    expect(result.severity).toBe(BPSeverity.MODERATE_ALERT);
  });

  it('debe priorizar diastólica alta si sistólica es normal', () => {
    const result = evaluateBloodPressure(125, 110);
    expect(result.severity).toBe(BPSeverity.MAJOR_ALERT);
    expect(result.requiresAlert).toBe(true);
  });

  it('debe priorizar sistólica alta si diastólica es normal', () => {
    const result = evaluateBloodPressure(185, 82);
    expect(result.severity).toBe(BPSeverity.HYPERTENSIVE_CRISIS);
    expect(result.requiresAlert).toBe(true);
  });
});

describe('Formato de Mensajes', () => {
  it('debe incluir valores de PA en todos los mensajes', () => {
    const result1 = evaluateBloodPressure(120, 80);
    const result2 = evaluateBloodPressure(165, 105);
    const result3 = evaluateBloodPressure(185, 125);

    expect(result1.message).toContain('120/80');
    expect(result2.message).toContain('165/105');
    expect(result3.message).toContain('185/125');
  });

  it('debe incluir emoji apropiado según severidad', () => {
    const normal = evaluateBloodPressure(120, 80);
    const moderate = evaluateBloodPressure(155, 98);
    const crisis = evaluateBloodPressure(185, 125);

    expect(normal.message).toContain('✅');
    expect(moderate.message).toContain('⚠️');
    expect(crisis.message).toContain('🚨');
  });
});
