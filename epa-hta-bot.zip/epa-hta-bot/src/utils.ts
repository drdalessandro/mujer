/**
 * Funciones Utilitarias para el Bot de Alertas de HTA
 * EPA Bienestar IA
 */

import {
  Observation,
  Communication,
  Task,
  Patient,
  Practitioner,
  Reference,
} from '@medplum/fhirtypes';
import {
  BloodPressureValues,
  LOINC_CODES,
  FHIR_STATUS,
  PRIORITY,
  TASK_INTENT,
  BPEvaluation,
  extractIdFromReference,
} from './types';
import { getResponseTimeMinutes } from './thresholds';

/**
 * Verifica si una Observation es de presión arterial
 * 
 * @param observation - Recurso Observation
 * @returns true si es una observación de PA
 */
export function isBloodPressureObservation(observation: Observation): boolean {
  if (!observation.code?.coding) return false;

  return observation.code.coding.some(
    (coding) =>
      coding.system === 'http://loinc.org' &&
      coding.code === LOINC_CODES.BP_PANEL
  );
}

/**
 * Extrae los valores de presión arterial de una Observation
 * 
 * @param observation - Recurso Observation de PA
 * @returns Valores de presión sistólica y diastólica
 * @throws Error si no se pueden extraer los valores
 */
export function extractBloodPressureValues(
  observation: Observation
): BloodPressureValues {
  if (!observation.component || observation.component.length === 0) {
    throw new Error('Observation no tiene componentes de presión arterial');
  }

  let systolic: number | undefined;
  let diastolic: number | undefined;
  let unit = 'mmHg';

  for (const component of observation.component) {
    const code = component.code?.coding?.[0]?.code;
    const value = component.valueQuantity?.value;
    const componentUnit = component.valueQuantity?.unit;

    if (value === undefined) continue;
    if (componentUnit) unit = componentUnit;

    if (code === LOINC_CODES.SYSTOLIC_BP) {
      systolic = value;
    } else if (code === LOINC_CODES.DIASTOLIC_BP) {
      diastolic = value;
    }
  }

  if (systolic === undefined || diastolic === undefined) {
    throw new Error(
      `Valores de PA incompletos: Sistólica=${systolic}, Diastólica=${diastolic}`
    );
  }

  return { systolic, diastolic, unit };
}

/**
 * Obtiene el nombre completo del paciente
 * 
 * @param patient - Recurso Patient
 * @returns Nombre completo o ID si no hay nombre
 */
export function getPatientName(patient: Patient): string {
  if (!patient.name || patient.name.length === 0) {
    return `Paciente ${patient.id}`;
  }

  const name = patient.name[0];
  const given = name.given?.join(' ') || '';
  const family = name.family || '';

  return `${given} ${family}`.trim() || `Paciente ${patient.id}`;
}

/**
 * Obtiene el nombre completo del practitioner
 * 
 * @param practitioner - Recurso Practitioner
 * @returns Nombre completo o ID si no hay nombre
 */
export function getPractitionerName(practitioner: Practitioner): string {
  if (!practitioner.name || practitioner.name.length === 0) {
    return `Dr./Dra. ${practitioner.id}`;
  }

  const name = practitioner.name[0];
  const prefix = name.prefix?.join(' ') || 'Dr./Dra.';
  const given = name.given?.join(' ') || '';
  const family = name.family || '';

  return `${prefix} ${given} ${family}`.trim();
}

/**
 * Crea un recurso Communication para alertar al equipo médico
 * 
 * @param observation - Observation de PA que disparó la alerta
 * @param patient - Paciente relacionado
 * @param practitioner - Profesional que recibirá la alerta
 * @param evaluation - Evaluación de la PA
 * @returns Recurso Communication para crear
 */
export function createCommunicationAlert(
  observation: Observation,
  patient: Patient,
  practitioner: Practitioner,
  evaluation: BPEvaluation
): Omit<Communication, 'id' | 'meta'> {
  const patientName = getPatientName(patient);
  const alertMessage = evaluation.message;

  return {
    resourceType: 'Communication',
    status: FHIR_STATUS.COMMUNICATION.COMPLETED,
    priority: evaluation.priority,
    subject: {
      reference: `Patient/${patient.id}`,
      display: patientName,
    },
    recipient: [
      {
        reference: `Practitioner/${practitioner.id}`,
        display: getPractitionerName(practitioner),
      },
    ],
    sent: new Date().toISOString(),
    payload: [
      {
        contentString: alertMessage,
      },
      {
        contentString: `Paciente: ${patientName}\nPA: ${evaluation.systolic}/${evaluation.diastolic} ${observation.component?.[0]?.valueQuantity?.unit || 'mmHg'}\nFecha: ${observation.effectiveDateTime || new Date().toISOString()}`,
      },
    ],
    reasonReference: [
      {
        reference: `Observation/${observation.id}`,
      },
    ],
    note: [
      {
        text: `Alerta generada automáticamente por EPA-HTA-Bot. Severidad: ${evaluation.severity}`,
        time: new Date().toISOString(),
      },
    ],
  };
}

/**
 * Crea un recurso Task para el seguimiento del caso
 * 
 * @param observation - Observation de PA que disparó la alerta
 * @param patient - Paciente relacionado
 * @param practitioner - Profesional asignado
 * @param evaluation - Evaluación de la PA
 * @returns Recurso Task para crear
 */
export function createFollowUpTask(
  observation: Observation,
  patient: Patient,
  practitioner: Practitioner,
  evaluation: BPEvaluation
): Omit<Task, 'id' | 'meta'> {
  const patientName = getPatientName(patient);
  const responseMinutes = getResponseTimeMinutes(evaluation.severity);
  const dueDate = new Date();
  dueDate.setMinutes(dueDate.getMinutes() + responseMinutes);

  let taskDescription = '';
  switch (evaluation.severity) {
    case 'hypertensive_crisis':
      taskDescription = `CRISIS HIPERTENSIVA - Contactar INMEDIATAMENTE a ${patientName}. PA: ${evaluation.systolic}/${evaluation.diastolic} mmHg. Evaluar necesidad de derivación a emergencia.`;
      break;
    case 'major_alert':
      taskDescription = `ALERTA URGENTE - Contactar a ${patientName} dentro de 2 horas. PA: ${evaluation.systolic}/${evaluation.diastolic} mmHg. Evaluar ajuste de tratamiento.`;
      break;
    case 'moderate_alert':
      taskDescription = `Seguimiento HTA - Contactar a ${patientName} dentro de 4 horas. PA: ${evaluation.systolic}/${evaluation.diastolic} mmHg. Revisar adherencia y plan de bienestar.`;
      break;
    default:
      taskDescription = `Seguimiento de PA elevada - ${patientName}. PA: ${evaluation.systolic}/${evaluation.diastolic} mmHg.`;
  }

  return {
    resourceType: 'Task',
    status: FHIR_STATUS.TASK.REQUESTED,
    intent: TASK_INTENT.ORDER,
    priority: evaluation.priority,
    code: {
      coding: [
        {
          system: 'http://epa-bienestar.com.ar/task-codes',
          code: 'bp-followup',
          display: 'Seguimiento de Presión Arterial Crítica',
        },
      ],
      text: 'Llamada de Verificación de PA Crítica',
    },
    description: taskDescription,
    for: {
      reference: `Patient/${patient.id}`,
      display: patientName,
    },
    authoredOn: new Date().toISOString(),
    owner: {
      reference: `Practitioner/${practitioner.id}`,
      display: getPractitionerName(practitioner),
    },
    focus: {
      reference: `Observation/${observation.id}`,
    },
    restriction: {
      period: {
        end: dueDate.toISOString(),
      },
    },
    note: [
      {
        text: `Tarea generada automáticamente por EPA-HTA-Bot. Severidad: ${evaluation.severity}. Tiempo de respuesta objetivo: ${responseMinutes} minutos.`,
        time: new Date().toISOString(),
      },
    ],
  };
}

/**
 * Formatea la fecha/hora para logs
 * 
 * @param date - Fecha a formatear
 * @returns String formateado
 */
export function formatDateTime(date: Date = new Date()): string {
  return date.toISOString().replace('T', ' ').substring(0, 19);
}

/**
 * Crea un log estructurado para el bot
 * 
 * @param level - Nivel del log (info, warn, error)
 * @param message - Mensaje
 * @param data - Datos adicionales
 */
export function logBotActivity(
  level: 'info' | 'warn' | 'error',
  message: string,
  data?: Record<string, any>
): void {
  const logEntry = {
    timestamp: formatDateTime(),
    level,
    bot: 'epa-hta-alert-bot',
    message,
    ...data,
  };

  const logMessage = JSON.stringify(logEntry, null, 2);

  switch (level) {
    case 'error':
      console.error(logMessage);
      break;
    case 'warn':
      console.warn(logMessage);
      break;
    default:
      console.log(logMessage);
  }
}

/**
 * Valida que una Observation tenga todos los campos requeridos
 * 
 * @param observation - Observation a validar
 * @returns true si es válida
 */
export function validateObservation(observation: Observation): boolean {
  if (!observation.id) {
    logBotActivity('error', 'Observation sin ID');
    return false;
  }

  if (!observation.subject?.reference) {
    logBotActivity('error', 'Observation sin referencia a Patient', {
      observationId: observation.id,
    });
    return false;
  }

  if (!observation.component || observation.component.length === 0) {
    logBotActivity('error', 'Observation sin componentes', {
      observationId: observation.id,
    });
    return false;
  }

  return true;
}

/**
 * Extrae el Patient ID de una Observation
 * 
 * @param observation - Observation
 * @returns Patient ID o undefined
 */
export function getPatientIdFromObservation(
  observation: Observation
): string | undefined {
  return extractIdFromReference(observation.subject);
}

/**
 * Calcula estadísticas de PA para reportes
 * 
 * @param observations - Lista de Observations
 * @returns Estadísticas calculadas
 */
export function calculateBPStats(observations: Observation[]): {
  count: number;
  avgSystolic: number;
  avgDiastolic: number;
  maxSystolic: number;
  maxDiastolic: number;
  minSystolic: number;
  minDiastolic: number;
} {
  if (observations.length === 0) {
    return {
      count: 0,
      avgSystolic: 0,
      avgDiastolic: 0,
      maxSystolic: 0,
      maxDiastolic: 0,
      minSystolic: 0,
      minDiastolic: 0,
    };
  }

  let sumSystolic = 0;
  let sumDiastolic = 0;
  let maxSystolic = 0;
  let maxDiastolic = 0;
  let minSystolic = Infinity;
  let minDiastolic = Infinity;

  for (const obs of observations) {
    try {
      const values = extractBloodPressureValues(obs);
      sumSystolic += values.systolic;
      sumDiastolic += values.diastolic;
      maxSystolic = Math.max(maxSystolic, values.systolic);
      maxDiastolic = Math.max(maxDiastolic, values.diastolic);
      minSystolic = Math.min(minSystolic, values.systolic);
      minDiastolic = Math.min(minDiastolic, values.diastolic);
    } catch (error) {
      // Skip invalid observations
      continue;
    }
  }

  return {
    count: observations.length,
    avgSystolic: Math.round(sumSystolic / observations.length),
    avgDiastolic: Math.round(sumDiastolic / observations.length),
    maxSystolic,
    maxDiastolic,
    minSystolic: minSystolic === Infinity ? 0 : minSystolic,
    minDiastolic: minDiastolic === Infinity ? 0 : minDiastolic,
  };
}
