import { indexStructureDefinitionBundle } from '@medplum/core';
import { SEARCH_PARAMETER_BUNDLE_FILES, readJson } from '@medplum/definitions';

/**
 * Setup para tests de Medplum Bot
 * Indexa las definiciones de schema FHIR para que MockClient funcione correctamente
 */
beforeAll(() => {
  console.log('📚 Indexando schema FHIR para tests...');
  
  // Indexar todos los bundles de parámetros de búsqueda
  for (const filename of SEARCH_PARAMETER_BUNDLE_FILES) {
    indexStructureDefinitionBundle(readJson(filename));
  }
  
  console.log('✅ Schema FHIR indexado correctamente');
});
