import { Observation } from '@medplum/fhirtypes';
import { BP_THRESHOLDS, BPSeverityLevel, BPAnalysisResult, LOINC_CODES } from './types';

/**
 * Analiza un recurso Observation de presión arterial y determina:
 * - Nivel de severidad
 * - Si requiere alerta
 * - Si requiere creación de tarea
 * - Prioridad de la alerta
 * - Mensaje descriptivo
 */
export function analyzeBPObservation(observation: Observation): BPAnalysisResult | null {
  // Verificar que sea una observación de presión arterial
  if (!isBloodPressureObservation(observation)) {
    return null;
  }

  // Extraer valores de sistólica y diastólica
  const systolic = extractSystolicValue(observation);
  const diastolic = extractDiastolicValue(observation);

  if (systolic === null || diastolic === null) {
    console.warn('No se pudieron extraer valores de PA de la observación', observation.id);
    return null;
  }

  // Validar valores dentro de rangos fisiológicos razonables
  if (!areValuesValid(systolic, diastolic)) {
    console.warn(`Valores de PA fuera de rango fisiológico: ${systolic}/${diastolic}`);
    return null;
  }

  // Determinar nivel de severidad
  const severityLevel = determineSeverity(systolic, diastolic);

  // Construir resultado del análisis
  return buildAnalysisResult(severityLevel, systolic, diastolic);
}

/**
 * Verifica si una observación corresponde a presión arterial
 */
function isBloodPressureObservation(observation: Observation): boolean {
  const coding = observation.code?.coding;
  if (!coding) return false;

  return coding.some(
    (code) =>
      code.code === LOINC_CODES.BP_PANEL ||
      code.code === LOINC_CODES.SYSTOLIC ||
      code.code === LOINC_CODES.DIASTOLIC
  );
}

/**
 * Extrae el valor de presión sistólica de la observación
 */
function extractSystolicValue(observation: Observation): number | null {
  // Buscar en componentes (cuando es un panel completo)
  if (observation.component) {
    const systolicComponent = observation.component.find((comp) =>
      comp.code?.coding?.some((code) => code.code === LOINC_CODES.SYSTOLIC)
    );
    if (systolicComponent?.valueQuantity?.value !== undefined) {
      return systolicComponent.valueQuantity.value;
    }
  }

  // Buscar en valueQuantity (cuando es una observación individual)
  if (observation.valueQuantity?.value !== undefined) {
    const isSystolic = observation.code?.coding?.some((code) => code.code === LOINC_CODES.SYSTOLIC);
    if (isSystolic) {
      return observation.valueQuantity.value;
    }
  }

  return null;
}

/**
 * Extrae el valor de presión diastólica de la observación
 */
function extractDiastolicValue(observation: Observation): number | null {
  // Buscar en componentes (cuando es un panel completo)
  if (observation.component) {
    const diastolicComponent = observation.component.find((comp) =>
      comp.code?.coding?.some((code) => code.code === LOINC_CODES.DIASTOLIC)
    );
    if (diastolicComponent?.valueQuantity?.value !== undefined) {
      return diastolicComponent.valueQuantity.value;
    }
  }

  // Buscar en valueQuantity (cuando es una observación individual)
  if (observation.valueQuantity?.value !== undefined) {
    const isDiastolic = observation.code?.coding?.some((code) => code.code === LOINC_CODES.DIASTOLIC);
    if (isDiastolic) {
      return observation.valueQuantity.value;
    }
  }

  return null;
}

/**
 * Valida que los valores estén dentro de rangos fisiológicos razonables
 */
function areValuesValid(systolic: number, diastolic: number): boolean {
  // Rangos fisiológicos: 50-250 para sistólica, 30-150 para diastólica
  const systolicValid = systolic >= 50 && systolic <= 250;
  const diastolicValid = diastolic >= 30 && diastolic <= 150;
  
  // La sistólica debe ser mayor que la diastólica
  const logicalRelation = systolic > diastolic;

  return systolicValid && diastolicValid && logicalRelation;
}

/**
 * Determina el nivel de severidad basado en los valores de PA
 */
function determineSeverity(systolic: number, diastolic: number): BPSeverityLevel {
  // Crisis hipertensiva (requiere atención inmediata)
  if (systolic >= BP_THRESHOLDS.CRITICAL.SYSTOLIC || diastolic >= BP_THRESHOLDS.CRITICAL.DIASTOLIC) {
    return BPSeverityLevel.CRITICAL;
  }

  // HTA Estadio 2 (requiere seguimiento urgente)
  if (systolic >= BP_THRESHOLDS.HIGH.SYSTOLIC || diastolic >= BP_THRESHOLDS.HIGH.DIASTOLIC) {
    return BPSeverityLevel.HIGH;
  }

  // HTA Estadio 1 (requiere monitoreo)
  if (systolic >= BP_THRESHOLDS.MODERATE.SYSTOLIC || diastolic >= BP_THRESHOLDS.MODERATE.DIASTOLIC) {
    return BPSeverityLevel.MODERATE;
  }

  // Hipotensión (puede requerir evaluación)
  if (systolic <= BP_THRESHOLDS.LOW.SYSTOLIC || diastolic <= BP_THRESHOLDS.LOW.DIASTOLIC) {
    return BPSeverityLevel.LOW;
  }

  // Valores normales
  return BPSeverityLevel.NORMAL;
}

/**
 * Construye el resultado del análisis con todas las recomendaciones
 */
function buildAnalysisResult(
  severityLevel: BPSeverityLevel,
  systolic: number,
  diastolic: number
): BPAnalysisResult {
  switch (severityLevel) {
    case BPSeverityLevel.CRITICAL:
      return {
        severityLevel,
        systolic,
        diastolic,
        requiresAlert: true,
        requiresTask: true,
        alertPriority: 'stat',
        taskPriority: 'stat',
        message: `⚠️ CRISIS HIPERTENSIVA DETECTADA: PA ${systolic}/${diastolic} mmHg. Requiere contacto inmediato con la paciente y evaluación médica urgente.`,
      };

    case BPSeverityLevel.HIGH:
      return {
        severityLevel,
        systolic,
        diastolic,
        requiresAlert: true,
        requiresTask: true,
        alertPriority: 'urgent',
        taskPriority: 'urgent',
        message: `⚠️ HTA ESTADIO 2 DETECTADA: PA ${systolic}/${diastolic} mmHg. Requiere contacto en las próximas 24 horas para evaluación y seguimiento.`,
      };

    case BPSeverityLevel.MODERATE:
      return {
        severityLevel,
        systolic,
        diastolic,
        requiresAlert: true,
        requiresTask: true,
        alertPriority: 'routine',
        taskPriority: 'routine',
        message: `⚡ HTA ESTADIO 1 DETECTADA: PA ${systolic}/${diastolic} mmHg. Programar seguimiento en los próximos 3-7 días.`,
      };

    case BPSeverityLevel.LOW:
      return {
        severityLevel,
        systolic,
        diastolic,
        requiresAlert: true,
        requiresTask: true,
        alertPriority: 'routine',
        taskPriority: 'routine',
        message: `📉 HIPOTENSIÓN DETECTADA: PA ${systolic}/${diastolic} mmHg. Evaluar síntomas asociados y contexto clínico.`,
      };

    case BPSeverityLevel.NORMAL:
    default:
      return {
        severityLevel,
        systolic,
        diastolic,
        requiresAlert: false,
        requiresTask: false,
        alertPriority: 'routine',
        taskPriority: 'routine',
        message: `✅ PRESIÓN ARTERIAL NORMAL: PA ${systolic}/${diastolic} mmHg.`,
      };
  }
}

/**
 * Obtiene una descripción detallada del nivel de severidad
 */
export function getSeverityDescription(level: BPSeverityLevel): string {
  const descriptions: Record<BPSeverityLevel, string> = {
    [BPSeverityLevel.CRITICAL]:
      'Crisis Hipertensiva - Riesgo de daño agudo a órganos. Requiere atención médica inmediata.',
    [BPSeverityLevel.HIGH]:
      'Hipertensión Estadio 2 - Requiere evaluación médica urgente y probable inicio de tratamiento farmacológico.',
    [BPSeverityLevel.MODERATE]:
      'Hipertensión Estadio 1 - Requiere cambios en estilo de vida y evaluación para posible tratamiento.',
    [BPSeverityLevel.NORMAL]: 'Presión arterial dentro de rangos normales.',
    [BPSeverityLevel.LOW]: 'Hipotensión - Evaluar síntomas y causas potenciales.',
  };

  return descriptions[level];
}
