/**
 * EPA Bienestar IA - Bot de Alertas de Hipertensión Arterial
 * 
 * Este bot se ejecuta automáticamente cuando se crea o actualiza
 * una Observation de presión arterial en Medplum.
 * 
 * Flujo:
 * 1. Verifica que sea una Observation de PA
 * 2. Extrae valores sistólicos y diastólicos
 * 3. Evalúa contra umbrales clínicos SAC
 * 4. Si es crítico, crea Communication y Task
 * 5. Registra actividad en logs
 * 
 * Equipo Médico:
 * - Dra. Analía Aquieri
 * - Dra. Verónica Crosa
 * - Dra. Marisa Pages
 * - Dra. Viviana Cavenago
 * - Mg. Giovanna Sanguinetti (Coordinación)
 * 
 * @author Alejandro D'Alessandro
 * @version 1.0.0
 */

import { BotEvent, MedplumClient } from '@medplum/core';
import { Observation, Patient, Practitioner } from '@medplum/fhirtypes';
import {
  isBloodPressureObservation,
  extractBloodPressureValues,
  validateObservation,
  getPatientIdFromObservation,
  createCommunicationAlert,
  createFollowUpTask,
  logBotActivity,
} from './utils';
import {
  evaluateBloodPressure,
  requiresMedicalAlert,
} from './thresholds';
import { BotExecutionResult, BPSeverity } from './types';

/**
 * Función principal del bot
 * Esta función se ejecuta cada vez que se crea o actualiza una Observation
 * 
 * @param medplum - Cliente de Medplum para interactuar con FHIR resources
 * @param event - Evento que disparó el bot
 * @returns Resultado de la ejecución
 */
export async function handler(
  medplum: MedplumClient,
  event: BotEvent<Observation>
): Promise<BotExecutionResult> {
  const startTime = Date.now();
  
  logBotActivity('info', '🚀 EPA-HTA Bot iniciado', {
    eventType: event.type,
    resourceId: event.input?.id,
  });

  try {
    const observation = event.input;

    // Validación 1: Verificar que tenemos una Observation válida
    if (!observation || !validateObservation(observation)) {
      logBotActivity('warn', 'Observation inválida o incompleta', {
        observationId: observation?.id,
      });
      return {
        success: false,
        observationId: observation?.id || 'unknown',
        severity: BPSeverity.NORMAL,
        alertGenerated: false,
        taskGenerated: false,
        error: 'Observation inválida',
      };
    }

    // Validación 2: Verificar que es una Observation de Presión Arterial
    if (!isBloodPressureObservation(observation)) {
      logBotActivity('info', 'Observation no es de presión arterial, ignorando', {
        observationId: observation.id,
        code: observation.code?.coding?.[0]?.code,
      });
      return {
        success: true,
        observationId: observation.id!,
        severity: BPSeverity.NORMAL,
        alertGenerated: false,
        taskGenerated: false,
      };
    }

    logBotActivity('info', '✅ Observation de PA detectada', {
      observationId: observation.id,
    });

    // Paso 1: Extraer valores de presión arterial
    let bpValues;
    try {
      bpValues = extractBloodPressureValues(observation);
      logBotActivity('info', '📊 Valores de PA extraídos', {
        observationId: observation.id,
        systolic: bpValues.systolic,
        diastolic: bpValues.diastolic,
        unit: bpValues.unit,
      });
    } catch (error) {
      logBotActivity('error', 'Error al extraer valores de PA', {
        observationId: observation.id,
        error: error instanceof Error ? error.message : String(error),
      });
      return {
        success: false,
        observationId: observation.id!,
        severity: BPSeverity.NORMAL,
        alertGenerated: false,
        taskGenerated: false,
        error: 'Error al extraer valores de PA',
      };
    }

    // Paso 2: Obtener información del paciente
    const patientId = getPatientIdFromObservation(observation);
    if (!patientId) {
      logBotActivity('error', 'No se pudo obtener Patient ID', {
        observationId: observation.id,
      });
      return {
        success: false,
        observationId: observation.id!,
        severity: BPSeverity.NORMAL,
        alertGenerated: false,
        taskGenerated: false,
        error: 'Patient ID no encontrado',
      };
    }

    let patient: Patient;
    try {
      patient = await medplum.readResource('Patient', patientId);
      logBotActivity('info', '👤 Paciente obtenido', {
        patientId: patient.id,
        patientName: patient.name?.[0]?.given?.[0],
      });
    } catch (error) {
      logBotActivity('error', 'Error al obtener paciente', {
        patientId,
        error: error instanceof Error ? error.message : String(error),
      });
      return {
        success: false,
        observationId: observation.id!,
        severity: BPSeverity.NORMAL,
        alertGenerated: false,
        taskGenerated: false,
        error: 'Error al obtener paciente',
      };
    }

    // Paso 3: Evaluar presión arterial contra umbrales clínicos
    // TODO: Detectar si la paciente está en Grupo B (embarazo) para usar umbrales específicos
    const evaluation = evaluateBloodPressure(
      bpValues.systolic,
      bpValues.diastolic,
      false // usePregnancyThresholds - implementar detección de grupo
    );

    logBotActivity('info', '🔍 PA evaluada', {
      observationId: observation.id,
      severity: evaluation.severity,
      requiresAlert: evaluation.requiresAlert,
      priority: evaluation.priority,
      systolic: evaluation.systolic,
      diastolic: evaluation.diastolic,
    });

    // Paso 4: Si no requiere alerta, terminar aquí
    if (!requiresMedicalAlert(evaluation)) {
      logBotActivity('info', '✅ PA en rango aceptable, no se requiere alerta', {
        observationId: observation.id,
        severity: evaluation.severity,
      });
      
      const executionTime = Date.now() - startTime;
      logBotActivity('info', '✅ Bot completado exitosamente', {
        executionTimeMs: executionTime,
      });

      return {
        success: true,
        observationId: observation.id!,
        severity: evaluation.severity,
        alertGenerated: false,
        taskGenerated: false,
      };
    }

    // Paso 5: PA crítica detectada - Obtener practitioner responsable
    // TODO: Implementar lógica de asignación inteligente según:
    // - Grupo de la paciente
    // - Disponibilidad del practitioner
    // - Carga de trabajo actual
    let practitioner: Practitioner;
    try {
      // Por ahora, buscar el primer practitioner disponible
      const practitioners = await medplum.searchResources('Practitioner', {
        active: 'true',
        _count: '1',
      });

      if (!practitioners || practitioners.length === 0) {
        throw new Error('No se encontraron practitioners disponibles');
      }

      practitioner = practitioners[0];
      logBotActivity('info', '👨‍⚕️ Practitioner asignado', {
        practitionerId: practitioner.id,
        practitionerName: practitioner.name?.[0]?.given?.[0],
      });
    } catch (error) {
      logBotActivity('error', 'Error al obtener practitioner', {
        error: error instanceof Error ? error.message : String(error),
      });
      return {
        success: false,
        observationId: observation.id!,
        severity: evaluation.severity,
        alertGenerated: false,
        taskGenerated: false,
        error: 'Error al obtener practitioner',
      };
    }

    // Paso 6: Crear Communication (Alerta)
    let communicationId: string | undefined;
    try {
      const communicationResource = createCommunicationAlert(
        observation,
        patient,
        practitioner,
        evaluation
      );

      const createdCommunication = await medplum.createResource(
        communicationResource
      );
      
      communicationId = createdCommunication.id;
      
      logBotActivity('info', '📧 Communication creado', {
        communicationId,
        priority: evaluation.priority,
        recipient: practitioner.id,
      });
    } catch (error) {
      logBotActivity('error', 'Error al crear Communication', {
        observationId: observation.id,
        error: error instanceof Error ? error.message : String(error),
      });
      // Continuar para intentar crear el Task
    }

    // Paso 7: Crear Task (Seguimiento)
    let taskId: string | undefined;
    try {
      const taskResource = createFollowUpTask(
        observation,
        patient,
        practitioner,
        evaluation
      );

      const createdTask = await medplum.createResource(taskResource);
      
      taskId = createdTask.id;
      
      logBotActivity('info', '✅ Task creado', {
        taskId,
        priority: evaluation.priority,
        owner: practitioner.id,
      });
    } catch (error) {
      logBotActivity('error', 'Error al crear Task', {
        observationId: observation.id,
        error: error instanceof Error ? error.message : String(error),
      });
    }

    // Paso 8: Resultado final
    const executionTime = Date.now() - startTime;
    
    logBotActivity('info', '🎉 Bot completado exitosamente con alertas', {
      observationId: observation.id,
      severity: evaluation.severity,
      communicationId,
      taskId,
      executionTimeMs: executionTime,
    });

    return {
      success: true,
      observationId: observation.id!,
      severity: evaluation.severity,
      alertGenerated: !!communicationId,
      taskGenerated: !!taskId,
      communicationId,
      taskId,
    };

  } catch (error) {
    logBotActivity('error', '❌ Error inesperado en el bot', {
      error: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : undefined,
    });

    return {
      success: false,
      observationId: 'unknown',
      severity: BPSeverity.NORMAL,
      alertGenerated: false,
      taskGenerated: false,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

/**
 * Export default para compatibilidad con Medplum Bot Engine
 */
export default handler;
