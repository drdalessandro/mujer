import { describe, it, expect } from 'vitest';
import { Observation } from '@medplum/fhirtypes';
import { analyzeBPObservation, getSeverityDescription } from './bp-analyzer';
import { BPSeverityLevel, LOINC_CODES } from './types';

describe('BP Analyzer', () => {
  describe('analyzeBPObservation', () => {
    it('debería detectar crisis hipertensiva', () => {
      const observation: Observation = {
        resourceType: 'Observation',
        status: 'final',
        code: {
          coding: [
            {
              system: 'http://loinc.org',
              code: LOINC_CODES.BP_PANEL,
              display: 'Blood pressure panel',
            },
          ],
        },
        component: [
          {
            code: {
              coding: [
                {
                  system: 'http://loinc.org',
                  code: LOINC_CODES.SYSTOLIC,
                },
              ],
            },
            valueQuantity: {
              value: 185,
              unit: 'mmHg',
            },
          },
          {
            code: {
              coding: [
                {
                  system: 'http://loinc.org',
                  code: LOINC_CODES.DIASTOLIC,
                },
              ],
            },
            valueQuantity: {
              value: 125,
              unit: 'mmHg',
            },
          },
        ],
      };

      const result = analyzeBPObservation(observation);

      expect(result).not.toBeNull();
      expect(result?.severityLevel).toBe(BPSeverityLevel.CRITICAL);
      expect(result?.systolic).toBe(185);
      expect(result?.diastolic).toBe(125);
      expect(result?.requiresAlert).toBe(true);
      expect(result?.requiresTask).toBe(true);
      expect(result?.alertPriority).toBe('stat');
    });

    it('debería detectar HTA Estadio 2', () => {
      const observation: Observation = {
        resourceType: 'Observation',
        status: 'final',
        code: {
          coding: [
            {
              system: 'http://loinc.org',
              code: LOINC_CODES.BP_PANEL,
            },
          ],
        },
        component: [
          {
            code: {
              coding: [{ system: 'http://loinc.org', code: LOINC_CODES.SYSTOLIC }],
            },
            valueQuantity: { value: 165, unit: 'mmHg' },
          },
          {
            code: {
              coding: [{ system: 'http://loinc.org', code: LOINC_CODES.DIASTOLIC }],
            },
            valueQuantity: { value: 105, unit: 'mmHg' },
          },
        ],
      };

      const result = analyzeBPObservation(observation);

      expect(result?.severityLevel).toBe(BPSeverityLevel.HIGH);
      expect(result?.alertPriority).toBe('urgent');
    });

    it('debería detectar HTA Estadio 1', () => {
      const observation: Observation = {
        resourceType: 'Observation',
        status: 'final',
        code: {
          coding: [{ system: 'http://loinc.org', code: LOINC_CODES.BP_PANEL }],
        },
        component: [
          {
            code: {
              coding: [{ system: 'http://loinc.org', code: LOINC_CODES.SYSTOLIC }],
            },
            valueQuantity: { value: 145, unit: 'mmHg' },
          },
          {
            code: {
              coding: [{ system: 'http://loinc.org', code: LOINC_CODES.DIASTOLIC }],
            },
            valueQuantity: { value: 92, unit: 'mmHg' },
          },
        ],
      };

      const result = analyzeBPObservation(observation);

      expect(result?.severityLevel).toBe(BPSeverityLevel.MODERATE);
      expect(result?.requiresAlert).toBe(true);
      expect(result?.alertPriority).toBe('routine');
    });

    it('debería detectar valores normales', () => {
      const observation: Observation = {
        resourceType: 'Observation',
        status: 'final',
        code: {
          coding: [{ system: 'http://loinc.org', code: LOINC_CODES.BP_PANEL }],
        },
        component: [
          {
            code: {
              coding: [{ system: 'http://loinc.org', code: LOINC_CODES.SYSTOLIC }],
            },
            valueQuantity: { value: 120, unit: 'mmHg' },
          },
          {
            code: {
              coding: [{ system: 'http://loinc.org', code: LOINC_CODES.DIASTOLIC }],
            },
            valueQuantity: { value: 80, unit: 'mmHg' },
          },
        ],
      };

      const result = analyzeBPObservation(observation);

      expect(result?.severityLevel).toBe(BPSeverityLevel.NORMAL);
      expect(result?.requiresAlert).toBe(false);
      expect(result?.requiresTask).toBe(false);
    });

    it('debería detectar hipotensión', () => {
      const observation: Observation = {
        resourceType: 'Observation',
        status: 'final',
        code: {
          coding: [{ system: 'http://loinc.org', code: LOINC_CODES.BP_PANEL }],
        },
        component: [
          {
            code: {
              coding: [{ system: 'http://loinc.org', code: LOINC_CODES.SYSTOLIC }],
            },
            valueQuantity: { value: 85, unit: 'mmHg' },
          },
          {
            code: {
              coding: [{ system: 'http://loinc.org', code: LOINC_CODES.DIASTOLIC }],
            },
            valueQuantity: { value: 55, unit: 'mmHg' },
          },
        ],
      };

      const result = analyzeBPObservation(observation);

      expect(result?.severityLevel).toBe(BPSeverityLevel.LOW);
      expect(result?.requiresAlert).toBe(true);
    });

    it('debería retornar null para observación no-BP', () => {
      const observation: Observation = {
        resourceType: 'Observation',
        status: 'final',
        code: {
          coding: [
            {
              system: 'http://loinc.org',
              code: '2339-0', // Glucosa
              display: 'Glucose',
            },
          ],
        },
        valueQuantity: {
          value: 95,
          unit: 'mg/dL',
        },
      };

      const result = analyzeBPObservation(observation);

      expect(result).toBeNull();
    });

    it('debería rechazar valores inválidos', () => {
      const observation: Observation = {
        resourceType: 'Observation',
        status: 'final',
        code: {
          coding: [{ system: 'http://loinc.org', code: LOINC_CODES.BP_PANEL }],
        },
        component: [
          {
            code: {
              coding: [{ system: 'http://loinc.org', code: LOINC_CODES.SYSTOLIC }],
            },
            valueQuantity: { value: 80, unit: 'mmHg' }, // Sistólica menor que diastólica
          },
          {
            code: {
              coding: [{ system: 'http://loinc.org', code: LOINC_CODES.DIASTOLIC }],
            },
            valueQuantity: { value: 110, unit: 'mmHg' },
          },
        ],
      };

      const result = analyzeBPObservation(observation);

      expect(result).toBeNull();
    });
  });

  describe('getSeverityDescription', () => {
    it('debería retornar descripción para cada nivel', () => {
      expect(getSeverityDescription(BPSeverityLevel.CRITICAL)).toContain('Crisis');
      expect(getSeverityDescription(BPSeverityLevel.HIGH)).toContain('Estadio 2');
      expect(getSeverityDescription(BPSeverityLevel.MODERATE)).toContain('Estadio 1');
      expect(getSeverityDescription(BPSeverityLevel.NORMAL)).toContain('normal');
      expect(getSeverityDescription(BPSeverityLevel.LOW)).toContain('Hipotensión');
    });
  });
});
