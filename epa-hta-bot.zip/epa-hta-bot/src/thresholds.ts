/**
 * Umbrales Clínicos de Presión Arterial
 * Basados en las guías de la Sociedad Argentina de Cardiología (SAC)
 * 
 * EPA Bienestar IA - FemTech
 */

import { ClinicalThresholds, BPSeverity, BPEvaluation } from './types';

/**
 * Umbrales clínicos estándar según SAC
 * 
 * Referencia:
 * - Sociedad Argentina de Cardiología - Consenso de Hipertensión Arterial
 * - American Heart Association - 2017 Guidelines
 */
export const CLINICAL_THRESHOLDS: ClinicalThresholds = {
  // PA Normal
  normal: {
    systolic: 130,
    diastolic: 85,
  },

  // PA Elevada (no requiere alerta inmediata, seguimiento)
  elevated: {
    systolic: 140,
    diastolic: 90,
  },

  // Alerta Moderada - HTA Grado 1
  moderateAlert: {
    systolic: 160,
    diastolic: 100,
  },

  // Alerta Mayor - HTA Grado 2 (CRÍTICA)
  majorAlert: {
    systolic: 180,
    diastolic: 110,
  },

  // Crisis Hipertensiva - Emergencia Médica
  hypertensiveCrisis: {
    systolic: 180,
    diastolic: 120,
  },
};

/**
 * Umbrales específicos para Grupo B (Embarazo/Planificación de Maternidad)
 * Criterios más estrictos según guías de hipertensión en embarazo
 */
export const PREGNANCY_THRESHOLDS: ClinicalThresholds = {
  normal: {
    systolic: 120,
    diastolic: 80,
  },
  elevated: {
    systolic: 130,
    diastolic: 85,
  },
  moderateAlert: {
    systolic: 140,
    diastolic: 90,
  },
  majorAlert: {
    systolic: 160,
    diastolic: 100,
  },
  hypertensiveCrisis: {
    systolic: 160,
    diastolic: 110,
  },
};

/**
 * Evalúa los valores de presión arterial y determina la severidad
 * 
 * @param systolic - Presión sistólica en mmHg
 * @param diastolic - Presión diastólica en mmHg
 * @param usePregnancyThresholds - Si se deben usar umbrales de embarazo
 * @returns Evaluación completa con severidad y recomendaciones
 */
export function evaluateBloodPressure(
  systolic: number,
  diastolic: number,
  usePregnancyThresholds: boolean = false
): BPEvaluation {
  const thresholds = usePregnancyThresholds ? PREGNANCY_THRESHOLDS : CLINICAL_THRESHOLDS;

  // Crisis Hipertensiva - Máxima prioridad
  if (systolic >= thresholds.hypertensiveCrisis.systolic || 
      diastolic >= thresholds.hypertensiveCrisis.diastolic) {
    return {
      severity: BPSeverity.HYPERTENSIVE_CRISIS,
      systolic,
      diastolic,
      requiresAlert: true,
      priority: 'stat',
      message: `🚨 CRISIS HIPERTENSIVA: PA ${systolic}/${diastolic} mmHg. REQUIERE ATENCIÓN MÉDICA INMEDIATA.`,
    };
  }

  // Alerta Mayor - HTA Grado 2
  if (systolic >= thresholds.majorAlert.systolic || 
      diastolic >= thresholds.majorAlert.diastolic) {
    return {
      severity: BPSeverity.MAJOR_ALERT,
      systolic,
      diastolic,
      requiresAlert: true,
      priority: 'stat',
      message: `⚠️ ALERTA MAYOR HTA: PA ${systolic}/${diastolic} mmHg. Requiere contacto médico urgente.`,
    };
  }

  // Alerta Moderada - HTA Grado 1
  if (systolic >= thresholds.moderateAlert.systolic || 
      diastolic >= thresholds.moderateAlert.diastolic) {
    return {
      severity: BPSeverity.MODERATE_ALERT,
      systolic,
      diastolic,
      requiresAlert: true,
      priority: 'urgent',
      message: `⚠️ ALERTA MODERADA HTA: PA ${systolic}/${diastolic} mmHg. Requiere seguimiento médico.`,
    };
  }

  // PA Elevada - Seguimiento recomendado
  if (systolic >= thresholds.elevated.systolic || 
      diastolic >= thresholds.elevated.diastolic) {
    return {
      severity: BPSeverity.ELEVATED,
      systolic,
      diastolic,
      requiresAlert: false,
      priority: 'routine',
      message: `ℹ️ PA ELEVADA: ${systolic}/${diastolic} mmHg. Se recomienda monitoreo continuo.`,
    };
  }

  // PA Normal
  return {
    severity: BPSeverity.NORMAL,
    systolic,
    diastolic,
    requiresAlert: false,
    priority: 'routine',
    message: `✅ PA NORMAL: ${systolic}/${diastolic} mmHg.`,
  };
}

/**
 * Determina el tiempo máximo de respuesta según la severidad
 * 
 * @param severity - Nivel de severidad de la PA
 * @returns Tiempo en minutos para completar la tarea
 */
export function getResponseTimeMinutes(severity: BPSeverity): number {
  switch (severity) {
    case BPSeverity.HYPERTENSIVE_CRISIS:
      return 30; // 30 minutos - emergencia
    case BPSeverity.MAJOR_ALERT:
      return 120; // 2 horas - urgente
    case BPSeverity.MODERATE_ALERT:
      return 240; // 4 horas - prioritario
    case BPSeverity.ELEVATED:
      return 1440; // 24 horas - seguimiento
    default:
      return 2880; // 48 horas - rutina
  }
}

/**
 * Genera un mensaje personalizado para la paciente según el grupo
 * 
 * @param severity - Severidad de la PA
 * @param groupId - Grupo de la paciente (A, B, C, D)
 * @returns Mensaje educativo personalizado
 */
export function getPatientMessage(severity: BPSeverity, groupId: string): string {
  const baseMessages: Record<BPSeverity, string> = {
    [BPSeverity.NORMAL]: 
      'Tu presión arterial está en rango normal. ¡Excelente! Continúa con tus hábitos saludables.',
    
    [BPSeverity.ELEVATED]: 
      'Tu presión arterial está ligeramente elevada. Te recomendamos: reducir el consumo de sal, aumentar actividad física y manejar el estrés. Nuestro equipo hará seguimiento.',
    
    [BPSeverity.MODERATE_ALERT]: 
      'Tu presión arterial requiere atención médica. Un miembro de nuestro equipo te contactará pronto para evaluar y ajustar tu plan de bienestar.',
    
    [BPSeverity.MAJOR_ALERT]: 
      'Tu presión arterial está en un nivel que requiere atención urgente. Por favor, mantente disponible para que nuestro equipo médico te contacte inmediatamente.',
    
    [BPSeverity.HYPERTENSIVE_CRISIS]: 
      '⚠️ IMPORTANTE: Tu presión arterial está en un nivel crítico. Si tienes dolor de cabeza intenso, dolor de pecho, dificultad para respirar o cambios en la visión, dirígete a la emergencia más cercana AHORA. Nuestro equipo te contactará de inmediato.',
  };

  // Personalización por grupo
  let groupNote = '';
  switch (groupId) {
    case 'B': // Embarazo/Planificación
      groupNote = ' Es especialmente importante mantener tu presión controlada durante esta etapa.';
      break;
    case 'C': // Menopausia
      groupNote = ' Los cambios hormonales pueden afectar tu presión arterial. Estamos aquí para apoyarte.';
      break;
  }

  return baseMessages[severity] + groupNote;
}

/**
 * Verifica si una observación requiere notificación al equipo médico
 * 
 * @param evaluation - Resultado de la evaluación
 * @returns true si requiere alerta
 */
export function requiresMedicalAlert(evaluation: BPEvaluation): boolean {
  return evaluation.requiresAlert && 
         (evaluation.severity === BPSeverity.MODERATE_ALERT ||
          evaluation.severity === BPSeverity.MAJOR_ALERT ||
          evaluation.severity === BPSeverity.HYPERTENSIVE_CRISIS);
}
