/**
 * Tipos y interfaces para el Bot de Alertas de HTA
 * EPA Bienestar IA
 */

import { Observation, Communication, Task, Reference } from '@medplum/fhirtypes';

/**
 * Niveles de severidad de la presión arterial según SAC
 */
export enum BPSeverity {
  NORMAL = 'normal',
  ELEVATED = 'elevated',
  MODERATE_ALERT = 'moderate_alert',
  MAJOR_ALERT = 'major_alert',
  HYPERTENSIVE_CRISIS = 'hypertensive_crisis',
}

/**
 * Valores de presión arterial extraídos
 */
export interface BloodPressureValues {
  systolic: number;
  diastolic: number;
  unit: string;
}

/**
 * Resultado de la evaluación de presión arterial
 */
export interface BPEvaluation {
  severity: BPSeverity;
  systolic: number;
  diastolic: number;
  requiresAlert: boolean;
  priority: 'routine' | 'urgent' | 'stat';
  message: string;
}

/**
 * Configuración de umbrales clínicos
 */
export interface ClinicalThresholds {
  normal: {
    systolic: number;
    diastolic: number;
  };
  elevated: {
    systolic: number;
    diastolic: number;
  };
  moderateAlert: {
    systolic: number;
    diastolic: number;
  };
  majorAlert: {
    systolic: number;
    diastolic: number;
  };
  hypertensiveCrisis: {
    systolic: number;
    diastolic: number;
  };
}

/**
 * Contexto del bot para logging y debugging
 */
export interface BotContext {
  observationId: string;
  patientId: string;
  timestamp: string;
  severity: BPSeverity;
  values: BloodPressureValues;
}

/**
 * Resultado de la ejecución del bot
 */
export interface BotExecutionResult {
  success: boolean;
  observationId: string;
  severity: BPSeverity;
  alertGenerated: boolean;
  taskGenerated: boolean;
  communicationId?: string;
  taskId?: string;
  error?: string;
}

/**
 * Códigos LOINC para presión arterial
 */
export const LOINC_CODES = {
  BP_PANEL: '85354-9',
  SYSTOLIC_BP: '8480-6',
  DIASTOLIC_BP: '8462-4',
} as const;

/**
 * Categorías de Observation
 */
export const OBSERVATION_CATEGORIES = {
  VITAL_SIGNS: 'vital-signs',
} as const;

/**
 * Estados de recursos FHIR
 */
export const FHIR_STATUS = {
  OBSERVATION: {
    FINAL: 'final',
    PRELIMINARY: 'preliminary',
  },
  COMMUNICATION: {
    COMPLETED: 'completed',
    IN_PROGRESS: 'in-progress',
  },
  TASK: {
    REQUESTED: 'requested',
    ACCEPTED: 'accepted',
    IN_PROGRESS: 'in-progress',
    COMPLETED: 'completed',
  },
} as const;

/**
 * Prioridades para Communication y Task
 */
export const PRIORITY = {
  ROUTINE: 'routine',
  URGENT: 'urgent',
  STAT: 'stat',
} as const;

/**
 * Intents para Task
 */
export const TASK_INTENT = {
  ORDER: 'order',
  PLAN: 'plan',
} as const;

/**
 * Type guards
 */
export function isObservation(resource: any): resource is Observation {
  return resource?.resourceType === 'Observation';
}

export function isCommunication(resource: any): resource is Communication {
  return resource?.resourceType === 'Communication';
}

export function isTask(resource: any): resource is Task {
  return resource?.resourceType === 'Task';
}

/**
 * Helper para extraer ID de referencia FHIR
 */
export function extractIdFromReference(reference?: Reference): string | undefined {
  if (!reference?.reference) return undefined;
  const parts = reference.reference.split('/');
  return parts.length === 2 ? parts[1] : undefined;
}
