import { MedplumClient } from '@medplum/core';
import { Communication, Task, Observation, Patient, Reference } from '@medplum/fhirtypes';
import {
  BPAnalysisResult,
  BPSeverityLevel,
  SNOMED_CODES,
  TASK_CODES,
  createCodeableConcept,
  generateIdentifier,
  formatDateTime,
  getPatientFullName,
} from './types';

/**
 * Crea un recurso Communication para notificar una alerta de PA
 */
export async function createBPAlert(
  medplum: MedplumClient,
  observation: Observation,
  analysis: BPAnalysisResult,
  patient: Patient
): Promise<Communication> {
  const patientName = getPatientFullName(patient);
  const patientReference: Reference = {
    reference: `Patient/${patient.id}`,
    display: patientName,
  };

  // Determinar el código SNOMED según la severidad
  const reasonCode =
    analysis.severityLevel === BPSeverityLevel.LOW
      ? SNOMED_CODES.HYPOTENSION
      : analysis.severityLevel === BPSeverityLevel.CRITICAL
      ? SNOMED_CODES.HYPERTENSIVE_CRISIS
      : SNOMED_CODES.HYPERTENSION;

  // Construir el payload del mensaje
  const messagePayload = buildAlertMessage(patientName, analysis, observation);

  const communication: Communication = {
    resourceType: 'Communication',
    status: 'completed',
    priority: analysis.alertPriority,
    subject: patientReference,
    recipient: [
      {
        // En producción, esto debería referenciar al Practitioner o Organization responsable
        display: 'Equipo de Monitoreo Cardiovascular EPA Bienestar IA',
      },
    ],
    sent: formatDateTime(),
    payload: [
      {
        contentString: messagePayload,
      },
    ],
    reasonCode: [createCodeableConcept(reasonCode)],
    reasonReference: [
      {
        reference: `Observation/${observation.id}`,
        display: `PA ${analysis.systolic}/${analysis.diastolic} mmHg`,
      },
    ],
    identifier: [
      {
        system: 'http://epa-bienestar.com.ar/fhir/identifier/alert',
        value: generateIdentifier('BP-ALERT'),
      },
    ],
    category: [
      {
        coding: [
          {
            system: 'http://terminology.hl7.org/CodeSystem/communication-category',
            code: 'alert',
            display: 'Alert',
          },
        ],
      },
    ],
  };

  try {
    const createdCommunication = await medplum.createResource(communication);
    console.log(`✅ Communication creado: ${createdCommunication.id}`);
    return createdCommunication;
  } catch (error) {
    console.error('❌ Error al crear Communication:', error);
    throw error;
  }
}

/**
 * Crea un recurso Task para el seguimiento clínico
 */
export async function createBPTask(
  medplum: MedplumClient,
  observation: Observation,
  analysis: BPAnalysisResult,
  patient: Patient
): Promise<Task> {
  const patientName = getPatientFullName(patient);
  const patientReference: Reference = {
    reference: `Patient/${patient.id}`,
    display: patientName,
  };

  // Determinar el código de tarea según la severidad
  const taskCode =
    analysis.severityLevel === BPSeverityLevel.CRITICAL || analysis.severityLevel === BPSeverityLevel.HIGH
      ? TASK_CODES.URGENT_CALLBACK
      : analysis.severityLevel === BPSeverityLevel.LOW
      ? TASK_CODES.HYPOTENSION_EVALUATION
      : TASK_CODES.BP_FOLLOWUP;

  // Calcular fecha límite según prioridad
  const restriction = calculateTaskRestriction(analysis.severityLevel);

  const task: Task = {
    resourceType: 'Task',
    status: 'requested',
    intent: 'order',
    priority: analysis.taskPriority,
    code: createCodeableConcept(taskCode),
    description: buildTaskDescription(patientName, analysis),
    for: patientReference,
    authoredOn: formatDateTime(),
    lastModified: formatDateTime(),
    focus: {
      reference: `Observation/${observation.id}`,
      display: `Observación de PA ${analysis.systolic}/${analysis.diastolic} mmHg`,
    },
    identifier: [
      {
        system: 'http://epa-bienestar.com.ar/fhir/identifier/task',
        value: generateIdentifier('BP-TASK'),
      },
    ],
    restriction,
    businessStatus: {
      text: getBusinessStatusText(analysis.severityLevel),
    },
    // En producción, owner debería referenciar al Practitioner responsable
    owner: {
      display: 'Equipo de Monitoreo Cardiovascular',
    },
  };

  try {
    const createdTask = await medplum.createResource(task);
    console.log(`✅ Task creado: ${createdTask.id}`);
    return createdTask;
  } catch (error) {
    console.error('❌ Error al crear Task:', error);
    throw error;
  }
}

/**
 * Construye el mensaje de alerta completo
 */
function buildAlertMessage(patientName: string, analysis: BPAnalysisResult, observation: Observation): string {
  const timestamp = observation.effectiveDateTime || formatDateTime();
  const observationId = observation.id || 'desconocido';

  return `
${analysis.message}

👤 Paciente: ${patientName}
📊 Presión Arterial: ${analysis.systolic}/${analysis.diastolic} mmHg
📅 Fecha/Hora: ${timestamp}
🆔 ID Observación: ${observationId}

⚡ ACCIÓN REQUERIDA:
${getActionRecommendation(analysis.severityLevel)}

📋 Este mensaje fue generado automáticamente por el Sistema de Monitoreo Cardiovascular EPA Bienestar IA.
  `.trim();
}

/**
 * Construye la descripción de la tarea
 */
function buildTaskDescription(patientName: string, analysis: BPAnalysisResult): string {
  return `Seguimiento de paciente ${patientName} por presión arterial ${analysis.severityLevel}. PA: ${analysis.systolic}/${analysis.diastolic} mmHg.`;
}

/**
 * Obtiene la recomendación de acción según severidad
 */
function getActionRecommendation(level: BPSeverityLevel): string {
  const recommendations: Record<BPSeverityLevel, string> = {
    [BPSeverityLevel.CRITICAL]:
      '🚨 Contactar INMEDIATAMENTE a la paciente. Evaluar necesidad de derivación a emergencias. Verificar síntomas de daño a órganos blanco (cefalea, alteraciones visuales, dolor torácico, disnea).',
    [BPSeverityLevel.HIGH]:
      '📞 Contactar a la paciente dentro de las próximas 24 horas. Programar consulta médica urgente. Evaluar necesidad de inicio o ajuste de tratamiento antihipertensivo.',
    [BPSeverityLevel.MODERATE]:
      '📋 Programar seguimiento en 3-7 días. Revisar adherencia al Plan Bienestar 100 Días. Reforzar medidas no farmacológicas (dieta DASH, actividad física, manejo de estrés).',
    [BPSeverityLevel.LOW]:
      '🔍 Evaluar síntomas asociados (mareos, fatiga, síncope). Revisar medicación actual. Considerar ajustes si es sintomática.',
    [BPSeverityLevel.NORMAL]: 'Continuar con monitoreo de rutina.',
  };

  return recommendations[level];
}

/**
 * Calcula las restricciones de tiempo para la tarea
 */
function calculateTaskRestriction(level: BPSeverityLevel): Task['restriction'] {
  const now = new Date();
  let period;

  switch (level) {
    case BPSeverityLevel.CRITICAL:
      // Debe completarse en 2 horas
      period = {
        end: new Date(now.getTime() + 2 * 60 * 60 * 1000).toISOString(),
      };
      break;
    case BPSeverityLevel.HIGH:
      // Debe completarse en 24 horas
      period = {
        end: new Date(now.getTime() + 24 * 60 * 60 * 1000).toISOString(),
      };
      break;
    case BPSeverityLevel.MODERATE:
      // Debe completarse en 7 días
      period = {
        end: new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      };
      break;
    case BPSeverityLevel.LOW:
      // Debe completarse en 7 días
      period = {
        end: new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      };
      break;
    default:
      period = undefined;
  }

  return period ? { period } : undefined;
}

/**
 * Obtiene el texto del estado de negocio
 */
function getBusinessStatusText(level: BPSeverityLevel): string {
  const statusTexts: Record<BPSeverityLevel, string> = {
    [BPSeverityLevel.CRITICAL]: 'Pendiente - Prioridad CRÍTICA',
    [BPSeverityLevel.HIGH]: 'Pendiente - Prioridad ALTA',
    [BPSeverityLevel.MODERATE]: 'Pendiente - Seguimiento de rutina',
    [BPSeverityLevel.LOW]: 'Pendiente - Evaluación de hipotensión',
    [BPSeverityLevel.NORMAL]: 'Pendiente - Monitoreo de rutina',
  };

  return statusTexts[level];
}
