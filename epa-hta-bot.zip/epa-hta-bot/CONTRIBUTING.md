# Guía de Contribución - EPA HTA Bot

¡Gracias por tu interés en contribuir al Bot de Alertas de HTA de EPA Bienestar IA!

## 📋 Tabla de Contenidos

1. [Código de Conducta](#código-de-conducta)
2. [Cómo Contribuir](#cómo-contribuir)
3. [Configuración del Entorno](#configuración-del-entorno)
4. [Estándares de Código](#estándares-de-código)
5. [Proceso de Pull Request](#proceso-de-pull-request)
6. [Reportar Bugs](#reportar-bugs)
7. [Sugerir Mejoras](#sugerir-mejoras)

## 🤝 Código de Conducta

### Nuestro Compromiso

En el interés de fomentar un ambiente abierto y acogedor, nosotros como contribuidores y mantenedores nos comprometemos a hacer de la participación en nuestro proyecto y nuestra comunidad una experiencia libre de acoso para todos.

### Estándares

- ✅ Usar lenguaje acogedor e inclusivo
- ✅ Respetar puntos de vista y experiencias diferentes
- ✅ Aceptar críticas constructivas con gracia
- ✅ Enfocarse en lo que es mejor para la comunidad
- ✅ Mostrar empatía hacia otros miembros

## 🚀 Cómo Contribuir

### Tipos de Contribuciones Bienvenidas

1. **Corrección de Bugs** 🐛
2. **Nuevas Funcionalidades** ✨
3. **Mejoras en Documentación** 📚
4. **Tests** 🧪
5. **Optimizaciones de Rendimiento** ⚡
6. **Mejoras de UX** 🎨

### Antes de Empezar

1. **Familiarízate con el proyecto**
   - Lee el README.md completo
   - Revisa la documentación en DEPLOYMENT.md
   - Entiende los umbrales clínicos en src/thresholds.ts

2. **Verifica si ya existe**
   - Busca en Issues existentes
   - Revisa Pull Requests abiertos
   - Consulta el CHANGELOG.md

3. **Contacta al equipo**
   - Para cambios grandes, abre un Issue primero
   - Discute tu propuesta antes de comenzar
   - Email: alejandro@epa-bienestar.com.ar

## 🛠️ Configuración del Entorno

### Requisitos

```bash
node >= 18.x
npm >= 9.x
git
```

### Instalación

```bash
# 1. Fork del repositorio en GitHub

# 2. Clonar tu fork
git clone https://github.com/TU_USUARIO/epa-hta-bot.git
cd epa-hta-bot

# 3. Agregar upstream
git remote add upstream https://github.com/drdalessandro/epa-hta-bot.git

# 4. Instalar dependencias
npm install

# 5. Crear rama para tu feature
git checkout -b feature/mi-feature

# 6. Compilar
npm run build

# 7. Ejecutar tests
npm test
```

## 📝 Estándares de Código

### TypeScript

- ✅ Usar TypeScript strict mode
- ✅ Documentar funciones públicas con JSDoc
- ✅ Usar tipos explícitos (evitar `any`)
- ✅ Nombres descriptivos para variables y funciones

### Ejemplo de Código Bien Documentado

```typescript
/**
 * Evalúa la presión arterial según umbrales clínicos de la SAC
 * 
 * @param systolic - Presión sistólica en mmHg
 * @param diastolic - Presión diastólica en mmHg
 * @param usePregnancyThresholds - Si usar umbrales de embarazo
 * @returns Evaluación completa con severidad y mensaje
 * 
 * @example
 * const result = evaluateBloodPressure(165, 105);
 * console.log(result.severity); // 'major_alert'
 */
export function evaluateBloodPressure(
  systolic: number,
  diastolic: number,
  usePregnancyThresholds: boolean = false
): BPEvaluation {
  // Implementación...
}
```

### Estilo de Código

Usamos **ESLint** y **Prettier** para mantener consistencia:

```bash
# Verificar estilo
npm run lint

# Auto-formatear
npm run format
```

### Configuración Prettier

```json
{
  "semi": true,
  "singleQuote": true,
  "printWidth": 100,
  "tabWidth": 2
}
```

### Commits

Usamos [Conventional Commits](https://www.conventionalcommits.org/):

```bash
# Formato
<tipo>(<ámbito>): <descripción>

# Tipos
feat:     Nueva funcionalidad
fix:      Corrección de bug
docs:     Cambios en documentación
style:    Formato, espacios, etc
refactor: Refactorización de código
test:     Agregar tests
chore:    Tareas de mantenimiento
perf:     Mejoras de rendimiento

# Ejemplos
feat(thresholds): agregar umbrales para Grupo C
fix(bot): corregir extracción de valores de PA
docs(readme): actualizar instrucciones de instalación
test(utils): agregar tests para extractBloodPressureValues
```

## 🔄 Proceso de Pull Request

### 1. Preparar el PR

```bash
# Asegurarse de estar actualizado
git checkout main
git pull upstream main

# Mergear cambios a tu rama
git checkout feature/mi-feature
git merge main

# Resolver conflictos si hay
```

### 2. Verificar Calidad

```bash
# Compilar sin errores
npm run build

# Todos los tests pasan
npm test

# No hay errores de lint
npm run lint

# Cobertura de tests adecuada
npm run test:coverage
```

### 3. Crear el PR

1. Push de tu rama:
   ```bash
   git push origin feature/mi-feature
   ```

2. En GitHub, crear Pull Request hacia `main`

3. Completar la plantilla del PR:
   ```markdown
   ## Descripción
   [Describe qué cambia y por qué]

   ## Tipo de Cambio
   - [ ] Bug fix
   - [ ] Nueva funcionalidad
   - [ ] Breaking change
   - [ ] Documentación

   ## Checklist
   - [ ] Mi código sigue el estilo del proyecto
   - [ ] He realizado una auto-revisión
   - [ ] He comentado código complejo
   - [ ] He actualizado la documentación
   - [ ] Mis cambios no generan nuevas advertencias
   - [ ] He agregado tests
   - [ ] Todos los tests pasan
   ```

### 4. Code Review

- Responde a comentarios constructivamente
- Realiza cambios solicitados prontamente
- Mantén conversación en el PR

### 5. Merge

- El equipo revisará y mergeará cuando esté listo
- Elimina tu rama después del merge

## 🐛 Reportar Bugs

### Antes de Reportar

1. Verifica que uses la última versión
2. Busca en Issues existentes
3. Intenta reproducir el bug

### Template de Bug Report

```markdown
**Descripción del Bug**
[Descripción clara y concisa]

**Pasos para Reproducir**
1. Crear Observation con '...'
2. Ejecutar bot
3. Ver error

**Comportamiento Esperado**
[Qué debería pasar]

**Comportamiento Actual**
[Qué pasa en realidad]

**Screenshots/Logs**
[Si aplica]

**Entorno**
- OS: [e.g., Ubuntu 22.04]
- Node version: [e.g., 18.17.0]
- npm version: [e.g., 9.6.7]
- Medplum version: [e.g., 3.2.0]

**Contexto Adicional**
[Cualquier información relevante]
```

## 💡 Sugerir Mejoras

### Template de Feature Request

```markdown
**¿Tu feature request está relacionado con un problema?**
[e.g., "Siempre me frustra cuando..."]

**Describe la solución que te gustaría**
[Descripción clara de lo que quieres]

**Describe alternativas que has considerado**
[Otras soluciones que consideraste]

**Contexto Adicional**
[Screenshots, mockups, referencias]

**Impacto Esperado**
- [ ] Grupos afectados: A / B / C / D
- [ ] Equipo médico
- [ ] Sistema técnico
```

## 🏥 Consideraciones Médicas

### Cambios en Umbrales Clínicos

**IMPORTANTE**: Cualquier cambio en umbrales debe:

1. Estar respaldado por literatura médica
2. Ser revisado por el equipo de cardiología
3. Seguir guías de la SAC
4. Documentar referencias científicas

### Ejemplo de Documentación

```typescript
/**
 * Umbral para crisis hipertensiva
 * 
 * Basado en:
 * - Whelton PK, et al. 2017 ACC/AHA/AAPA/ABC/ACPM/AGS/APhA/ASH/ASPC/NMA/PCNA
 *   Guideline for the Prevention, Detection, Evaluation, and Management of 
 *   High Blood Pressure in Adults. Hypertension. 2018;71:e13-e115
 * - Sociedad Argentina de Cardiología - Consenso de HTA 2018
 * 
 * Revisado por: Dra. Analía Aquieri (SAC)
 * Fecha de revisión: 2025-12-04
 */
export const HYPERTENSIVE_CRISIS_THRESHOLD = {
  systolic: 180,
  diastolic: 120,
};
```

## 📊 Testing

### Requisitos

- Cobertura mínima: 80%
- Todos los tests deben pasar
- Agregar tests para nuevas funcionalidades

### Estructura de Tests

```typescript
describe('Funcionalidad', () => {
  describe('Caso Exitoso', () => {
    it('debe hacer X cuando Y', () => {
      // Arrange
      const input = ...;
      
      // Act
      const result = myFunction(input);
      
      // Assert
      expect(result).toBe(expected);
    });
  });

  describe('Casos Edge', () => {
    it('debe manejar valores límite', () => {
      // ...
    });
  });

  describe('Manejo de Errores', () => {
    it('debe lanzar error con input inválido', () => {
      expect(() => myFunction(invalid)).toThrow();
    });
  });
});
```

## 🔒 Seguridad

### Reportar Vulnerabilidades

**NO** abras un Issue público para vulnerabilidades de seguridad.

En su lugar:
1. Email a: seguridad@epa-bienestar.com.ar
2. Incluye descripción detallada
3. Pasos para reproducir
4. Impacto potencial

## 📞 Contacto

- **Email**: alejandro@epa-bienestar.com.ar
- **GitHub Issues**: Para bugs y features
- **Equipo Médico**: Para consultas clínicas

## 🙏 Reconocimientos

Contribuidores destacados serán reconocidos en el README.md y en releases notes.

---

¡Gracias por contribuir a mejorar la salud cardiovascular de las mujeres! ❤️

**EPA Bienestar IA**  
Buenos Aires, Argentina
