# EPA Bienestar IA - Bot de Alertas de Hipertensión Arterial (HTA)

## 🎯 Descripción

Bot automatizado para **EPA Bienestar IA** que monitorea mediciones de presión arterial y genera alertas automáticas cuando se detectan valores críticos. Implementado con **FHIR R4** y **Medplum**.

### Problema que Resuelve

Las mujeres tienen **46% menos probabilidades** de recibir tratamiento adecuado para hipertensión que los hombres. Este bot:

- ✅ Detecta valores críticos de presión arterial en tiempo real
- ✅ Genera alertas automáticas al equipo médico (Dras. Aquieri, Crosa, Pages, Cavenago)
- ✅ Crea tareas rastreables para seguimiento
- ✅ Mantiene registro auditable completo según estándares FHIR R4

### Grupos Objetivo

Principalmente enfocado en:
- **Grupo A** (18-30): Detección temprana y educación
- **Grupo B** (28-40): Monitoreo durante planificación de maternidad
- **Grupo C** (45-65): Prevención cardiovascular en menopausia
- **Grupo D** (65+): Seguimiento continuo

---

## 🏗️ Arquitectura Técnica

### Flujo de Trabajo

```
1. Paciente → Registra PA manual en THRIVE
                ↓
2. FHIR Observation (LOINC 85354-9) → Creado en Medplum
                ↓
3. Bot EPA-HTA → Se ejecuta automáticamente
                ↓
4. Evaluación → Compara con umbrales SAC
                ↓
5a. PA Normal → Log y termina
5b. PA Crítica → Genera Communication + Task
                ↓
6. Alertas → Notificación al equipo médico
                ↓
7. Seguimiento → Task asignado a Practitioner
```

### Recursos FHIR Utilizados

| Recurso | Propósito | Estándar |
|---------|-----------|----------|
| `Observation` | Registro de PA (trigger) | LOINC 85354-9 |
| `Communication` | Alerta al equipo médico | FHIR R4 Communication |
| `Task` | Gestión de seguimiento | FHIR R4 Task |
| `Patient` | Mujer en el sistema | FHIR R4 Patient |
| `Practitioner` | Profesional responsable | FHIR R4 Practitioner |

---

## 📋 Requisitos Previos

- **Node.js** >= 18.x
- **npm** >= 9.x
- **Cuenta Medplum** con acceso a Bot deployment
- **TypeScript** >= 5.x

---

## 🚀 Instalación

### 1. Clonar el repositorio

```bash
git clone https://github.com/drdalessandro/epa-hta-bot.git
cd epa-hta-bot
```

### 2. Instalar dependencias

```bash
npm install
```

### 3. Configurar Medplum

Edita `medplum.config.json` con tus credenciales:

```json
{
  "bots": [
    {
      "name": "epa-hta-alert-bot",
      "id": "tu-bot-id-aqui",
      "source": "src/index.ts",
      "dist": "dist/index.js"
    }
  ]
}
```

### 4. Compilar

```bash
npm run build
```

### 5. Desplegar a Medplum

```bash
npm run deploy
```

---

## ⚙️ Configuración Clínica

### Umbrales de Presión Arterial (SAC)

Basados en las guías de la **Sociedad Argentina de Cardiología**:

```
Normal
Sistólica: < 130 mmHg
Diastólica: < 85 mmHg

Alerta Moderada
Sistólica: 140-159 mmHg
Diastólica: 90-99 mmHg

Alerta Mayor (CRÍTICA)
Sistólica: ≥ 160 mmHg
Diastólica: ≥ 100 mmHg

Crisis Hipertensiva
Sistólica: ≥ 180 mmHg
Diastólica: ≥ 120 mmHg
```

---

## 📊 Códigos LOINC Utilizados

| Código | Descripción |
|--------|-------------|
| `85354-9` | Blood pressure panel with all children |
| `8480-6` | Systolic blood pressure |
| `8462-4` | Diastolic blood pressure |

---

## 📦 Estructura del Proyecto

```
epa-hta-bot/
├── src/
│   ├── index.ts              # Bot principal
│   ├── types.ts              # Tipos TypeScript
│   ├── thresholds.ts         # Umbrales clínicos SAC
│   └── utils.ts              # Funciones utilitarias
├── examples/
│   ├── observation.json      # Ejemplo de Observation
│   ├── communication.json    # Ejemplo de Communication
│   └── task.json             # Ejemplo de Task
├── package.json
├── tsconfig.json
├── medplum.config.json
├── .gitignore
└── README.md
```

---

## 🔐 Seguridad y Cumplimiento

- ✅ **HIPAA Compliant** (AWS HealthLake + Medplum)
- ✅ **FHIR R4 Standard**
- ✅ Logs auditables de todas las alertas
- ✅ Encriptación en tránsito y reposo
- ✅ Control de acceso basado en roles (RBAC)

---

## 🤝 Equipo Médico

**Cardiólogas - Sociedad Argentina de Cardiología:**
- Dra. Analía Aquieri
- Dra. Verónica Crosa
- Dra. Marisa Pages
- Dra. Viviana Cavenago

**Gestión de Programa:**
- Mg. Giovanna Sanguinetti

---

## 📄 Licencia

Copyright © 2025 EPA Bienestar IA

---

## 📞 Contacto

**Alejandro D'Alessandro**  
Líder de Producto - EPA Bienestar IA  
Buenos Aires, Argentina
