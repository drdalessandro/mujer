# Changelog

Todos los cambios notables en el proyecto EPA HTA Bot serán documentados en este archivo.

El formato está basado en [Keep a Changelog](https://keepachangelog.com/es-ES/1.0.0/),
y este proyecto adhiere a [Semantic Versioning](https://semver.org/lang/es/).

## [1.0.0] - 2025-12-04

### Agregado
- ✨ Implementación inicial del bot de alertas de HTA
- 📊 Sistema de evaluación de presión arterial según guías SAC
- 🚨 Generación automática de alertas (Communication) para PA crítica
- ✅ Creación automática de tareas (Task) para seguimiento médico
- 📋 Umbrales clínicos diferenciados:
  - Normal: < 130/85 mmHg
  - Elevada: 140-159/90-99 mmHg
  - Alerta Moderada: 160-179/100-109 mmHg
  - Alerta Mayor: ≥ 180/110 mmHg
  - Crisis Hipertensiva: ≥ 180/120 mmHg
- 🤰 Soporte para umbrales especiales en embarazo (Grupo B)
- 📝 Logs estructurados con JSON
- 🧪 Suite de tests unitarios con Jest
- 📚 Documentación completa (README, DEPLOYMENT)
- 🔧 Configuración de TypeScript, ESLint, Prettier
- 📦 Ejemplos de recursos FHIR (Patient, Practitioner, Observation, etc.)

### Recursos FHIR Soportados
- `Observation` (LOINC 85354-9) - Trigger del bot
- `Communication` - Alertas al equipo médico
- `Task` - Seguimiento estructurado
- `Patient` - Información de pacientes
- `Practitioner` - Equipo médico (SAC)

### Características Técnicas
- FHIR R4 compliant
- TypeScript con strict mode
- Integración con Medplum Bot Engine
- AWS Lambda runtime
- Manejo robusto de errores
- Validación exhaustiva de datos

### Equipo Médico Integrado
- Dra. Analía Aquieri (SAC)
- Dra. Verónica Crosa (SAC)
- Dra. Marisa Pages (SAC)
- Dra. Viviana Cavenago (SAC)
- Mg. Giovanna Sanguinetti (Coordinación)

### Seguridad
- HIPAA Compliant
- Encriptación en tránsito y reposo
- Logs auditables
- Control de acceso basado en roles

## [Unreleased]

### Planeado para v1.1.0
- 🔄 Integración con Terra API para wearables
- 🤖 Modelo ML de predicción de crisis hipertensivas
- 📊 Dashboard web para equipo médico
- 📱 Notificaciones push móviles
- 🔗 Integración con HCEN (Historia Clínica Electrónica Nacional)
- 👥 Asignación inteligente de practitioners según carga de trabajo
- 📈 Métricas y analytics avanzados

### Planeado para v1.2.0
- 🧬 Digital Twins cardiovasculares
- 🎯 Personalización por grupos (A/B/C/D)
- 🌡️ Integración con otros vitales (frecuencia cardíaca, temperatura)
- 📊 Reportes automatizados para el equipo médico
- 🔍 Detección de patrones y tendencias
- 💊 Integración con MedicationRequest

### Consideraciones Futuras
- Soporte multi-idioma (portugués para expansión LATAM)
- Integración con sistemas de obra social argentinos
- API pública para terceros autorizados
- Modo offline para zonas con conectividad limitada

---

## Formato de Versiones

- **MAJOR**: Cambios incompatibles con versiones anteriores
- **MINOR**: Nueva funcionalidad compatible con versiones anteriores
- **PATCH**: Correcciones de bugs compatibles con versiones anteriores

## Tipos de Cambios

- `Agregado`: Nueva funcionalidad
- `Cambiado`: Cambios en funcionalidad existente
- `Deprecado`: Funcionalidad que será removida en versiones futuras
- `Removido`: Funcionalidad eliminada
- `Corregido`: Corrección de bugs
- `Seguridad`: Vulnerabilidades corregidas

---

**Mantenedor**: Alejandro D'Alessandro  
**Organización**: EPA Bienestar IA  
**Ubicación**: Buenos Aires, Argentina
