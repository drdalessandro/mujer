# 🚀 Guía de Deployment - Bot de Monitoreo HTA

Esta guía detalla el proceso completo de deployment del Bot de Monitoreo de Hipertensión Arterial en el ambiente de producción de EPA Bienestar IA.

---

## 📋 Pre-requisitos

### Cuentas y Accesos

- ✅ Cuenta en Medplum (Cloud o Self-hosted)
- ✅ AWS Account (para Lambda/HealthLake)
- ✅ GitHub Account (para CI/CD)
- ✅ Node.js 20+ instalado
- ✅ npm o yarn instalado
- ✅ Git configurado

### Permisos Necesarios

- **Medplum**:
  - Project Admin
  - Bot create/update/deploy
  - Subscription create
  - Patient read
  - Observation read
  - Communication create
  - Task create

- **AWS**:
  - Lambda create/update
  - IAM role management
  - CloudWatch Logs access
  - Secrets Manager access (opcional)

---

## 🔧 Setup Inicial

### 1. Clonar Repositorio

```bash
git clone https://github.com/drdalessandro/epa-hta-bot.git
cd epa-hta-bot
```

### 2. Instalar Dependencias

```bash
npm install
```

### 3. Configurar Credenciales de Medplum

#### Opción A: ClientApplication (Recomendado para CI/CD)

1. Navegar a Medplum: `https://app.medplum.com/ClientApplication`
2. Click en "New..."
3. Completar:
   - **Name**: `EPA HTA Bot CLI`
   - **Description**: `Cliente para deploy del Bot de HTA`
4. Click "Create"
5. Copiar **Client ID** y **Client Secret**

#### Opción B: Login Interactivo

```bash
npx medplum login
```

### 4. Crear Archivo .env

```bash
cp .env.example .env
```

Editar `.env`:

```env
MEDPLUM_BASE_URL=https://api.medplum.com
MEDPLUM_CLIENT_ID=tu_client_id_aqui
MEDPLUM_CLIENT_SECRET=tu_client_secret_aqui
```

### 5. Verificar Setup

```bash
# Compilar
npm run build

# Verificar compilación
ls dist/
# Deberías ver: index.js, index.d.ts, etc.

# Ejecutar tests
npm test
```

---

## 🤖 Crear Bot en Medplum

### Via UI (Recomendado para primera vez)

1. Navegar a: `https://app.medplum.com/Bot`
2. Click en "New..."
3. Completar formulario:
   ```
   Name: EPA HTA Monitoring Bot
   Description: Bot de monitoreo automático de presión arterial crítica
   ```
4. Click "Create"
5. **Copiar el Bot ID** que aparece en la URL:
   ```
   https://app.medplum.com/Bot/[ESTE_ES_EL_ID]
   ```

### Via CLI (Alternativo)

```bash
# El comando create aún no existe en CLI
# Usar UI por ahora
```

### 6. Configurar Bot ID

Editar `medplum.config.json`:

```json
{
  "bots": [
    {
      "name": "hta-monitoring-bot",
      "id": "PEGAR_BOT_ID_AQUI",
      "source": "src/index.ts",
      "dist": "dist/index.js"
    }
  ]
}
```

---

## 📤 Deploy del Bot

### Deploy Manual

```bash
# 1. Asegurar que está compilado
npm run build

# 2. Deploy a Medplum
npx medplum bot deploy hta-monitoring-bot

# Output esperado:
# ✓ Saving code...
# ✓ Deploying bot...
# ✓ Success! New bot version: [version-id]
```

### Verificar Deploy

1. Navegar a: `https://app.medplum.com/Bot/TU_BOT_ID`
2. Pestaña "Code" → Verificar que el código está actualizado
3. Pestaña "Editor" → Click "Execute" para test manual

### Test Manual en Editor

Input de prueba (pegar en "Input"):

```json
{
  "resourceType": "Observation",
  "status": "final",
  "code": {
    "coding": [
      {
        "system": "http://loinc.org",
        "code": "85354-9"
      }
    ]
  },
  "subject": {
    "reference": "Patient/test-patient-id"
  },
  "component": [
    {
      "code": {
        "coding": [{"system": "http://loinc.org", "code": "8480-6"}]
      },
      "valueQuantity": {"value": 185, "unit": "mmHg"}
    },
    {
      "code": {
        "coding": [{"system": "http://loinc.org", "code": "8462-4"}]
      },
      "valueQuantity": {"value": 125, "unit": "mmHg"}
    }
  ]
}
```

Click "Execute" → Verificar output en "Outcome".

---

## 🔔 Configurar Subscription

La Subscription activa el Bot automáticamente cuando se crean/actualizan Observations de PA.

### 1. Crear Subscription

Navegar a: `https://app.medplum.com/Subscription`

Click "New..."

Pegar JSON:

```json
{
  "resourceType": "Subscription",
  "status": "active",
  "reason": "Monitoreo automático de presión arterial crítica - EPA Bienestar IA",
  "criteria": "Observation?code=http://loinc.org|85354-9,http://loinc.org|8480-6,http://loinc.org|8462-4",
  "channel": {
    "type": "rest-hook",
    "endpoint": "Bot/TU_BOT_ID_AQUI",
    "payload": "application/fhir+json"
  },
  "meta": {
    "tag": [
      {
        "system": "http://epa-bienestar.com.ar/fhir/tags",
        "code": "cardiovascular-monitoring",
        "display": "Sistema de Monitoreo Cardiovascular"
      }
    ]
  }
}
```

**IMPORTANTE**: Reemplazar `TU_BOT_ID_AQUI` con el ID real del Bot.

### 2. Verificar Subscription

Crear una Observation de prueba:

```bash
curl -X POST https://api.medplum.com/fhir/R4/Observation \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/fhir+json" \
  -d '{
  "resourceType": "Observation",
  "status": "final",
  "code": {
    "coding": [{"system": "http://loinc.org", "code": "85354-9"}]
  },
  "subject": {"reference": "Patient/test-patient"},
  "component": [
    {
      "code": {"coding": [{"system": "http://loinc.org", "code": "8480-6"}]},
      "valueQuantity": {"value": 185, "unit": "mmHg"}
    },
    {
      "code": {"coding": [{"system": "http://loinc.org", "code": "8462-4"}]},
      "valueQuantity": {"value": 125, "unit": "mmHg"}
    }
  ]
}'
```

Verificar que:
1. Se creó la Observation
2. El Bot se ejecutó (ver Events en `Bot/TU_BOT_ID/event`)
3. Se crearon Communication y Task

---

## 👥 Configurar Practitioners y Organizations

Para que las alertas lleguen a las personas correctas:

### 1. Crear Practitioner

```json
{
  "resourceType": "Practitioner",
  "name": [
    {
      "family": "Aquieri",
      "given": ["Analía"],
      "prefix": ["Dra."]
    }
  ],
  "telecom": [
    {
      "system": "email",
      "value": "a.aquieri@epa-bienestar.com.ar"
    }
  ]
}
```

### 2. Actualizar resource-generator.ts

Editar `src/resource-generator.ts`:

```typescript
// Línea ~35
recipient: [
  {
    reference: "Practitioner/ID_DE_TU_PRACTITIONER",
    display: "Dra. Analía Aquieri"
  }
],

// Línea ~95
owner: {
  reference: "Practitioner/ID_DE_TU_PRACTITIONER",
  display: "Dra. Analía Aquieri"
}
```

Rebuild y redeploy:

```bash
npm run build
npx medplum bot deploy hta-monitoring-bot
```

---

## 🔄 CI/CD con GitHub Actions

### 1. Configurar Secrets en GitHub

Navegar a: `https://github.com/TU_USUARIO/epa-hta-bot/settings/secrets/actions`

Agregar secrets:

- `MEDPLUM_BASE_URL`: `https://api.medplum.com`
- `MEDPLUM_CLIENT_ID`: Tu Client ID
- `MEDPLUM_CLIENT_SECRET`: Tu Client Secret

### 2. Workflow Automático

El workflow en `.github/workflows/ci-cd.yml` se activará automáticamente en:

- Push a `main` → Deploy a producción
- Push a `develop` → Deploy a staging
- Pull Request → Tests y build

### 3. Manual Deploy desde GitHub

Ir a: `Actions` → Seleccionar workflow → `Run workflow`

---

## 📊 Monitoreo Post-Deployment

### 1. Verificar Events del Bot

```
https://app.medplum.com/Bot/TU_BOT_ID/event
```

Verificar:
- ✅ Eventos se están registrando
- ✅ Outcomes sin errores
- ✅ Latencia <500ms

### 2. Verificar Communications

```
https://app.medplum.com/Communication?_sort=-sent
```

Verificar que se están creando alertas.

### 3. Verificar Tasks

```
https://app.medplum.com/Task?status=requested
```

Verificar que se están creando tareas.

### 4. CloudWatch Logs (AWS)

Si estás en Medplum Cloud:

```
https://console.aws.amazon.com/cloudwatch/
→ Log groups
→ /aws/lambda/medplum-bot-[environment]
```

---

## 🚨 Troubleshooting

### Problema: Bot no se ejecuta

**Síntomas**: No aparecen eventos en `/event`

**Soluciones**:

1. Verificar que Subscription está `active`
2. Verificar que `criteria` coincide con códigos LOINC
3. Verificar que `endpoint` tiene el Bot ID correcto
4. Revisar logs de Subscription en Medplum

### Problema: Errores en ejecución

**Síntomas**: Events con outcome negativo

**Soluciones**:

1. Revisar logs en CloudWatch
2. Verificar que Patient existe
3. Verificar permisos del Bot (AccessPolicy)
4. Test en Editor local con mismo input

### Problema: No se crean Communication/Task

**Síntomas**: Bot se ejecuta pero no crea recursos

**Soluciones**:

1. Verificar que valores superan umbrales
2. Verificar permisos de escritura
3. Revisar logs para errores de creación
4. Verificar referencias a Patient son válidas

### Problema: Deploy falla

**Síntomas**: Error en `medplum bot deploy`

**Soluciones**:

```bash
# Limpiar y rebuildar
rm -rf dist node_modules
npm install
npm run build

# Verificar credenciales
npx medplum whoami

# Reintentar deploy
npx medplum bot deploy hta-monitoring-bot
```

### Problema: Tests fallan

```bash
# Limpiar cache
rm -rf node_modules/.vite

# Reinstalar
npm ci

# Ejecutar tests con verbose
npm test -- --reporter=verbose
```

---

## 📈 Optimizaciones Post-Deployment

### 1. Ajustar Lambda Memory

Si latencia es alta:

```typescript
// En Medplum bot settings
{
  "memory": 512 // Aumentar de 256 a 512 MB
}
```

### 2. Configurar Provisioned Concurrency

Para reducir cold starts:

```typescript
{
  "provisionedConcurrency": 2 // 2 instancias warm
}
```

### 3. Habilitar Caching

```typescript
// En index.ts
const patientCache = new Map();

async function getPatientFromObservation(medplum, observation) {
  const cacheKey = observation.subject?.reference;
  if (patientCache.has(cacheKey)) {
    return patientCache.get(cacheKey);
  }
  
  const patient = await medplum.readResource(...);
  patientCache.set(cacheKey, patient);
  return patient;
}
```

---

## 🔐 Security Hardening

### 1. Restringir AccessPolicy

```json
{
  "resourceType": "AccessPolicy",
  "resource": [
    {
      "resourceType": "Observation",
      "criteria": "Observation?code=85354-9,8480-6,8462-4"
    },
    {
      "resourceType": "Patient",
      "readonly": true
    },
    {
      "resourceType": "Communication",
      "writeonly": true
    },
    {
      "resourceType": "Task",
      "writeonly": true
    }
  ]
}
```

### 2. Rotar Secrets Regularmente

```bash
# Cada 90 días
1. Crear nuevo ClientApplication
2. Actualizar secrets en GitHub
3. Redeploy
4. Eliminar ClientApplication anterior
```

### 3. Habilitar Audit Logging

```typescript
// En bot settings
{
  "auditEventDestination": "resource" // Producción
}
```

---

## 📝 Checklist de Deployment

### Pre-Deployment

- [ ] Tests pasan localmente
- [ ] Build sin errores
- [ ] Linter sin warnings
- [ ] Documentación actualizada
- [ ] CHANGELOG.md actualizado

### Deployment

- [ ] Bot creado en Medplum
- [ ] Bot ID configurado en `medplum.config.json`
- [ ] Código deployado exitosamente
- [ ] Subscription creada y activa
- [ ] Practitioners configurados
- [ ] Test manual ejecutado

### Post-Deployment

- [ ] Events registrándose correctamente
- [ ] Communications creándose
- [ ] Tasks creándose
- [ ] Alertas llegando a profesionales
- [ ] CloudWatch Logs funcionando
- [ ] Monitoring configurado

### Rollback Plan

- [ ] Versión anterior del Bot identificada
- [ ] Comando de rollback preparado
- [ ] Proceso de notificación definido

```bash
# Rollback si es necesario
npx medplum bot deploy hta-monitoring-bot --version VERSION_ANTERIOR
```

---

## 🎉 ¡Deployment Exitoso!

Si llegaste aquí y todos los checks están ✅, ¡felicitaciones!

El Bot está ahora:
- ✅ Deployado en producción
- ✅ Monitoreando presión arterial 24/7
- ✅ Generando alertas automáticas
- ✅ Creando tasks de seguimiento
- ✅ Salvando vidas ❤️

---

## 📞 Soporte

- **Documentación**: [README.md](../README.md)
- **Arquitectura**: [ARCHITECTURE.md](./ARCHITECTURE.md)
- **Issues**: [GitHub Issues](https://github.com/drdalessandro/epa-hta-bot/issues)
- **Email**: info@epa-bienestar.com.ar

---

**EPA Bienestar IA - Tecnología al servicio de la salud cardiovascular femenina** 💜
