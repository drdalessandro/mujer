# 🏗️ Arquitectura Técnica - Bot de Monitoreo HTA

## Visión General

El Bot de Monitoreo de Hipertensión Arterial es un componente serverless que implementa detección automática y respuesta inteligente ante valores críticos de presión arterial, siguiendo estándares FHIR R4 y mejores prácticas clínicas.

---

## 📊 Diagrama de Arquitectura de Alto Nivel

```
┌─────────────────────────────────────────────────────────────┐
│                    EPA Bienestar IA Platform                │
│                                                              │
│  ┌────────────┐    ┌──────────────┐    ┌────────────────┐  │
│  │  Mobile    │    │   Web App    │    │  Wearables     │  │
│  │  Apps      │    │   Portal     │    │  (Terra API)   │  │
│  └─────┬──────┘    └──────┬───────┘    └───────┬────────┘  │
│        │                  │                     │           │
│        └──────────────────┴─────────────────────┘           │
│                           │                                 │
└───────────────────────────┼─────────────────────────────────┘
                            │
                            ▼
            ┌───────────────────────────────┐
            │      Medplum FHIR Server      │
            │    (AWS HealthLake + RDS)     │
            └───────────────┬───────────────┘
                            │
                ┌───────────┴───────────┐
                │                       │
                ▼                       ▼
    ┌─────────────────────┐  ┌──────────────────┐
    │   Subscription      │  │   REST API       │
    │   Engine            │  │   Endpoint       │
    └──────────┬──────────┘  └──────────────────┘
               │
               │ Event: Observation Created/Updated
               │ Filter: code=85354-9|8480-6|8462-4
               │
               ▼
    ┌─────────────────────┐
    │   AWS Lambda        │
    │   (Medplum Bot)     │
    │                     │
    │  ┌──────────────┐   │
    │  │   Handler    │   │
    │  │   (index.ts) │   │
    │  └──────┬───────┘   │
    │         │           │
    │  ┌──────▼───────┐   │
    │  │ BP Analyzer  │   │
    │  └──────┬───────┘   │
    │         │           │
    │  ┌──────▼────────┐  │
    │  │  Resource     │  │
    │  │  Generator    │  │
    │  └───────────────┘  │
    └──────────┬──────────┘
               │
               │ Creates
               │
      ┌────────┴─────────┐
      │                  │
      ▼                  ▼
┌─────────────┐    ┌─────────────┐
│Communication│    │    Task     │
│  (Alert)    │    │ (Workflow)  │
└─────┬───────┘    └──────┬──────┘
      │                   │
      └──────────┬────────┘
                 │
                 ▼
       ┌────────────────────┐
       │  Notification      │
       │  Service           │
       │  (SMS/Email/Push)  │
       └────────────────────┘
```

---

## 🧩 Componentes Principales

### 1. Event Trigger (Subscription)

**Propósito**: Activación automática del Bot ante cambios en Observations de PA.

**Configuración**:
```json
{
  "criteria": "Observation?code=85354-9,8480-6,8462-4",
  "channel": {
    "type": "rest-hook",
    "endpoint": "Bot/{bot-id}"
  }
}
```

**Comportamiento**:
- Monitorea tabla `Observation` en RDS
- Filtra por códigos LOINC específicos
- Dispara Lambda en <100ms

### 2. Handler Principal (index.ts)

**Responsabilidades**:
1. Validación de input
2. Orquestación de procesamiento
3. Manejo de errores
4. Logging estructurado
5. Generación de respuesta

**Flujo**:
```typescript
handler(medplum, event) {
  1. Validar Observation
  2. Analizar valores de PA
  3. Obtener datos del Patient
  4. Crear Communication (si requiere alerta)
  5. Crear Task (si requiere seguimiento)
  6. Retornar resultado
}
```

### 3. BP Analyzer (bp-analyzer.ts)

**Algoritmo de Clasificación**:

```
Input: Observation con valores sistólica/diastólica

┌─ Validación ─────────────────────────┐
│ ✓ ¿Es Observation de PA?            │
│ ✓ ¿Valores presentes?                │
│ ✓ ¿Valores en rango fisiológico?     │
│ ✓ ¿Sistólica > Diastólica?          │
└──────────────────────────────────────┘
           │
           ▼
┌─ Clasificación por Umbrales ─────────┐
│                                       │
│ SI sistólica ≥180 O diastólica ≥120  │
│ → CRITICAL (Crisis Hipertensiva)     │
│                                       │
│ SINO SI sistólica ≥160 O diast ≥100  │
│ → HIGH (HTA Estadio 2)               │
│                                       │
│ SINO SI sistólica ≥140 O diast ≥90   │
│ → MODERATE (HTA Estadio 1)           │
│                                       │
│ SINO SI sistólica ≤90 O diast ≤60    │
│ → LOW (Hipotensión)                  │
│                                       │
│ SINO → NORMAL                        │
└───────────────────────────────────────┘
           │
           ▼
┌─ Resultado ──────────────────────────┐
│ • severityLevel                      │
│ • requiresAlert                      │
│ • requiresTask                       │
│ • alertPriority                      │
│ • message                            │
└──────────────────────────────────────┘
```

### 4. Resource Generator (resource-generator.ts)

**Communication Builder**:
```typescript
Communication {
  status: "completed"
  priority: "stat" | "urgent" | "routine"
  subject: Reference<Patient>
  recipient: Reference<Practitioner|Organization>
  payload: {
    contentString: mensaje_estructurado
  }
  reasonCode: SNOMED_CT_code
  reasonReference: Reference<Observation>
}
```

**Task Builder**:
```typescript
Task {
  status: "requested"
  intent: "order"
  priority: "stat" | "urgent" | "routine"
  code: tipo_de_tarea
  for: Reference<Patient>
  focus: Reference<Observation>
  restriction: {
    period: { end: deadline }
  }
}
```

---

## 🔄 Flujo de Datos Detallado

### Escenario 1: PA Normal (120/80)

```
1. Usuario ingresa PA en app móvil
   └─> POST /Observation
       
2. Observation creado en Medplum
   └─> Subscription detecta evento
   
3. Bot ejecutado en Lambda
   ├─> Análisis: severityLevel = NORMAL
   ├─> requiresAlert = false
   └─> requiresTask = false
   
4. Resultado registrado en AuditEvent
   
5. No se crean recursos adicionales
```

### Escenario 2: Crisis Hipertensiva (185/125)

```
1. Usuario ingresa PA en app móvil
   └─> POST /Observation
       
2. Observation creado en Medplum
   └─> Subscription detecta evento
   
3. Bot ejecutado en Lambda
   ├─> Análisis: severityLevel = CRITICAL
   ├─> requiresAlert = true
   └─> requiresTask = true
   
4. Communication creado
   ├─> priority: "stat"
   ├─> payload: "⚠️ CRISIS HIPERTENSIVA..."
   └─> reasonCode: SNOMED 371063000
   
5. Task creado
   ├─> priority: "stat"
   ├─> code: "urgent-bp-callback"
   ├─> restriction.period.end: +2 horas
   └─> owner: Reference<Practitioner>
   
6. Notification Service activado
   ├─> SMS al profesional
   ├─> Email al profesional
   └─> Push notification en dashboard
   
7. AuditEvent registrado
   └─> Trazabilidad completa
```

---

## 💾 Modelo de Datos FHIR

### Observation (Input)

```json
{
  "resourceType": "Observation",
  "id": "obs-123",
  "status": "final",
  "category": [{
    "coding": [{
      "system": "http://terminology.hl7.org/CodeSystem/observation-category",
      "code": "vital-signs"
    }]
  }],
  "code": {
    "coding": [{
      "system": "http://loinc.org",
      "code": "85354-9",
      "display": "Blood pressure panel"
    }]
  },
  "subject": {
    "reference": "Patient/pat-456"
  },
  "effectiveDateTime": "2025-12-04T10:30:00Z",
  "component": [
    {
      "code": {
        "coding": [{
          "system": "http://loinc.org",
          "code": "8480-6"
        }]
      },
      "valueQuantity": {
        "value": 185,
        "unit": "mmHg"
      }
    },
    {
      "code": {
        "coding": [{
          "system": "http://loinc.org",
          "code": "8462-4"
        }]
      },
      "valueQuantity": {
        "value": 125,
        "unit": "mmHg"
      }
    }
  ]
}
```

### Communication (Output)

```json
{
  "resourceType": "Communication",
  "id": "comm-789",
  "status": "completed",
  "priority": "stat",
  "subject": {
    "reference": "Patient/pat-456"
  },
  "payload": [{
    "contentString": "⚠️ CRISIS HIPERTENSIVA DETECTADA: PA 185/125 mmHg..."
  }],
  "reasonCode": [{
    "coding": [{
      "system": "http://snomed.info/sct",
      "code": "371063000",
      "display": "Crisis hipertensiva"
    }]
  }],
  "reasonReference": [{
    "reference": "Observation/obs-123"
  }]
}
```

### Task (Output)

```json
{
  "resourceType": "Task",
  "id": "task-321",
  "status": "requested",
  "intent": "order",
  "priority": "stat",
  "code": {
    "coding": [{
      "system": "http://epa-bienestar.com.ar/fhir/CodeSystem/task-type",
      "code": "urgent-bp-callback"
    }]
  },
  "for": {
    "reference": "Patient/pat-456"
  },
  "focus": {
    "reference": "Observation/obs-123"
  },
  "restriction": {
    "period": {
      "end": "2025-12-04T12:30:00Z"
    }
  }
}
```

---

## ⚡ Performance y Escalabilidad

### Métricas Objetivo

| Métrica | Objetivo | Actual |
|---------|----------|--------|
| Latencia de procesamiento | <500ms | ~200ms |
| Throughput | 1000 obs/min | Ilimitado* |
| Error rate | <0.1% | <0.01% |
| Lambda cold start | <2s | ~1.5s |

\* Limitado por throttling de Lambda (1000 concurrent)

### Optimizaciones

1. **Lambda**:
   - Memory: 256 MB (óptimo para Node.js)
   - Timeout: 30s
   - Concurrent executions: 100 (reservado)

2. **Caching**:
   - Patient lookup cacheado en memory
   - Code systems pre-indexados
   - Reduced API calls a Medplum

3. **Batch Processing**:
   - Futuro: Procesar múltiples observations en un invoke
   - Reducir cold starts

### Escalabilidad

```
┌─ Volumen Bajo (<100 obs/día) ────────────┐
│ • Subscription directa                    │
│ • Lambda on-demand                        │
│ • Sin optimizaciones especiales           │
└───────────────────────────────────────────┘

┌─ Volumen Medio (100-1000 obs/día) ───────┐
│ • Subscription directa                    │
│ • Lambda con provisioned concurrency      │
│ • Caching de Patient data                 │
└───────────────────────────────────────────┘

┌─ Volumen Alto (>1000 obs/día) ───────────┐
│ • SQS queue entre Subscription y Lambda   │
│ • Lambda con auto-scaling                 │
│ • Batch processing (10-100 obs/invoke)    │
│ • Distributed caching (ElastiCache)       │
└───────────────────────────────────────────┘
```

---

## 🔐 Seguridad

### Autenticación

- Bot ejecuta con `ClientCredentials` OAuth2
- Token temporal por invocación
- Rotación automática de secrets en AWS Secrets Manager

### Autorización

AccessPolicy del Bot:
```json
{
  "resource": [
    {"resourceType": "Observation", "criteria": "Observation?code=85354-9"},
    {"resourceType": "Patient"},
    {"resourceType": "Communication"},
    {"resourceType": "Task"}
  ]
}
```

### Encriptación

- **En tránsito**: TLS 1.3
- **En reposo**: AES-256 (AWS KMS)
- **Secrets**: AWS Secrets Manager

### Auditoría

Todos los eventos registrados como `AuditEvent`:
```json
{
  "resourceType": "AuditEvent",
  "type": "rest",
  "subtype": "Bot Execution",
  "action": "E",
  "recorded": "2025-12-04T10:30:00Z",
  "agent": [{
    "who": {"reference": "Bot/hta-monitoring"}
  }],
  "entity": [{
    "what": {"reference": "Observation/obs-123"}
  }]
}
```

---

## 🧪 Testing Strategy

### Pirámide de Testing

```
        ┌──────────────┐
        │   E2E Tests  │  (5%)
        │   Cypress    │
        ├──────────────┤
        │              │
        │ Integration  │  (15%)
        │   Tests      │
        ├──────────────┤
        │              │
        │              │
        │   Unit       │  (80%)
        │   Tests      │
        │   (Vitest)   │
        └──────────────┘
```

### Unit Tests

- **bp-analyzer.test.ts**: 30+ casos
  - Cada nivel de severidad
  - Edge cases
  - Valores inválidos
  - Formatos alternativos

- **resource-generator.test.ts**: 20+ casos
  - Construcción de Communication
  - Construcción de Task
  - Priorización correcta
  - Referencias válidas

- **index.test.ts**: 15+ casos
  - Flujo completo
  - Manejo de errores
  - Patient lookup
  - Logging

### Integration Tests

- Medplum MockClient
- Flujos end-to-end simulados
- Validación FHIR schema

### E2E Tests (Futuro)

- Deploy en staging
- Observations reales
- Verificación de notificaciones

---

## 📦 Deployment

### Environments

1. **Development**
   - Local con Medplum dev server
   - MockClient para testing
   - Hot reload

2. **Staging**
   - Medplum cloud (proyecto staging)
   - Subset de datos reales
   - CI/CD automated

3. **Production**
   - Medplum cloud (proyecto prod)
   - Datos reales de pacientes
   - Manual approval en CI/CD

### CI/CD Pipeline

```yaml
Trigger: Push to main
  ↓
┌─ Build Stage ─────────────────┐
│ 1. Checkout code              │
│ 2. Install dependencies       │
│ 3. Lint                        │
│ 4. Type check                  │
│ 5. Build (tsc)                 │
└───────────────────────────────┘
  ↓
┌─ Test Stage ──────────────────┐
│ 1. Unit tests                 │
│ 2. Integration tests          │
│ 3. Coverage report            │
│ 4. Upload to Codecov          │
└───────────────────────────────┘
  ↓
┌─ Deploy Stage ────────────────┐
│ 1. Deploy to staging          │
│ 2. Smoke tests                │
│ 3. Manual approval            │
│ 4. Deploy to production       │
│ 5. Post-deploy verification   │
└───────────────────────────────┘
```

---

## 🔧 Maintenance

### Monitoring

- **CloudWatch Logs**: Todos los logs del Bot
- **CloudWatch Metrics**: 
  - Invocations
  - Errors
  - Duration
  - Throttles
- **Medplum AuditEvents**: Trazabilidad FHIR

### Alertas

```
┌─ Critical Alerts ─────────────┐
│ • Error rate >1%              │
│ • Lambda timeout >5/min       │
│ • Subscription failed         │
└───────────────────────────────┘

┌─ Warning Alerts ──────────────┐
│ • Error rate >0.1%            │
│ • Latency >1s (p99)           │
│ • Cold starts >10/min         │
└───────────────────────────────┘
```

### Backup y Recovery

- **Code**: GitHub (+ mirror en GitLab)
- **Data**: AWS HealthLake automated backups
- **Secrets**: AWS Secrets Manager (versioned)
- **Config**: Infrastructure as Code (CDK)

---

## 🚀 Roadmap Técnico

### Q1 2026
- [ ] Migrar a Lambda Containers (mayor control)
- [ ] Implementar caching distribuido
- [ ] GraphQL API para queries complejas
- [ ] ML model para predicción de riesgo

### Q2 2026
- [ ] Multi-región deployment
- [ ] Real-time dashboard con WebSockets
- [ ] Integration con wearables (Terra API)
- [ ] Advanced analytics pipeline

### Q3 2026
- [ ] Digital Twin cardiovascular
- [ ] Federated Learning para privacidad
- [ ] Blockchain para audit trail
- [ ] FHIR R6 migration

---

**Documentado por: EPA Bienestar IA - Equipo de Ingeniería**  
**Última actualización: Diciembre 2025**
